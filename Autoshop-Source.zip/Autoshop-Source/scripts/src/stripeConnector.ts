import { ReplitConnectors } from "@replit/connectors-sdk";

async function stripeRequest(path: string, values: Record<string, string>): Promise<Record<string, unknown>> {
  const connectors = new ReplitConnectors();
  const response = await connectors.proxy("stripe", path, {
    method: "POST",
    body: new URLSearchParams(values),
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  });
  if (!response.ok) throw new Error(`Stripe request failed (${response.status})`);
  return (await response.json()) as Record<string, unknown>;
}

export const stripeConnector = {
  createProduct: (name: string, metadata: Record<string, string>) => stripeRequest("/v1/products", { name, ...Object.fromEntries(Object.entries(metadata).map(([k, v]) => [`metadata[${k}]`, v])) }),
  createPrice: (product: string, amountMinor: number, metadata: Record<string, string>) => stripeRequest("/v1/prices", { product, currency: "cad", unit_amount: String(amountMinor), ...Object.fromEntries(Object.entries(metadata).map(([k, v]) => [`metadata[${k}]`, v])) }),
};