import { db, bannerDurationPricesTable, bannerLocationsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { sql } from "drizzle-orm";
import { stripeConnector } from "./stripeConnector";

const locations = [
  { id: "horizontal-listings", placementKey: "horizontal-listings", name: "Horizontal Listings", page: "listings", desktopWidth: 970, desktopHeight: 250, mobileWidth: 320, mobileHeight: 100 },
  { id: "right-rail-1", placementKey: "right-rail-1", name: "Right Rail 1", page: "listings", desktopWidth: 300, desktopHeight: 600, mobileWidth: null, mobileHeight: null },
  { id: "right-rail-2", placementKey: "right-rail-2", name: "Right Rail 2", page: "listings", desktopWidth: 300, desktopHeight: 600, mobileWidth: null, mobileHeight: null },
] as const;
const priceByDuration: Record<number, number> = { 1: 19900, 3: 49900, 6: 89900, 12: 149900 };

const legacy = (await db.select().from(bannerLocationsTable).where(eq(bannerLocationsTable.id, "right-rail"))).at(0);
if (legacy?.isActive) {
  const booked = (await db.execute(sql`SELECT 1 FROM banner_advertisements WHERE location_id=${legacy.id} AND status IN ('active','pending_approval','pending_payment') AND (status <> 'pending_payment' OR reservation_expires_at > now()) LIMIT 1`)).rows[0];
  if (!booked) await db.update(bannerLocationsTable).set({ isActive: false, updatedAt: new Date() }).where(eq(bannerLocationsTable.id, legacy.id));
}

for (const location of locations) {
  const existing = (await db.select().from(bannerLocationsTable).where(eq(bannerLocationsTable.id, location.id))).at(0);
  const saved = existing
    ? (await db.update(bannerLocationsTable).set({
        desktopWidth: location.desktopWidth,
        desktopHeight: location.desktopHeight,
        mobileWidth: location.mobileWidth,
        mobileHeight: location.mobileHeight,
        isActive: true,
        updatedAt: new Date(),
      }).where(eq(bannerLocationsTable.id, location.id)).returning()).at(0)
    : (await db.insert(bannerLocationsTable).values({ ...location, description: "Reach automotive professionals and shop owners." }).returning()).at(0);
  if (!saved) throw new Error(`Unable to seed ${location.id}`);
  for (const months of [1, 3, 6, 12]) {
    const current = (await db.select().from(bannerDurationPricesTable).where(and(eq(bannerDurationPricesTable.locationId, saved.id), eq(bannerDurationPricesTable.durationMonths, months)))).at(0);
    if (current?.stripePriceId) continue;
    const product = await stripeConnector.createProduct(`${saved.name} — ${months} month${months === 1 ? "" : "s"}`, { bannerLocationId: saved.id, durationMonths: String(months) });
    const price = await stripeConnector.createPrice(String(product.id), priceByDuration[months], { bannerLocationId: saved.id, durationMonths: String(months) });
    const productId = String(product.id);
    const priceId = String(price.id);
    if (current) await db.update(bannerDurationPricesTable).set({ amountMinor: priceByDuration[months], stripeProductId: productId, stripePriceId: priceId, currency: "CAD", updatedAt: new Date() }).where(eq(bannerDurationPricesTable.id, current.id));
    else await db.insert(bannerDurationPricesTable).values({ id: `banner-price-${saved.id}-${months}`, locationId: saved.id, durationMonths: months, amountMinor: priceByDuration[months], currency: "CAD", stripeProductId: productId, stripePriceId: priceId });
  }
}

const horizontalBase = (await db.select().from(bannerLocationsTable).where(eq(bannerLocationsTable.id, "horizontal-listings"))).at(0);
if (!horizontalBase) throw new Error("Horizontal banner inventory is missing");
const horizontalBasePrices = await db.select().from(bannerDurationPricesTable).where(eq(bannerDurationPricesTable.locationId, horizontalBase.id));

for (let slot = 2; slot <= 40; slot += 1) {
  const id = `horizontal-listings-${slot}`;
  const existing = (await db.select().from(bannerLocationsTable).where(eq(bannerLocationsTable.id, id))).at(0);
  const saved = existing
    ? (await db.update(bannerLocationsTable).set({
        name: `Horizontal Listings ${slot}`,
        desktopWidth: 970,
        desktopHeight: 250,
        mobileWidth: 320,
        mobileHeight: 100,
        isActive: true,
        updatedAt: new Date(),
      }).where(eq(bannerLocationsTable.id, id)).returning()).at(0)
    : (await db.insert(bannerLocationsTable).values({
        id,
        placementKey: id,
        name: `Horizontal Listings ${slot}`,
        page: "listings",
        desktopWidth: 970,
        desktopHeight: 250,
        mobileWidth: 320,
        mobileHeight: 100,
        description: "Reach automotive professionals and shop owners.",
      }).returning()).at(0);
  if (!saved) throw new Error(`Unable to seed ${id}`);

  for (const basePrice of horizontalBasePrices) {
    const current = (await db.select().from(bannerDurationPricesTable).where(and(
      eq(bannerDurationPricesTable.locationId, saved.id),
      eq(bannerDurationPricesTable.durationMonths, basePrice.durationMonths),
    ))).at(0);
    if (!current) {
      await db.insert(bannerDurationPricesTable).values({
        id: `banner-price-${saved.id}-${basePrice.durationMonths}`,
        locationId: saved.id,
        durationMonths: basePrice.durationMonths,
        amountMinor: basePrice.amountMinor,
        currency: basePrice.currency,
        stripeProductId: basePrice.stripeProductId,
        stripePriceId: basePrice.stripePriceId,
        isActive: basePrice.isActive,
      });
    }
  }
}

const unusedThirdRail = (await db.select().from(bannerLocationsTable).where(eq(bannerLocationsTable.id, "right-rail-3"))).at(0);
if (unusedThirdRail?.isActive) {
  const booked = (await db.execute(sql`SELECT 1 FROM banner_advertisements WHERE location_id=${unusedThirdRail.id} AND status IN ('active','pending_approval','pending_payment') AND (status <> 'pending_payment' OR reservation_expires_at > now()) LIMIT 1`)).rows[0];
  if (!booked) await db.update(bannerLocationsTable).set({ isActive: false, updatedAt: new Date() }).where(eq(bannerLocationsTable.id, unusedThirdRail.id));
}
console.log("Banner advertising inventory seeded");