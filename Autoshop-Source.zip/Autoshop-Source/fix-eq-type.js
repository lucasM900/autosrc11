const fs = require('fs');
let content = fs.readFileSync('artifacts/tool-bay-direct/src/components/equipment-schema-fields.tsx', 'utf8');

const regex = /<select\s*\{\.\.\.field\}\s*value=\{field\.value \|\| ''\}\s*onChange=\{\(e\) => \{\s*field\.onChange\(e\);\s*\/\/[^\n]*\s*const currentAttributes = [^\n]*\s*const resetAttributes = [^\n]*\s*setValue\('attributes', resetAttributes, \{ shouldDirty: true \}\);\s*\}\}/;

content = content.replace(regex, `<select
                  {...field}
                  value={field.value || ''}
                  onChange={(e) => {
                    setValue('attributes', { equipmentType: e.target.value }, { shouldValidate: true, shouldDirty: true });
                  }}`);
fs.writeFileSync('artifacts/tool-bay-direct/src/components/equipment-schema-fields.tsx', content);
