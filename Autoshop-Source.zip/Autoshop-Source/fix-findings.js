const fs = require('fs');

// 1. Update equipment-schema.ts
let schemaContent = fs.readFileSync('artifacts/tool-bay-direct/src/lib/equipment-schema.ts', 'utf8');

schemaContent = schemaContent.replace(
  "export type FieldKind = 'select' | 'multi-select' | 'yes-no' | 'text' | 'number';",
  "export type FieldKind = 'select' | 'multi-select' | 'yes-no' | 'text' | 'number' | 'date';\n\nexport const SUPPORTED_FIELD_KINDS: FieldKind[] = ['select', 'multi-select', 'yes-no', 'text', 'number', 'date'];\n\nexport function assertFieldKindSupported(kind: FieldKind) {\n  if (!SUPPORTED_FIELD_KINDS.includes(kind)) {\n    throw new Error(`Unsupported field kind: ${kind}. Both seller (EquipmentSchemaFields) and buyer (SidebarFilters) UIs must implement it for parity.`);\n  }\n}"
);

// Optional: change Subscription Expiry Date to use 'date' kind for completeness
schemaContent = schemaContent.replace(
  "{ key: 'subscriptionExpiry', label: 'Subscription Expiry Date', kind: 'text' },",
  "{ key: 'subscriptionExpiry', label: 'Subscription Expiry Date', kind: 'date' },"
);

fs.writeFileSync('artifacts/tool-bay-direct/src/lib/equipment-schema.ts', schemaContent);


// 2. Update sidebar-filters.tsx
let sidebarContent = fs.readFileSync('artifacts/tool-bay-direct/src/components/sidebar-filters.tsx', 'utf8');

const returnNullRegex = /return null;\s*\/\/\s*text search not generally needed for dynamic facets in sidebar/;
const replacementSidebar = `if (field.kind === 'text' || field.kind === 'date') {
                return (
                  <div key={field.key}>
                    <label className="text-xs font-bold uppercase tracking-wider text-steel-dark block mb-1">
                      {field.label} {field.units && \`(\${field.units})\`}
                    </label>
                    <input 
                      type={field.kind === 'date' ? 'date' : 'text'} 
                      value={attributeFilters[field.key] || ''} 
                      onChange={(e) => setFilter(field.key, e.target.value)} 
                      className="w-full bg-transparent border-2 border-steel-dark text-sm p-1.5 focus:outline-none focus:border-yellow" 
                    />
                  </div>
                );
              }

              return null;`;
              
sidebarContent = sidebarContent.replace(returnNullRegex, replacementSidebar);
fs.writeFileSync('artifacts/tool-bay-direct/src/components/sidebar-filters.tsx', sidebarContent);


// 3. Update equipment-schema-fields.tsx
let fieldsContent = fs.readFileSync('artifacts/tool-bay-direct/src/components/equipment-schema-fields.tsx', 'utf8');

const yesNoRegex = /<select \{\.\.\.field\} value=\{field\.value !== undefined \? String\(field\.value\) : ''\}>/g;
fieldsContent = fieldsContent.replace(
  yesNoRegex,
  `<select
                          name={field.name}
                          onBlur={field.onBlur}
                          ref={field.ref}
                          value={field.value !== undefined && field.value !== '' ? String(field.value) : ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === '') field.onChange(undefined);
                            else if (val === 'true') field.onChange(true);
                            else if (val === 'false') field.onChange(false);
                          }}
                        >`
);

const textRegex = /return \([\s\S]*?<FormItem className="form-field">[\s\S]*?<FormLabel>\{fieldDef\.label\} \{fieldDef\.units && \`\(\$\{fieldDef\.units\}\)\`\}<\/FormLabel>[\s\S]*?<FormControl>[\s\S]*?<input type="text" \{\.\.\.field\} value=\{field\.value \|\| ''\} \/>[\s\S]*?<\/FormControl>[\s\S]*?<\/FormItem>[\s\S]*?\);/g;

fieldsContent = fieldsContent.replace(
  textRegex,
  `return (
                <FormItem className="form-field">
                  <FormLabel>{fieldDef.label} {fieldDef.units && \`(\${fieldDef.units})\`}</FormLabel>
                  <FormControl>
                    <input type={fieldDef.kind === 'date' ? 'date' : 'text'} {...field} value={field.value || ''} />
                  </FormControl>
                </FormItem>
              );`
);

fs.writeFileSync('artifacts/tool-bay-direct/src/components/equipment-schema-fields.tsx', fieldsContent);


// 4. Update create-listing.tsx and edit-listing.tsx
function fixCategoryOnChange(filename) {
  let content = fs.readFileSync(filename, 'utf8');
  
  // Replace the Category onChange handler
  // Old: <select {...field} onChange={(e) => { field.onChange(e); form.setValue('attributes', {}); }}>
  // Old (edit): <select {...field} onChange={(e) => { field.onChange(e); form.setValue('attributes', {}, { shouldDirty: true }); }}>
  
  content = content.replace(
    /<select \{\.\.\.field\} onChange=\{\(e\) => \{ field\.onChange\(e\); form\.setValue\('attributes', \{\}(, \{ shouldDirty: true \})?\); \}\}>/g,
    `<select {...field} onChange={(e) => { 
                      form.setValue('category', e.target.value, { shouldValidate: true, shouldDirty: true }); 
                      form.setValue('attributes', {}, { shouldValidate: true, shouldDirty: true }); 
                    }}>`
  );
  
  fs.writeFileSync(filename, content);
}

fixCategoryOnChange('artifacts/tool-bay-direct/src/pages/create-listing.tsx');
fixCategoryOnChange('artifacts/tool-bay-direct/src/pages/edit-listing.tsx');

console.log("Fixes applied successfully.");
