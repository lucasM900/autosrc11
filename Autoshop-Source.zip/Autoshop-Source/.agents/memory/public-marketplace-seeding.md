---
name: Public marketplace seeding
description: Public listing APIs may receive concurrent first requests while initializing example data.
---

Initial example-data creation for a public marketplace must be idempotent under concurrent requests.

**Why:** The browser loads listings and summary data in parallel, so both endpoints can try to initialize an empty database at the same time.

**How to apply:** Use conflict-safe inserts and always fetch the resulting rows after initialization; never assume a single first request.