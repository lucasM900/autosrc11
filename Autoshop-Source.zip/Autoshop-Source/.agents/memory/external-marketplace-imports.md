---
name: External marketplace imports
description: Product and compliance rules for importing third-party equipment listings.
---

Third-party marketplace imports must disclose their source on the detail page, must not imply the source seller created an account, and must describe on-site inquiries as relay requests rather than direct seller delivery. Source attribution should not appear on marketplace scrolling cards.

The project owner confirmed on September 17, 2026 that Autoshop Source has permission to republish the Kijiji listing photographs. Store imported copies in App Storage rather than hotlinking them.

**Why:** Scraped records may not include reliable seller contact details. Hiding provenance or promising seller delivery would mislead buyers, while hotlinking leaves the site dependent on third-party image availability.

**How to apply:** Import factual fields and the authorized photographs, continue omitting copied descriptions unless separately authorized, preserve source URLs internally, deduplicate by source ID, and disclose on detail pages that price and availability require confirmation.