---
name: Seller listing resilience
description: Keep seller inventory visibility independent from external payment verification.
---

Seller inventory reads must remain available even when an unrelated premium-checkout reconciliation fails. Do not convert a failed request into an empty-state message in the dashboard.

**Why:** A pending Checkout session created in another Stripe environment can be unavailable to the currently connected account. That lookup previously failed the entire seller listings request, making saved listings appear absent after retries despite remaining in the database.

**How to apply:** Treat payment reconciliation as best-effort for inventory reads, log its failure, and preserve pending payment state unless payment status is verified. Keep distinct loading, error, and genuinely empty states in the UI. Changes to checkout recovery require extra care not to mark potentially paid sessions unpaid.