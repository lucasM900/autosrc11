---
name: Object storage burst warnings
description: Replit object storage behavior during highly concurrent reads.
---

The GCS-backed object storage client can emit `MaxListenersExceededWarning` messages on internal `PassThrough` streams during a burst of roughly 20 concurrent object reads, even when every request returns successfully.

**Why:** Both streamed reads and buffered `file.download()` reads reproduced the warning, so replacing streaming with buffering does not address the SDK behavior and unnecessarily raises server memory use.

**How to apply:** Treat the warning separately from failed responses, retain streaming for general object serving, and investigate SDK concurrency limiting only if real traffic shows failed or aborted image requests.