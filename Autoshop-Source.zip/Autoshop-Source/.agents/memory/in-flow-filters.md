---
name: In-flow filter interactions
description: Event timing constraint for expanding filter menus in normal document flow.
---
Dismiss outside-open menus after the target click, not on pointer-down or mouse-down.

**Why:** Collapsing an upstream menu on mouse-down moves the downstream Type button before mouse-up. Its click is lost, creating an intermittent-looking failure even though options exist.

**How to apply:** Preserve click completion when changing outside-dismiss behavior for normal-flow filter menus. Verify category-to-type selection with ordinary pointer clicks, not only programmatic clicks.