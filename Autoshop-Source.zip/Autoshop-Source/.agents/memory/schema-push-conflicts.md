---
name: Development schema push conflicts
description: How to handle noninteractive Drizzle schema push conflicts in this workspace without risking existing data.
---

The development database can have schema drift that makes an ordinary Drizzle push request an interactive table-conflict decision. Noninteractive shell runs then fail before applying any changes.

**Why:** A push while adding unrelated profile and messaging tables stopped at a TTY-only conflict prompt. Using force would silently resolve unrelated drift and could discard existing data.

**How to apply:** Inspect the exact proposed change and existing database state before applying it. For purely additive new tables, apply only those development-side DDL statements if needed; keep the Drizzle schema as the source of truth. Never use force as a workaround for an unexamined conflict, and leave production schema updates to the Publish flow.