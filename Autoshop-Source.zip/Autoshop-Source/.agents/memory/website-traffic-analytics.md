---
name: Website traffic analytics
description: Privacy and counting rules for the owner traffic dashboard.
---

Website traffic metrics use anonymous browser and session IDs that are HMAC-hashed on the server. Store no names, emails, raw visitor IDs, or raw IP addresses. Filter known bot user agents and describe unique visitors as approximate people, not verified humans.

**Why:** A browser can represent one person on several devices or be shared by several people, while page views alone are easily inflated. The dashboard must be useful without overstating certainty or collecting unnecessary personal data.

**How to apply:** Keep aggregate access owner-only, count successful login and sign-up transitions rather than button clicks, retain raw events for no more than 13 months, and preserve the on-screen methodology note.