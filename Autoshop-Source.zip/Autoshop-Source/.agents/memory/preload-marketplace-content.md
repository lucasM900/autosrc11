---
name: Preload marketplace content
description: Keep the initial marketplace HTML readable to non-JavaScript clients without showing it as a flash to normal visitors.
---

Keep the server-delivered marketplace fallback readable without JavaScript, but hide its raw text immediately when JavaScript is enabled and show a branded loading state until the interactive app mounts.

**Why:** Removing initial HTML to prevent a brief unstyled text flash would also remove useful content for non-JavaScript visitors and crawlers.

**How to apply:** When changing the initial page or its loading behavior, preserve the no-JavaScript path and check both the first interactive paint and the final mounted app.