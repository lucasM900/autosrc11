---
name: Stripe connector payments
description: The durable payment-integration constraint for the attached Replit Stripe connector.
---

Use the authenticated Stripe connector proxy rather than expecting a raw Stripe secret key. Treat Checkout session data retrieved server-side as the payment source of truth, and never activate a campaign from browser query parameters alone.

**Why:** This connector intentionally does not expose `secret_key` or a webhook signing secret. Credential-based Stripe SDK and sync templates fail even though the connection itself is healthy.

**How to apply:** Create and retrieve Stripe resources through the connector proxy. Validate stored Product/Price IDs against the currently connected account at startup and replace `resource_missing` IDs because connection changes can leave valid-looking IDs from another account. Persist every Checkout attempt so concurrent or superseded sessions cannot lose a paid purchase. Before activation, retrieve the session and attest its mode, amount, currency, metadata, client reference, and payment intent. Keep transitions idempotent and release expired pending reservations.