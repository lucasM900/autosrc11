---
name: Device location privacy
description: How device geolocation is used in public seller fields versus private marketplace filters
---

When a person uses device location to fill a public profile or listing, resolve it to a nearby city or region and use approximate coordinates rather than publishing their exact position or street address. Marketplace radius filtering may use precise coordinates transiently without saving them to a public record.

**Why:** A browser's location permission can return a home or workplace position accurate enough to identify an address; public seller fields do not require that precision.

**How to apply:** Keep any future "Use My Location" forms consistent with this distinction. The browser owns its native permission prompt and displays the site's origin; app copy can be simplified, but removing random-looking development-domain characters from the native prompt requires a branded published domain rather than a frontend text change.