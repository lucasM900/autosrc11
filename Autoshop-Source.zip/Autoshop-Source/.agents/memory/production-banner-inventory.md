---
name: Production banner inventory
description: Why required advertising inventory must be initialized independently in development and production.
---

Required banner locations and initial prices must be initialized idempotently by the API in every environment, while existing records and owner edits remain untouched.

**Why:** Development seed commands only populate the development database. A published frontend can still render placement boxes while the production API returns no inventory, making owner management empty and reservations unavailable.

**How to apply:** Any new required placement needs an idempotent production initialization path. Use concurrency protection, insert only missing records, and never overwrite owner-managed activation or pricing settings.