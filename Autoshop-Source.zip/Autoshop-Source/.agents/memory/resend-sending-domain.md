---
name: Resend sending domain validation
description: This project's Resend connection is send-only and cannot list verified domains.
---

The connected Resend API key is restricted to sending emails, so `GET /domains` returns a restricted-key error. Do not interpret that as a disconnected integration. A test send from a proposed address can reveal a clear unverified-domain error.

**Why:** An attempted send from the project's custom domain was rejected with `403` because that domain had not been verified; a Gmail mailbox cannot substitute for a verified sending domain.

**How to apply:** Require the user to verify a domain they control in Resend before promising outgoing mail works. Do not treat a connected sender integration as proof of a usable From address. Avoid using the public Gmail address as the From domain.