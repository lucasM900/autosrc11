/**
 * Shared, displayable manufacturer registry.
 *
 * This module deliberately contains brands only. Model suggestions remain in
 * the UI catalogue and are never used to infer a seller's brand. Keeping the
 * registry shared prevents the API's "Other" complement from drifting away
 * from the checkboxes buyers actually see.
 */

export const OTHER_BRAND_VALUE = '__other__';

export const LEGACY_ATTRIBUTE_ALIASES: Record<string, string[]> = {
  manualIncluded: ['manualsIncluded'],
  serviceRecords: ['serviceHistory'],
  installationStatus: ['installationIncluded'],
};

export function getAttributeWithLegacyAliases(
  attributes: Record<string, unknown>,
  key: string,
): unknown {
  const current = attributes[key];
  if (current !== undefined && current !== null && current !== '') return current;

  for (const legacyKey of LEGACY_ATTRIBUTE_ALIASES[key] ?? []) {
    const legacy = attributes[legacyKey];
    if (legacy === undefined || legacy === null || legacy === '') {
      if (key === 'serviceRecords' && legacy !== undefined) return 'false';
      continue;
    }
    if (key === 'installationStatus') {
      if (legacy === true || String(legacy).toLowerCase() === 'true') return 'included';
      if (legacy === false || String(legacy).toLowerCase() === 'false') return 'no';
    }
    if (key === 'serviceRecords') {
      const normalized = String(legacy).trim().toLowerCase();
      return ['false', 'no', 'none', 'not available', 'unavailable'].includes(normalized)
        ? 'false'
        : 'true';
    }
    return legacy;
  }
  return undefined;
}

export function legacyAttributeKeys(): Set<string> {
  return new Set(Object.values(LEGACY_ATTRIBUTE_ALIASES).flat());
}

function normalizeBrand(value: string): string {
  return value.trim().toLocaleLowerCase().replace(/\s+/g, ' ');
}

type BrandRegistry = Record<string, Record<string, string[]>>;

function perType(
  types: string[],
  defaults: string[],
  overrides: Record<string, string[]> = {},
): Record<string, string[]> {
  return Object.fromEntries(types.map(type => [type, overrides[type] ?? defaults]));
}

export const BRAND_REGISTRY: BrandRegistry = {
  'vehicle-lifts': perType(
    ['2-post', '4-post', 'scissor', 'low-rise', 'mid-rise', 'in-ground', 'mobile-column', 'alignment', 'motorcycle', 'heavy-duty-truck', 'portable'],
    ['Rotary Lift', 'BendPak', 'Challenger Lifts', 'Mohawk Lifts', 'Stertil-Koni', 'Forward Lift', 'Dannmar', 'Ranger'],
    {
      '2-post': ['Rotary Lift', 'BendPak', 'Challenger Lifts', 'Mohawk Lifts', 'Stertil-Koni'],
      '4-post': ['Rotary Lift', 'BendPak', 'Challenger Lifts', 'Stertil-Koni'],
      scissor: ['Rotary Lift', 'BendPak', 'Challenger Lifts', 'Stertil-Koni', 'Hunter Engineering'],
      'low-rise': ['Rotary Lift', 'BendPak', 'Challenger Lifts'],
      'mid-rise': ['Rotary Lift', 'BendPak', 'Challenger Lifts'],
      'in-ground': ['Rotary Lift', 'Challenger Lifts', 'Mohawk Lifts', 'Stertil-Koni'],
      'mobile-column': ['Rotary Lift', 'Challenger Lifts', 'Mohawk Lifts', 'Stertil-Koni'],
      alignment: ['Rotary Lift', 'Challenger Lifts', 'Mohawk Lifts', 'Hunter Engineering'],
      motorcycle: ['Handy Industries', 'Titan Lifts', 'BendPak'],
      'heavy-duty-truck': ['Rotary Lift', 'Stertil-Koni', 'Mohawk Lifts', 'Challenger Lifts'],
      portable: ['BendPak', 'Titan Lifts'],
    },
  ),
  'tire-changers': perType(
    ['automatic', 'semi-automatic', 'swing-arm', 'leverless', 'tilt-back', 'heavy-duty', 'truck-bus', 'motorcycle', 'run-flat'],
    ['Hunter Engineering', 'Corghi', 'Coats', 'Ranger', 'Hofmann', 'Giuliano', 'Atlas'],
    {
      'swing-arm': ['Hunter Engineering', 'Corghi', 'Coats', 'Ranger'],
      leverless: ['Hunter Engineering', 'Corghi', 'Coats', 'Ranger'],
      'tilt-back': ['Hunter Engineering', 'Corghi', 'Coats', 'Ranger'],
      'heavy-duty': ['Hunter Engineering', 'Corghi', 'Coats', 'Ranger'],
      motorcycle: ['Hunter Engineering', 'Corghi', 'Coats', 'Ranger'],
    },
  ),
  'wheel-balancers': perType(
    ['standard', 'high-speed', 'truck', 'motorcycle', 'diagnostic', 'road-force'],
    ['Hunter Engineering', 'Hofmann', 'Coats', 'Corghi', 'Ranger'],
    { motorcycle: ['Hunter Engineering', 'Coats', 'Corghi', 'Ranger'] },
  ),
  'wheel-alignment': perType(
    ['2-wheel', '4-wheel', '3d', 'ccd', 'laser', 'mobile'],
    ['Hunter Engineering', 'John Bean', 'Hofmann', 'Beissbarth', 'Snap-on', 'Launch'],
  ),
  'diagnostic-scanners': perType(
    ['professional', 'oem', 'universal', 'adas', 'key-programming', 'ecu-programming', 'ev-diagnostics', 'battery-diagnostics', 'tpms', 'handheld', 'tablet', 'pc-based', 'heavy-duty'],
    ['Autel', 'LAUNCH', 'Snap-on', 'Bosch', 'TEXA', 'Jaltest', 'TOPDON', 'OTC'],
    {
      handheld: ['Autel', 'LAUNCH', 'Snap-on', 'Bosch'],
      tablet: ['Autel', 'LAUNCH', 'Snap-on', 'Bosch', 'TEXA'],
      'pc-based': ['Autel', 'LAUNCH', 'Bosch', 'Jaltest', 'TEXA'],
      'heavy-duty': ['Autel', 'LAUNCH', 'Bosch', 'TEXA', 'Jaltest'],
      adas: ['Autel', 'Bosch', 'LAUNCH', 'TEXA'],
    },
  ),
  'adas-calibration': perType(
    ['static', 'dynamic', 'radar', 'camera', 'lidar', 'multi-brand'],
    ['Autel', 'Bosch', 'Hunter Engineering', 'John Bean', 'Launch', 'Hella Gutmann', 'TEXA'],
    {
      radar: ['Bosch', 'Autel', 'Hella Gutmann', 'TEXA'],
      lidar: ['Autel', 'Bosch', 'TEXA'],
    },
  ),
  compressors: perType(
    ['rotary-screw', 'reciprocating', 'scroll', 'vertical', 'horizontal', 'portable'],
    ['Kaeser', 'Atlas Copco', 'Ingersoll Rand', 'Quincy Compressor', 'Sullair', 'Powerex', 'Gardner Denver'],
    {
      'rotary-screw': ['Kaeser', 'Atlas Copco', 'Ingersoll Rand', 'Quincy Compressor', 'Sullair'],
      reciprocating: ['Kaeser', 'Atlas Copco', 'Ingersoll Rand', 'Quincy Compressor', 'Powerex'],
      scroll: ['Atlas Copco', 'Ingersoll Rand', 'Quincy Compressor', 'Powerex'],
      portable: ['Atlas Copco', 'Ingersoll Rand', 'Kaeser', 'Sullair', 'Quincy Compressor'],
    },
  ),
  'air-shop-systems': perType(
    ['air-dryer', 'air-receiver', 'filter', 'regulator', 'air-treatment', 'hose-reel', 'air-distribution'],
    ['Kaeser', 'Atlas Copco', 'Ingersoll Rand', 'Quincy Compressor', 'Sullair', 'Hankison', 'Parker'],
    {
      'hose-reel': ['Reelcraft', 'Coxreels', 'Lincoln', 'Graco'],
      regulator: ['Parker', 'Norgren', 'SMC', 'Ingersoll Rand'],
    },
  ),
  'tire-service': perType(
    ['inflation-system', 'nitrogen-generator', 'nitrogen-machine', 'inflation-cage', 'bead-seating', 'repair-machine', 'tire-spreader', 'storage-rack', 'tire-changer', 'wheel-balancer'],
    ['Hofmann', 'Hunter Engineering', 'Ranger', 'Coats', 'Motive Products', 'Dill'],
  ),
  'oil-fluid-service': perType(
    ['oil-drainer', 'oil-dispenser', 'fluid-extractor', 'transmission-fluid', 'coolant-flush', 'brake-bleeding', 'power-steering', 'differential-fluid', 'ac-service'],
    ['Lincoln', 'Graco', 'Mityvac', 'JohnDow', 'OTC', 'Macnaught', 'Robinair'],
    {
      'ac-service': ['Robinair', 'MAHLE', 'Mastercool', 'TEXA', 'CPS'],
    },
  ),
  'ac-service': perType(
    ['r134a', 'r1234yf', 'dual-gas'],
    ['Robinair', 'MAHLE', 'Mastercool', 'Snap-on', 'TEXA', 'CPS'],
  ),
  'brake-service': perType(
    ['brake-lathe', 'brake-bleeder', 'brake-flush', 'brake-tester', 'disc-resurfacing', 'drum-resurfacing'],
    ['Ammco', 'Ranger', 'Pro-Cut', 'Hunter Engineering', 'Snap-on', 'BendPak'],
  ),
  'engine-transmission': perType(
    ['engine-hoist', 'engine-stand', 'transmission-jack', 'transmission-lift', 'engine-crane', 'drivetrain-table', 'mobile-workstation'],
    ['OTC', 'Forward Lift', 'Norco', 'Sunex', 'Torin', 'ESCO'],
  ),
  welding: perType(
    ['mig', 'tig', 'plasma', 'stick', 'spot', 'frame', 'welding-table', 'fume-extractor'],
    ['Lincoln Electric', 'Miller', 'ESAB', 'Hobart', 'Fronius', 'Everlast', 'Hypertherm'],
    {
      plasma: ['Hypertherm', 'Miller', 'Lincoln Electric', 'ESAB'],
      'welding-table': ['WeldTables', 'Strong Hand Tools', 'Baileigh', 'Certiflat'],
    },
  ),
  'body-shop': perType(
    ['frame-machine', 'frame-straightening', 'paint-booth', 'prep-station', 'paint-mixing', 'dent-repair', 'spot-welder', 'aluminum-repair', 'plastic-repair', 'dust-extraction', 'sanding', 'paint-booth-filters'],
    ['Car-O-Liner', 'Chief Automotive', 'Globaljig', 'Garmat', 'Blowtherm', 'Celette', 'Wielander+Schill'],
  ),
  detailing: perType(
    ['steam-cleaner', 'extractor', 'pressure-washer', 'polisher', 'vacuum', 'ozone-generator', 'carpet-cleaner', 'detailing-cart', 'water-reclaim'],
    ['Kärcher', 'Mi-T-M', 'Mytee', 'Tornador', 'Rupes', 'Flex', 'Metrovac'],
  ),
  'vehicle-inspection': perType(
    ['brake-tester', 'suspension-tester', 'headlight-tester', 'emissions', 'exhaust-analyzer', 'battery-tester', 'charging-system', 'dynamometer'],
    ['MAHA', 'Hunter Engineering', 'Snap-on', 'Bosch', 'OTC', 'AVL'],
  ),
  'battery-ev': perType(
    ['battery-lift', 'battery-testing', 'insulation-tester', 'hv-diagnostic', 'charger', 'charging-station', 'battery-storage', 'hv-safety', 'service-table'],
    ['Bosch', 'Midtronics', 'Autel', 'MAHLE', 'Hella Gutmann', 'DeWalt', 'Schumacher'],
  ),
  'battery-chargers': perType(
    ['charger', 'maintainer', 'jump-starter', 'analyzer', 'booster'],
    ['CTEK', 'NOCO', 'Midtronics', 'Schumacher', 'Associated Equipment', 'Clore Automotive', 'Draper'],
  ),
  'shop-furniture': perType(
    ['workbench', 'tool-cabinet', 'tool-box', 'service-cart', 'parts-cabinet', 'storage-rack', 'tire-rack', 'shelving', 'reception', 'computer-station'],
    ['Lista', 'Vidmar', 'Bott', 'Würth', 'Snap-on', 'Matco', 'Husky'],
  ),
  'shop-infrastructure': perType(
    ['exhaust-extraction', 'shop-fan', 'industrial-fan', 'heater', 'hvac', 'oil-tank', 'fluid-tank', 'waste-oil-furnace', 'waste-oil-tank', 'pressure-washer', 'water-reclaim', 'lighting', 'security', 'generator', 'electrical'],
    ['Dayton', 'Jet', 'Kohler', 'Generac', 'Reznor', 'Modine', 'Greenheck'],
  ),
  'parts-cleaning': perType(
    ['parts-washer', 'ultrasonic', 'solvent', 'hot-water-pressure-washer', 'steam-cleaner', 'degreaser'],
    ['Safety-Kleen', 'Jensen', 'Karcher', 'ChemFree', 'Branson', 'Elma'],
  ),
  metalworking: perType(
    ['lathe', 'milling-machine', 'drill-press', 'hydraulic-press', 'grinder', 'parts-washer', 'sandblasting-cabinet', 'metal-cutting', 'hydraulic'],
    ['Jet', 'Baileigh', 'Haas', 'Miller', 'Lincoln Electric', 'Clausing', 'Grizzly'],
  ),
  milling: perType(
    ['lathe', 'milling-machine', 'drill-press', 'hydraulic-press', 'grinder', 'parts-washer', 'sandblasting-cabinet', 'metal-cutting', 'hydraulic'],
    ['Jet', 'Baileigh', 'Haas', 'Miller', 'Lincoln Electric', 'Clausing', 'Grizzly'],
  ),
  'motorcycle-shop': perType(
    ['motorcycle-lift', 'tire-changer', 'wheel-balancer', 'motorcycle-stand', 'engine-stand', 'diagnostic', 'wheel-service'],
    ['Handy Industries', 'Ranger', 'Hunter Engineering', 'No-Mar', 'K&L Supply', 'BendPak', 'Derek Weaver'],
  ),
  'heavy-truck': perType(
    ['heavy-duty-lift', 'mobile-column', 'truck-tire-changer', 'truck-wheel-balancer', 'truck-alignment', 'diesel-diagnostic', 'dpf-cleaning', 'brake-tester', 'engine-equipment', 'transmission-equipment'],
    ['Stertil-Koni', 'Rotary Lift', 'Challenger Lifts', 'Hunter Engineering', 'Jaltest', 'Hendrickson', 'BendPak'],
  ),
  specialty: perType(
    ['dpf-cleaner', 'injector-cleaner', 'fuel-system-cleaner', 'carbon-cleaning', 'hydrogen-cleaning', 'decarbonization', 'smoke-leak', 'cooling-system', 'pressure-tester', 'ultrasonic', 'borescope', 'oscilloscope', 'adas'],
    ['Autel', 'MAHLE', 'Carbon Clean', 'Liqui Moly', 'BG Products', 'OTC', 'Snap-on'],
  ),
  'shop-business-assets': perType(
    ['individual-item', 'shop-liquidation', 'shop-package'],
    ['Rotary Lift', 'Snap-on', 'Matco', 'Lista', 'Kaeser', 'Lincoln Electric', 'Hunter Engineering'],
  ),
  hoists: perType(['engine-hoist', 'shop-hoist'], ['OTC', 'Norco', 'Sunex', 'Torin', 'Rotary Lift', 'BendPak']),
  generators: perType(['portable', 'industrial'], ['Generac', 'Kohler', 'Cummins', 'CAT', 'Honda', 'Multiquip']),
  'hand-power': perType(['hand-tools', 'power-tools'], ['Snap-on', 'Matco', 'Mac Tools', 'Milwaukee', 'DeWalt', 'Makita', 'Bosch']),
  diagnostics: perType(['general', 'electrical'], ['Autel', 'LAUNCH', 'Snap-on', 'Bosch', 'OTC', 'TEXA']),
  'lifts-jacks': perType(['floor-jack', 'jack-stand', 'transmission-jack'], ['OTC', 'Norco', 'Sunex', 'Torin', 'ESCO', 'BendPak']),
};

export function getRegisteredBrands(category: string, equipmentType?: string): string[] {
  const categoryRegistry = BRAND_REGISTRY[category];
  if (!categoryRegistry) return [];
  if (equipmentType) return [...(categoryRegistry[equipmentType] ?? [])];
  return [...new Set(Object.values(categoryRegistry).flat())];
}

export function isRegisteredBrand(category: string, equipmentType: string, value: unknown): boolean {
  if (typeof value !== 'string') return false;
  const normalized = normalizeBrand(value);
  return getRegisteredBrands(category, equipmentType).some(brand => normalizeBrand(brand) === normalized);
}

export function isCustomBrand(category: string, equipmentType: string, value: unknown): boolean {
  return typeof value === 'string' && normalizeBrand(value).length > 0 && !isRegisteredBrand(category, equipmentType, value);
}

export function normalizeRegisteredBrand(value: string): string {
  return normalizeBrand(value);
}