import {
  boolean,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  real,
  text,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const bannerAdStatusEnum = pgEnum("banner_ad_status", [
  "pending_payment",
  "pending_approval",
  "active",
  "expired",
  "cancelled",
  "rejected",
]);

export const bannerLocationsTable = pgTable("banner_locations", {
  id: text("id").primaryKey(),
  placementKey: text("placement_key").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  page: text("page").notNull().default("site"),
  desktopWidth: integer("desktop_width").notNull(),
  desktopHeight: integer("desktop_height").notNull(),
  mobileWidth: integer("mobile_width"),
  mobileHeight: integer("mobile_height"),
  maxFileSizeBytes: integer("max_file_size_bytes").notNull().default(5242880),
  isActive: boolean("is_active").notNull().default(true),
  approvalRequired: boolean("approval_required").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const bannerDurationPricesTable = pgTable("banner_duration_prices", {
  id: text("id").primaryKey(),
  locationId: text("location_id").notNull().references(() => bannerLocationsTable.id, { onDelete: "cascade" }),
  durationMonths: integer("duration_months").notNull(),
  amountMinor: integer("amount_minor").notNull(),
  currency: text("currency").notNull().default("CAD"),
  stripeProductId: text("stripe_product_id"),
  stripePriceId: text("stripe_price_id"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [unique("banner_duration_location_duration_unique").on(table.locationId, table.durationMonths)]);

export const bannerAdvertisementsTable = pgTable("banner_advertisements", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  locationId: text("location_id").notNull().references(() => bannerLocationsTable.id),
  desktopImagePath: text("desktop_image_path").notNull(),
  mobileImagePath: text("mobile_image_path"),
  desktopWidth: integer("desktop_width").notNull(),
  desktopHeight: integer("desktop_height").notNull(),
  mobileWidth: integer("mobile_width"),
  mobileHeight: integer("mobile_height"),
  destinationUrl: text("destination_url").notNull(),
  durationMonths: integer("duration_months").notNull(),
  amountMinor: integer("amount_minor").notNull(),
  currency: text("currency").notNull().default("CAD"),
  status: bannerAdStatusEnum("status").notNull().default("pending_payment"),
  checkoutSessionId: text("checkout_session_id").unique(),
  paymentIntentId: text("payment_intent_id"),
  purchaseAt: timestamp("purchase_at", { withTimezone: true }),
  startAt: timestamp("start_at", { withTimezone: true }),
  endAt: timestamp("end_at", { withTimezone: true }),
  reservationExpiresAt: timestamp("reservation_expires_at", { withTimezone: true }),
  impressions: integer("impressions").notNull().default(0),
  clicks: integer("clicks").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
});

export const bannerAnalyticsEventsTable = pgTable("banner_analytics_events", {
  id: text("id").primaryKey(),
  advertisementId: text("advertisement_id").notNull().references(() => bannerAdvertisementsTable.id, { onDelete: "cascade" }),
  eventType: text("event_type").notNull(),
  ipHash: text("ip_hash"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const bannerWebhookEventsTable = pgTable("banner_webhook_events", {
  id: text("id").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertBannerLocationSchema = createInsertSchema(bannerLocationsTable).omit({ createdAt: true, updatedAt: true });
export const insertBannerDurationPriceSchema = createInsertSchema(bannerDurationPricesTable).omit({ createdAt: true, updatedAt: true });
export const insertBannerAdvertisementSchema = createInsertSchema(bannerAdvertisementsTable).omit({ createdAt: true, updatedAt: true });
export type BannerLocation = typeof bannerLocationsTable.$inferSelect;
export type BannerDurationPrice = typeof bannerDurationPricesTable.$inferSelect;
export type BannerAdvertisement = typeof bannerAdvertisementsTable.$inferSelect;
export type InsertBannerLocation = z.infer<typeof insertBannerLocationSchema>;
export type InsertBannerDurationPrice = z.infer<typeof insertBannerDurationPriceSchema>;
export type InsertBannerAdvertisement = z.infer<typeof insertBannerAdvertisementSchema>;