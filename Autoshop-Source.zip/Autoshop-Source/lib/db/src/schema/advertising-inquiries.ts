import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const advertisingInquiriesTable = pgTable("advertising_inquiries", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  company: text("company").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  placement: text("placement").notNull(),
  budget: text("budget"),
  message: text("message").notNull(),
  status: text("status").notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertAdvertisingInquirySchema = createInsertSchema(
  advertisingInquiriesTable,
).omit({
  createdAt: true,
});
export type InsertAdvertisingInquiry = z.infer<
  typeof insertAdvertisingInquirySchema
>;
export type AdvertisingInquiry =
  typeof advertisingInquiriesTable.$inferSelect;