import { index, pgTable, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const conversationsTable = pgTable("conversations", {
  id: text("id").primaryKey(),
  listingId: text("listing_id").notNull(),
  listingTitle: text("listing_title").notNull(),
  buyerId: text("buyer_id").notNull(),
  sellerId: text("seller_id").notNull(),
  lastMessage: text("last_message").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  uniqueIndex("conversations_listing_buyer_unique").on(table.listingId, table.buyerId),
  index("conversations_buyer_updated_idx").on(table.buyerId, table.updatedAt),
  index("conversations_seller_updated_idx").on(table.sellerId, table.updatedAt),
]);

export const conversationMessagesTable = pgTable("conversation_messages", {
  id: text("id").primaryKey(),
  conversationId: text("conversation_id").notNull().references(() => conversationsTable.id),
  senderId: text("sender_id").notNull(),
  body: text("body").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("conversation_messages_thread_idx").on(table.conversationId, table.createdAt),
]);

export const insertConversationSchema = createInsertSchema(conversationsTable).omit({ updatedAt: true });
export const insertConversationMessageSchema = createInsertSchema(conversationMessagesTable).omit({ createdAt: true });
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversationsTable.$inferSelect;
export type ConversationMessage = typeof conversationMessagesTable.$inferSelect;