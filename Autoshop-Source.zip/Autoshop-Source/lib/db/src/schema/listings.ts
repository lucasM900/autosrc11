import { sql } from "drizzle-orm";
import {
  jsonb,
  boolean,
  integer,
  pgEnum,
  pgTable,
  real,
  text,
  timestamp,
  check,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const listingStatusEnum = pgEnum("listing_status", [
  "active",
  "expired",
  "sold",
  "cancelled",
] as const);

export const listingsTable = pgTable("listings", {
  id: text("id").primaryKey(),
  // Nullable for the original seed listings, which predate Clerk accounts.
  ownerId: text("owner_id"),
  title: text("title").notNull(),
  category: text("category").notNull(),
  condition: text("condition").notNull(),
  price: real("price").notNull(),
  location: text("location").notNull(),
  latitude: real("latitude"),
  longitude: real("longitude"),
  countryCode: text("country_code"),
  currencyCode: text("currency_code").notNull().default("CAD"),
  spec: text("spec").notNull(),
  description: text("description"),
  attributes: jsonb("attributes")
    .$type<Record<string, unknown>>()
    .notNull()
    .default({}),
  contact: text("contact").notNull(),
  image: text("image"),
  imagePaths: text("image_paths").array().notNull().default([]),
  status: listingStatusEnum("status").notNull().default("active"),
  // Nullable to preserve pre-expiry legacy listings in production; new listings
  // always receive the 90-day application-controlled term and this DB default.
  expiresAt: timestamp("expires_at", { withTimezone: true })
    .default(sql`now() + '90 days'::interval`),
  isPremium: boolean("is_premium").notNull().default(false),
  premiumCheckoutSessionId: text("premium_checkout_session_id"),
  premiumPaymentIntentId: text("premium_payment_intent_id"),
  premiumPaidAt: timestamp("premium_paid_at", { withTimezone: true }),
  premiumExpiresAt: timestamp("premium_expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
}, (table) => [
  check("listings_image_paths_max_7", sql`cardinality(${table.imagePaths}) <= 7`),
]);

export const insertListingSchema = createInsertSchema(listingsTable).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertListing = z.infer<typeof insertListingSchema>;
export type Listing = typeof listingsTable.$inferSelect;

export const premiumListingPricingTable = pgTable("premium_listing_pricing", {
  id: text("id").primaryKey(),
  amountMinor: integer("amount_minor").notNull().default(999),
  currency: text("currency").notNull().default("CAD"),
  stripeProductId: text("stripe_product_id"),
  stripePriceId: text("stripe_price_id"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const listingPremiumPaymentsTable = pgTable("listing_premium_payments", {
  id: text("id").primaryKey(),
  listingId: text("listing_id").notNull(),
  ownerId: text("owner_id").notNull(),
  stripeCheckoutSessionId: text("stripe_checkout_session_id").notNull().unique(),
  stripePaymentIntentId: text("stripe_payment_intent_id").unique(),
  amountMinor: integer("amount_minor").notNull(),
  currency: text("currency").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  paidAt: timestamp("paid_at", { withTimezone: true }),
});