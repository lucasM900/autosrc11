import { createHash, randomUUID } from "node:crypto";
import { and, desc, eq, or, asc } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  GetConversationParams, GetConversationResponse, GetMyProfileResponse,
  GetUserProfileParams, GetUserProfileResponse, ListConversationsResponse,
  RequestProfilePhotoUploadUrlBody, RequestProfilePhotoUploadUrlResponse,
  SendConversationMessageBody, SendConversationMessageParams, SendConversationMessageResponse,
  StartListingConversationBody, StartListingConversationParams, StartListingConversationResponse,
  UpdateMyProfileBody, UpdateMyProfileResponse, UpdateMyProfilePhotoBody, UpdateMyProfilePhotoResponse,
} from "@workspace/api-zod";
import {
  db, listingsTable, userProfilesTable, conversationsTable, conversationMessagesTable,
  type Conversation,
} from "@workspace/db";
import { getAuthenticatedUserId, requireAuth } from "../middlewares/auth";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();
const PHOTO_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);
const MAX_PHOTO_BYTES = 3_000_000;

function profilePhotoPrefix(userId: string) {
  return `profiles/${createHash("sha256").update(userId).digest("hex")}`;
}

function profile(userId: string, row?: { displayName: string; bio: string; location: string; avatarPath: string | null }) {
  return {
    userId,
    displayName: row?.displayName ?? "Member",
    bio: row?.bio ?? "",
    location: row?.location ?? "",
    avatarPath: row?.avatarPath ?? null,
  };
}

router.get("/profile/me", requireAuth, async (req, res): Promise<void> => {
  const userId = getAuthenticatedUserId(req)!;
  await db.insert(userProfilesTable).values({ userId, displayName: "Member" }).onConflictDoNothing();
  const [row] = await db.select().from(userProfilesTable).where(eq(userProfilesTable.userId, userId));
  res.json(GetMyProfileResponse.parse(profile(userId, row)));
});

router.patch("/profile/me", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateMyProfileBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const userId = getAuthenticatedUserId(req)!;
  const data = {
    displayName: parsed.data.displayName.trim(),
    bio: parsed.data.bio.trim(),
    location: parsed.data.location.trim(),
  };
  if (data.displayName.length < 2) { res.status(400).json({ error: "Display name is too short" }); return; }
  const [row] = await db.insert(userProfilesTable)
    .values({ userId, ...data })
    .onConflictDoUpdate({ target: userProfilesTable.userId, set: { ...data, updatedAt: new Date() } })
    .returning();
  res.json(UpdateMyProfileResponse.parse(profile(userId, row)));
});

router.post("/profile/photo/upload-url", requireAuth, async (req, res): Promise<void> => {
  const parsed = RequestProfilePhotoUploadUrlBody.safeParse(req.body);
  if (!parsed.success || !PHOTO_TYPES.has(parsed.data.contentType) || parsed.data.size > MAX_PHOTO_BYTES) {
    res.status(400).json({ error: "Choose a JPG, PNG or WebP image under 3 MB" }); return;
  }
  const userId = getAuthenticatedUserId(req)!;
  const uploadURL = await objectStorage.getObjectEntityUploadURL(profilePhotoPrefix(userId));
  const objectPath = objectStorage.normalizeObjectEntityPath(uploadURL);
  res.json(RequestProfilePhotoUploadUrlResponse.parse({
    uploadURL, objectPath,
    metadata: { name: parsed.data.name, size: parsed.data.size, contentType: parsed.data.contentType },
  }));
});

router.patch("/profile/me/photo", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateMyProfilePhotoBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const userId = getAuthenticatedUserId(req)!;
  const path = parsed.data.avatarPath;
  if (path !== null) {
    const prefix = profilePhotoPrefix(userId);
    if (!new RegExp(`^/objects/${prefix}/[a-f0-9-]{36}$`).test(path)) {
      res.status(400).json({ error: "This photo was not uploaded for your profile" }); return;
    }
    try {
      const file = await objectStorage.getObjectEntityFile(path);
      const [metadata] = await file.getMetadata();
      if (!PHOTO_TYPES.has(metadata.contentType || "") ||
          !metadata.size || Number(metadata.size) > MAX_PHOTO_BYTES) {
        res.status(400).json({ error: "Choose a JPG, PNG or WebP image under 3 MB" }); return;
      }
    } catch (error) {
      if (error instanceof ObjectNotFoundError) {
        res.status(400).json({ error: "Upload the picture before saving it" }); return;
      }
      throw error;
    }
  }
  const [row] = await db.insert(userProfilesTable)
    .values({ userId, displayName: "Member", avatarPath: path })
    .onConflictDoUpdate({
      target: userProfilesTable.userId,
      set: { avatarPath: path, updatedAt: new Date() },
    }).returning();
  res.json(UpdateMyProfilePhotoResponse.parse(profile(userId, row)));
});

router.get("/profiles/:userId", async (req, res): Promise<void> => {
  const parsed = GetUserProfileParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const userId = parsed.data.userId;
  const [row] = await db.select().from(userProfilesTable).where(eq(userProfilesTable.userId, userId));
  if (!row) {
    const [listing] = await db.select({ id: listingsTable.id }).from(listingsTable)
      .where(eq(listingsTable.ownerId, userId)).limit(1);
    if (!listing) { res.status(404).json({ error: "Profile not found" }); return; }
  }
  res.json(GetUserProfileResponse.parse(profile(userId, row)));
});

async function conversationView(conversation: Conversation, currentUserId: string) {
  const otherUserId = conversation.buyerId === currentUserId ? conversation.sellerId : conversation.buyerId;
  const [other] = await db.select({ displayName: userProfilesTable.displayName })
    .from(userProfilesTable).where(eq(userProfilesTable.userId, otherUserId));
  return {
    id: conversation.id,
    listingId: conversation.listingId,
    listingTitle: conversation.listingTitle,
    buyerId: conversation.buyerId,
    sellerId: conversation.sellerId,
    otherUserId,
    otherUserName: other?.displayName ?? "Member",
    lastMessage: conversation.lastMessage,
    updatedAt: conversation.updatedAt,
  };
}

router.post("/listings/:id/conversations", requireAuth, async (req, res): Promise<void> => {
  const params = StartListingConversationParams.safeParse(req.params);
  const body = StartListingConversationBody.safeParse(req.body);
  if (!params.success || !body.success || !body.data.body.trim()) {
    res.status(400).json({ error: "A message is required" }); return;
  }
  const buyerId = getAuthenticatedUserId(req)!;
  const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, params.data.id));
  if (!listing || listing.status !== "active" || (listing.expiresAt && listing.expiresAt <= new Date()) ||
      !listing.ownerId || listing.attributes?.externalListing === true) {
    res.status(404).json({ error: "This seller is not available for messaging" }); return;
  }
  if (listing.ownerId === buyerId) {
    res.status(400).json({ error: "You cannot message yourself" }); return;
  }
  const conversation = await db.transaction(async tx => {
    await tx.insert(userProfilesTable).values([
      { userId: buyerId, displayName: "Member" },
      { userId: listing.ownerId!, displayName: "Member" },
    ]).onConflictDoNothing();
    await tx.insert(conversationsTable).values({
      id: randomUUID(), listingId: listing.id, listingTitle: listing.title,
      buyerId, sellerId: listing.ownerId!,
    }).onConflictDoNothing();
    const [thread] = await tx.select().from(conversationsTable)
      .where(and(eq(conversationsTable.listingId, listing.id), eq(conversationsTable.buyerId, buyerId)));
    const text = body.data.body.trim();
    await tx.insert(conversationMessagesTable).values({
      id: randomUUID(), conversationId: thread.id, senderId: buyerId, body: text,
    });
    const [updated] = await tx.update(conversationsTable).set({ lastMessage: text, updatedAt: new Date() })
      .where(eq(conversationsTable.id, thread.id)).returning();
    return updated;
  });
  res.status(201).json(StartListingConversationResponse.parse(await conversationView(conversation, buyerId)));
});

router.get("/conversations", requireAuth, async (req, res): Promise<void> => {
  const userId = getAuthenticatedUserId(req)!;
  const rows = await db.select().from(conversationsTable)
    .where(or(eq(conversationsTable.buyerId, userId), eq(conversationsTable.sellerId, userId)))
    .orderBy(desc(conversationsTable.updatedAt));
  res.json(ListConversationsResponse.parse(await Promise.all(rows.map(row => conversationView(row, userId)))));
});

router.get("/conversations/:id", requireAuth, async (req, res): Promise<void> => {
  const params = GetConversationParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const userId = getAuthenticatedUserId(req)!;
  const [conversation] = await db.select().from(conversationsTable)
    .where(and(eq(conversationsTable.id, params.data.id),
      or(eq(conversationsTable.buyerId, userId), eq(conversationsTable.sellerId, userId))));
  if (!conversation) { res.status(404).json({ error: "Conversation not found" }); return; }
  const messages = await db.select().from(conversationMessagesTable)
    .where(eq(conversationMessagesTable.conversationId, conversation.id))
    .orderBy(asc(conversationMessagesTable.createdAt));
  res.json(GetConversationResponse.parse({
    conversation: await conversationView(conversation, userId),
    messages,
  }));
});

router.post("/conversations/:id/messages", requireAuth, async (req, res): Promise<void> => {
  const params = SendConversationMessageParams.safeParse(req.params);
  const body = SendConversationMessageBody.safeParse(req.body);
  if (!params.success || !body.success || !body.data.body.trim()) {
    res.status(400).json({ error: "A message is required" }); return;
  }
  const userId = getAuthenticatedUserId(req)!;
  const [conversation] = await db.select().from(conversationsTable)
    .where(and(eq(conversationsTable.id, params.data.id),
      or(eq(conversationsTable.buyerId, userId), eq(conversationsTable.sellerId, userId))));
  if (!conversation) { res.status(404).json({ error: "Conversation not found" }); return; }
  const text = body.data.body.trim();
  const [message] = await db.transaction(async tx => {
    const inserted = await tx.insert(conversationMessagesTable).values({
      id: randomUUID(), conversationId: conversation.id, senderId: userId, body: text,
    }).returning();
    await tx.update(conversationsTable).set({ lastMessage: text, updatedAt: new Date() })
      .where(eq(conversationsTable.id, conversation.id));
    return inserted;
  });
  res.status(201).json(SendConversationMessageResponse.parse(message));
});

export default router;