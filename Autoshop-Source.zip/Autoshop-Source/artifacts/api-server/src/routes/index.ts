import { Router, type IRouter } from "express";
import healthRouter from "./health";
import listingsRouter from "./listings";
import locationsRouter from "./locations";
import storageRouter from "./storage";
import advertisingRouter from "./advertising";
import bannerAdvertisingRouter from "./bannerAdvertising";
import websiteAnalyticsRouter from "./websiteAnalytics";
import messagingRouter from "./messaging";

const router: IRouter = Router();

router.use(healthRouter);
router.use(listingsRouter);
router.use(locationsRouter);
router.use(storageRouter);
router.use(advertisingRouter);
router.use(bannerAdvertisingRouter);
router.use(websiteAnalyticsRouter);
router.use(messagingRouter);

export default router;
