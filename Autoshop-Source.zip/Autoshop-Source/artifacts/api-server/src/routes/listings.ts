import { randomUUID } from "node:crypto";
import { desc, eq, inArray, sql } from "drizzle-orm";
import { Router, type IRouter, type Request } from "express";
import { ReplitConnectors } from "@replit/connectors-sdk";
import { z } from "zod";
import {
  CreateInquiryBody,
  CreateInquiryParams,
  CreateInquiryResponse,
  CreateListingBody,
  CreateListingResponse,
  CreateSellerListingBody,
  CreateSellerListingResponse,
  CreateListingPremiumCheckoutParams,
  CreateListingPremiumCheckoutResponse,
  CancelSellerListingParams,
  CancelSellerListingResponse,
  DeleteSellerListingParams,
  GetListingParams,
  GetListingResponse,
  GetSellerListingResponse,
  GetListingPremiumStatusParams,
  GetListingPremiumStatusResponse,
  GetListingsSummaryResponse,
  ListListingsQueryParams,
  ListListingsResponse,
  ListSellerInquiriesResponse,
  ListSellerListingsResponse,
  type ListingInput,
  RenewSellerListingBody,
  RenewSellerListingResponse,
  RenewSellerListingParams,
  UpdateSellerListingBody,
  UpdateSellerListingParams,
  UpdateSellerListingResponse,
} from "@workspace/api-zod";
import {
  db,
  inquiriesTable,
  listingsTable,
  userProfilesTable,
  pool,
  type Listing,
} from "@workspace/db";
import { getAuthenticatedUserId, requireAdmin, requireAuth } from "../middlewares/auth";
import { currencyForCountry } from "../lib/currency";
import { storeImportedListingImages } from "../lib/importedListingImages";
import { ensurePremiumListingInventory } from "../lib/ensurePremiumListingInventory";
import { sendInquiryEmail } from "../lib/inquiryEmail";
import { sendListingCreatedEmail } from "../lib/listingCreatedEmail";
import { StripeConnectorError, stripeConnector } from "../stripeConnector";
import {
  isCustomBrand,
  normalizeRegisteredBrand,
  OTHER_BRAND_VALUE,
  getAttributeWithLegacyAliases,
} from "@workspace/api-zod";

const router: IRouter = Router();

const apifyRunResponseSchema = z.object({
  data: z.object({
    items: z.array(z.object({
      id: z.string(),
      defaultDatasetId: z.string(),
    })).min(1),
  }),
});

const kijijiDatasetItemSchema = z.object({
  adId: z.union([z.string(), z.number()]).transform(String),
  title: z.string().trim().min(1),
  priceAmount: z.coerce.number().finite().nonnegative(),
  currency: z.string().trim().length(3).default("CAD"),
  location: z.string().trim().min(1),
  latitude: z.coerce.number().finite().optional().nullable(),
  longitude: z.coerce.number().finite().optional().nullable(),
  postedDate: z.string().optional().nullable(),
  adType: z.string().optional().nullable(),
  url: z.string().url(),
  description: z.string().optional().nullable(),
  imageUrls: z.array(z.string().url()).max(20).default([]),
});

function importedCategory(text: string): string {
  const normalized = text.toLowerCase();
  if (normalized.includes("tire changer")) return "tire-changers";
  if (normalized.includes("wheel balancer") || normalized.includes("tire machine")) return "tire-service";
  if (normalized.includes("lift") || normalized.includes("hoist")) return "vehicle-lifts";
  return "shop-equipment";
}

function importedCondition(text: string): "new" | "used" {
  return /\b(new|brand new|unused)\b/i.test(text) ? "new" : "used";
}

async function getOrSeedListings(): Promise<Listing[]> {
  return db.select().from(listingsTable).orderBy(desc(listingsTable.createdAt));
}

function selectedValues(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.map(String).map(item => item.trim().toLowerCase()).filter(Boolean);
  }
  if (typeof value === "string") {
    return value.split(",").map(item => item.trim().toLowerCase()).filter(Boolean);
  }
  return [];
}

function listingAvailability(listing: Listing): string {
  if (listing.status === "sold") return "sold";
  const value = listing.attributes?.availability;
  if (typeof value === "string" && ["available", "pending", "sold"].includes(value.toLowerCase())) {
    return value.toLowerCase();
  }
  return listing.status === "active" ? "available" : listing.status;
}

/**
 * The normal board remains active-only. Explicit availability/status filters
 * opt into the corresponding lifecycle records, which makes Pending and Sold
 * real filters without changing the existing default marketplace semantics.
 */
export function publicListings(
  listings: Listing[],
  requestedStatus: string | undefined = undefined,
  requestedAvailability: unknown = undefined,
): Listing[] {
  const now = Date.now();
  const statuses = selectedValues(requestedStatus);
  const availability = selectedValues(requestedAvailability);
  const hasExplicitVisibility = statuses.length > 0 || availability.length > 0;

  return listings.filter((listing) => {
    // Expired and cancelled records are owner-private lifecycle history.
    // Explicit public availability is intentionally limited to pending/sold.
    if (listing.status === "cancelled" || listing.status === "expired") return false;
    if (!hasExplicitVisibility) {
      return listing.status === "active" &&
        listingAvailability(listing) !== "sold" &&
        (listing.expiresAt === null || listing.expiresAt.getTime() > now);
    }
    if (statuses.length > 0 && !statuses.includes(listing.status)) return false;
    if (availability.length > 0 && !availability.includes(listingAvailability(listing))) return false;
    if (statuses.includes("active") && listingAvailability(listing) === "sold" && !availability.includes("sold")) return false;
    if (listing.status === "active" && listing.expiresAt !== null && listing.expiresAt.getTime() <= now) {
      return statuses.includes("expired");
    }
    return true;
  });
}

function rotationHash(value: string): number {
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) {
    hash = Math.imul(31, hash) + value.charCodeAt(index) | 0;
  }
  return Math.abs(hash);
}

function rotatePremiumListings(listings: Listing[], rotationSeed = ""): Listing[] {
  const now = Date.now();
  const normalized = listings.map(listing =>
    listing.isPremium && (!listing.premiumExpiresAt || listing.premiumExpiresAt.getTime() <= now)
      ? { ...listing, isPremium: false }
      : listing,
  );
  const premium = normalized.filter(listing =>
    listing.isPremium &&
    listing.premiumExpiresAt !== null &&
    listing.premiumExpiresAt.getTime() > now
  );
  if (premium.length === 0) return normalized;
  const minute = Math.floor(now / 60_000);
  const offset = rotationHash(`${rotationSeed}:${minute}`) % premium.length;
  const featured = Array.from(
    { length: Math.min(3, premium.length) },
    (_, index) => premium[(offset + index) % premium.length],
  );
  const featuredIds = new Set(featured.map(listing => listing.id));
  return [...featured, ...normalized.filter(listing => !featuredIds.has(listing.id))];
}

type AttributeFilters = Record<string, unknown>;

function parseAttributeFilters(
  raw: string | undefined,
): { filters?: AttributeFilters; error?: string } {
  if (raw === undefined) {
    return { filters: {} };
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(raw) as unknown;
  } catch {
    return { error: "attributeFilters must be valid JSON" };
  }

  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
    return { error: "attributeFilters must be a JSON object" };
  }

  return { filters: parsed as AttributeFilters };
}

function scalarAttributeValues(attributes: Record<string, unknown>): string[] {
  return Object.values(attributes).flatMap((value) => {
    if (Array.isArray(value)) return value.filter(item => typeof item === "string" || typeof item === "number" || typeof item === "boolean").map(String);
    if (typeof value === "string" || typeof value === "boolean") return [String(value)];
    if (typeof value === "number" && Number.isFinite(value)) return [String(value)];
    return [];
  });
}

function normalizedBoolean(value: unknown): boolean | undefined {
  if (typeof value === "boolean") {
    return value;
  }
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") return true;
    if (normalized === "false") return false;
  }
  return undefined;
}

function scalarEquals(listingValue: unknown, selectedValue: unknown): boolean {
  const listingBoolean = normalizedBoolean(listingValue);
  const selectedBoolean = normalizedBoolean(selectedValue);
  if (listingBoolean !== undefined && selectedBoolean !== undefined) {
    return listingBoolean === selectedBoolean;
  }
  if (typeof listingValue === "string" && typeof selectedValue === "string") {
    return listingValue.toLowerCase().includes(selectedValue.trim().toLowerCase());
  }
  if (typeof listingValue === "number" && typeof selectedValue === "number") {
    return Number.isFinite(listingValue) && listingValue === selectedValue;
  }
  return listingValue === selectedValue;
}

function matchesManufacturerValue(
  listingValue: unknown,
  selectedValue: unknown,
  category: string,
  equipmentType: string,
): boolean {
  if (Array.isArray(listingValue)) {
    return listingValue.some(value => matchesManufacturerValue(value, selectedValue, category, equipmentType));
  }
  if (Array.isArray(selectedValue)) {
    return selectedValue.some(value => matchesManufacturerValue(listingValue, value, category, equipmentType));
  }
  if (selectedValue === OTHER_BRAND_VALUE) {
    return isCustomBrand(category, equipmentType, listingValue);
  }
  if (typeof listingValue === "string" && typeof selectedValue === "string") {
    return normalizeRegisteredBrand(listingValue) === normalizeRegisteredBrand(selectedValue);
  }
  return scalarEquals(listingValue, selectedValue);
}

function selectedQueryValues(value: string | undefined): string[] {
  return value
    ?.split(",")
    .map((item) => item.trim())
    .filter((item) => item.length > 0) ?? [];
}

function isRangeFilter(
  value: unknown,
): value is { min?: unknown; max?: unknown } {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    return false;
  }
  const keys = Object.keys(value);
  return (
    keys.length > 0 &&
    keys.every((key) => key === "min" || key === "max") &&
    ("min" in value || "max" in value)
  );
}

function matchesAttributeValue(
  listingValue: unknown,
  selectedValue: unknown,
): boolean {
  if (isRangeFilter(selectedValue)) {
    const numericListingValue =
      typeof listingValue === "number"
        ? listingValue
        : typeof listingValue === "string" && listingValue.trim() !== ""
          ? Number(listingValue)
          : NaN;
    if (!Number.isFinite(numericListingValue)) {
      return false;
    }
    if (
      "min" in selectedValue &&
      (typeof selectedValue.min !== "number" ||
        !Number.isFinite(selectedValue.min) ||
        numericListingValue < selectedValue.min)
    ) {
      return false;
    }
    if (
      "max" in selectedValue &&
      (typeof selectedValue.max !== "number" ||
        !Number.isFinite(selectedValue.max) ||
        numericListingValue > selectedValue.max)
    ) {
      return false;
    }
    return true;
  }

  if (Array.isArray(listingValue)) {
    if (Array.isArray(selectedValue)) {
      return selectedValue.some((selected) =>
        listingValue.some((value) => matchesAttributeValue(value, selected)),
      );
    }
    return listingValue.some((value) =>
      matchesAttributeValue(value, selectedValue),
    );
  }

  if (Array.isArray(selectedValue)) {
    return selectedValue.some((selected) =>
      matchesAttributeValue(listingValue, selected),
    );
  }

  return scalarEquals(listingValue, selectedValue);
}

function filterListings(
  listings: Listing[],
  query: ReturnType<typeof ListListingsQueryParams.parse>,
  attributeFilters: AttributeFilters = {},
): Listing[] {
  const search = query.search?.trim().toLowerCase();
  const categories = selectedQueryValues(query.category);
  const conditions = selectedQueryValues(query.condition);
  const equipmentTypes = selectedQueryValues(query.equipmentType);
  const queryAvailability = selectedQueryValues((query as { availability?: string }).availability);
  return listings.filter((listing) => {
    const attributes = listing.attributes ?? {};
    if (
      categories.length > 0 &&
      !categories.some((category) => {
        const normalizedCategory = category.toLowerCase();
        const normalizedListingCategory = listing.category.toLowerCase();
        return (
          normalizedListingCategory === normalizedCategory ||
          (normalizedCategory === "vehicle-lifts" &&
            normalizedListingCategory === "hoists")
        );
      })
    ) {
      return false;
    }
    if (
      conditions.length > 0 &&
      !conditions.some(
        (condition) => listing.condition.toLowerCase() === condition.toLowerCase(),
      )
    ) {
      return false;
    }
    if (query.status && listing.status !== query.status) return false;
    if (queryAvailability.length > 0 && !queryAvailability.includes(listingAvailability(listing))) {
      return false;
    }
    if (
      equipmentTypes.length > 0 &&
      !equipmentTypes.some((equipmentType) =>
        scalarEquals(attributes.equipmentType, equipmentType),
      )
    ) {
      return false;
    }
    if (!Object.entries(attributeFilters).every(([key, selectedValue]) => {
      if (Array.isArray(selectedValue) && selectedValue.length === 0) {
        return true;
      }
      if (key === "availability") {
        return matchesAttributeValue(listingAvailability(listing), selectedValue);
      }
      const listingValue =
        key === "manufacturer"
          ? attributes.manufacturer ?? attributes.brand
          : key === "model"
            ? attributes.model ?? attributes.modelNumber
            : getAttributeWithLegacyAliases(attributes, key);
      if (key === "manufacturer") {
        return matchesManufacturerValue(
          listingValue,
          selectedValue,
          listing.category,
          typeof attributes.equipmentType === "string" ? attributes.equipmentType : "",
        );
      }
      return matchesAttributeValue(listingValue, selectedValue);
    })) {
      return false;
    }
    if (query.minPrice !== undefined && listing.price < query.minPrice) return false;
    if (query.maxPrice !== undefined && listing.price > query.maxPrice) return false;
    if (
      search &&
      ![
        listing.title,
        listing.category,
        listing.location,
        listing.spec,
        listing.description ?? "",
        ...scalarAttributeValues(attributes),
      ]
        .join(" ")
        .toLowerCase()
        .includes(search)
    ) {
      return false;
    }
    if (query.latitude !== undefined && listing.latitude !== null) {
      const radius = query.radiusKm ?? 25;
      if (Math.abs(listing.latitude - query.latitude) > radius / 111) return false;
    }
    if (query.longitude !== undefined && listing.longitude !== null) {
      const radius = query.radiusKm ?? 25;
      if (Math.abs(listing.longitude - query.longitude) > radius / 111) return false;
    }
    return true;
  });
}

function listingValues(
  input: {
    title: string;
    category: string;
    condition: string;
    price: number;
    location: string;
    latitude?: number;
    longitude?: number;
    spec: string;
    description?: string;
    attributes?: Record<string, unknown>;
    contact: string;
    image?: string | null;
    imagePaths?: string[];
    status?: "active" | "expired" | "sold";
    expiresAt?: Date | null;
    countryCode?: string;
    currencyCode?: string;
  },
  ownerId: string,
) {
  return {
    id: randomUUID(),
    ownerId,
    title: input.title,
    category: input.category,
    condition: input.condition,
    price: input.price,
    location: input.location,
    latitude: input.latitude ?? null,
    longitude: input.longitude ?? null,
    countryCode: input.countryCode ?? "CA",
    currencyCode: currencyForCountry(input.countryCode ?? "CA"),
    spec: input.spec,
    description: input.description ?? null,
    attributes: input.attributes ?? {},
    contact: input.contact,
    image: input.image ?? null,
    imagePaths: input.imagePaths ?? [],
    status: input.status ?? "active",
    expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
  };
}

function validationError(
  params: { success: false; error: { message: string } } | undefined,
  body: { success: false; error: { message: string } } | undefined,
): string {
  return params?.error.message ?? body?.error.message ?? "Invalid request";
}

async function ownedListing(
  id: string,
  ownerId: string,
): Promise<{ listing: Listing | undefined; forbidden: boolean }> {
  const [listing] = await db
    .select()
    .from(listingsTable)
    .where(eq(listingsTable.id, id));
  return { listing, forbidden: Boolean(listing && listing.ownerId !== ownerId) };
}

async function withSellerProfiles(listings: Listing[]) {
  const sellerIds = [...new Set(listings
    .filter(listing => listing.ownerId && listing.attributes?.externalListing !== true)
    .map(listing => listing.ownerId!))];
  const profiles = sellerIds.length
    ? await db.select({
        userId: userProfilesTable.userId,
        displayName: userProfilesTable.displayName,
        avatarPath: userProfilesTable.avatarPath,
      }).from(userProfilesTable).where(inArray(userProfilesTable.userId, sellerIds))
    : [];
  const byId = new Map(profiles.map(profile => [profile.userId, profile]));
  return listings.map(listing => ({
    ...listing,
    sellerProfile: listing.ownerId && listing.attributes?.externalListing !== true
      ? {
          displayName: byId.get(listing.ownerId)?.displayName ?? "Member",
          avatarPath: byId.get(listing.ownerId)?.avatarPath ?? null,
        }
      : null,
  }));
}

router.get("/listings", async (req, res): Promise<void> => {
  const parsed = ListListingsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const parsedAttributeFilters = parseAttributeFilters(
    parsed.data.attributeFilters,
  );
  if (parsedAttributeFilters.error) {
    res.status(400).json({ error: parsedAttributeFilters.error });
    return;
  }
  const allListings = await getOrSeedListings();
  const listings = filterListings(
    publicListings(
      allListings,
      parsed.data.status,
      (parsedAttributeFilters.filters as Record<string, unknown> | undefined)?.availability ??
        (parsed.data as { availability?: string }).availability,
    ),
    parsed.data,
    parsedAttributeFilters.filters,
  );
  res.json(ListListingsResponse.parse(await withSellerProfiles(rotatePremiumListings(listings, parsed.data.rotationSeed))));
});

router.get("/listings/summary", async (_req, res): Promise<void> => {
  const listings = publicListings(await getOrSeedListings());
  const byCategory = listings.reduce<Record<string, number>>((counts, listing) => {
    counts[listing.category] = (counts[listing.category] ?? 0) + 1;
    return counts;
  }, {});
  res.json(GetListingsSummaryResponse.parse({ total: listings.length, byCategory }));
});

router.post("/admin/imports/apify/latest", requireAdmin, async (req, res): Promise<void> => {
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  try {
    const connectors = new ReplitConnectors();
    const runsResponse = await connectors.proxy(
      "apify",
      "/v2/actor-runs?status=SUCCEEDED&desc=1&limit=1",
      { method: "GET" },
    );
    if (!runsResponse.ok) {
      req.log.error({ status: runsResponse.status }, "Unable to read Apify runs");
      res.status(502).json({ error: "Apify did not return a usable completed run." });
      return;
    }

    const runs = apifyRunResponseSchema.parse(await runsResponse.json());
    const run = runs.data.items[0];
    const datasetResponse = await connectors.proxy(
      "apify",
      `/v2/datasets/${encodeURIComponent(run.defaultDatasetId)}/items?format=json&clean=true&limit=100`,
      { method: "GET" },
    );
    if (!datasetResponse.ok) {
      req.log.error({ status: datasetResponse.status }, "Unable to read Apify dataset");
      res.status(502).json({ error: "Apify did not return the scraper dataset." });
      return;
    }

    const rawItems = z.array(z.unknown()).parse(await datasetResponse.json());
    const parsedItems = rawItems.map(item => kijijiDatasetItemSchema.safeParse(item));
    const validItems = parsedItems.flatMap(result => result.success ? [result.data] : []);
    const values = await Promise.all(validItems.map(async item => {
      const searchableText = `${item.title} ${item.description ?? ""}`;
      const listingId = `kijiji-${item.adId}`;
      const imagePaths = await storeImportedListingImages(listingId, item.imageUrls);
      return {
        id: listingId,
        ownerId,
        title: item.title,
        category: importedCategory(searchableText),
        condition: importedCondition(searchableText),
        price: item.priceAmount,
        location: item.location,
        latitude: item.latitude ?? null,
        longitude: item.longitude ?? null,
        countryCode: "CA",
        currencyCode: item.currency.toUpperCase(),
        spec: "External equipment listing · specifications must be confirmed through an inquiry",
        description: `${item.title} is advertised in ${item.location}. Price, availability, condition, and specifications must be confirmed with the source seller before purchase.`,
        attributes: {
          availability: "available",
          externalListing: true,
          sourcePlatform: "Kijiji",
          sourceListingId: item.adId,
          sourceUrl: item.url,
          sourcePostedAt: item.postedDate ?? null,
          sourceAdType: item.adType ?? null,
          inquiryMode: "autoshop-source-relay",
          sellerManaged: false,
          importedAt: new Date().toISOString(),
        },
        contact: "Autoshop Source inquiry relay",
        image: null,
        imagePaths,
        status: "active" as const,
        expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
      };
    }));

    const inserted = values.length > 0
      ? await db.insert(listingsTable).values(values).onConflictDoUpdate({
          target: listingsTable.id,
          set: {
            imagePaths: sql`excluded.image_paths`,
            updatedAt: new Date(),
          },
        }).returning({ id: listingsTable.id })
      : [];

    res.json({
      runId: run.id,
      datasetId: run.defaultDatasetId,
      received: rawItems.length,
      valid: validItems.length,
      imported: inserted.length,
      skipped: rawItems.length - validItems.length,
    });
  } catch (error) {
    req.log.error({ err: error }, "Kijiji dataset import failed");
    res.status(502).json({ error: "The Apify dataset could not be imported." });
  }
});

router.get("/listings/:id", async (req, res): Promise<void> => {
  const params = GetListingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const requestedAvailability =
    typeof req.query.availability === "string" ? req.query.availability : undefined;
  const listing = publicListings(await getOrSeedListings(), undefined, requestedAvailability).find(
    (item) => item.id === params.data.id,
  );
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  res.json(GetListingResponse.parse((await withSellerProfiles([listing]))[0]));
});

async function createListing(
  ownerId: string,
  input: ListingInput,
  req: Request,
) {
  const [listing] = await db
    .insert(listingsTable)
    .values(listingValues(input, ownerId))
    .returning();
  try {
    await sendListingCreatedEmail(listing);
  } catch (error) {
    // The listing was saved. Returning an error would encourage a duplicate submission.
    req.log.error({ err: error, listingId: listing.id }, "Listing saved but owner notification was not sent");
  }
  return listing;
}

router.post("/listings", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateListingBody.safeParse(req.body);
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  res.status(201).json(CreateListingResponse.parse(await createListing(ownerId, parsed.data, req)));
});

router.get("/seller/listings", requireAuth, async (req, res): Promise<void> => {
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const pending = await db.select({ id: listingsTable.id }).from(listingsTable)
    .where(sql`${listingsTable.ownerId}=${ownerId} AND ${listingsTable.premiumCheckoutSessionId} IS NOT NULL AND ${listingsTable.isPremium}=false`);
  // A missing or temporarily unreachable Stripe session must not hide the seller's
  // listings. Keep the payment pending so a later request can still reconcile it.
  await Promise.all(pending.map(async row => {
    try {
      await reconcilePremiumListing(row.id);
    } catch (error) {
      req.log.warn({ err: error, listingId: row.id }, "Premium checkout reconciliation failed while loading seller listings");
    }
  }));
  await db.update(listingsTable).set({ status: "expired" }).where(
    sql`${listingsTable.ownerId}=${ownerId} AND ${listingsTable.status}='active' AND ${listingsTable.expiresAt} <= now()`,
  );
  const listings = await db
    .select()
    .from(listingsTable)
    .where(eq(listingsTable.ownerId, ownerId))
    .orderBy(desc(listingsTable.updatedAt));
  res.json(ListSellerListingsResponse.parse(listings));
});

router.get("/seller/listings/:id", requireAuth, async (req, res): Promise<void> => {
  const params = GetListingParams.safeParse(req.params);
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const ownership = await ownedListing(params.data.id, ownerId);
  if (!ownership.listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  if (ownership.forbidden) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  res.json(GetSellerListingResponse.parse(ownership.listing));
});

router.post("/seller/listings", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateSellerListingBody.safeParse(req.body);
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const listing = await createListing(ownerId, parsed.data, req);
  res.status(201).json(CreateSellerListingResponse.parse(listing));
});

router.patch("/seller/listings/:id", requireAuth, async (req, res): Promise<void> => {
  const params = UpdateSellerListingParams.safeParse(req.params);
  const parsed = UpdateSellerListingBody.safeParse(req.body);
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: validationError(
        params.success ? undefined : params,
        parsed.success ? undefined : parsed,
      ),
    });
    return;
  }
  const ownership = await ownedListing(params.data.id, ownerId);
  if (!ownership.listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  if (ownership.forbidden) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  const { countryCode, currencyCode: _currencyCode, ...fields } = parsed.data;
  const locationFields =
    countryCode === undefined
      ? {}
      : {
          countryCode,
          currencyCode: currencyForCountry(countryCode),
        };
  if (Object.keys(fields).length === 0 && countryCode === undefined) {
    res.json(UpdateSellerListingResponse.parse(ownership.listing));
    return;
  }
  const [listing] = await db
    .update(listingsTable)
    .set({ ...fields, ...locationFields })
    .where(eq(listingsTable.id, params.data.id))
    .returning();
  res.json(UpdateSellerListingResponse.parse(listing));
});

router.delete("/seller/listings/:id", requireAuth, async (req, res): Promise<void> => {
  const params = DeleteSellerListingParams.safeParse(req.params);
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const ownership = await ownedListing(params.data.id, ownerId);
  if (!ownership.listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  if (ownership.forbidden) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  await closeOpenPremiumSessions(params.data.id);
  await db.delete(listingsTable).where(eq(listingsTable.id, params.data.id));
  res.sendStatus(204);
});

router.post("/seller/listings/:id/cancel", requireAuth, async (req, res): Promise<void> => {
  const params = CancelSellerListingParams.safeParse(req.params);
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const ownership = await ownedListing(params.data.id, ownerId);
  if (!ownership.listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  if (ownership.forbidden) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  await closeOpenPremiumSessions(params.data.id);
  const [listing] = await db
    .update(listingsTable)
    .set({ status: "cancelled", updatedAt: new Date() })
    .where(eq(listingsTable.id, params.data.id))
    .returning();
  res.json(CancelSellerListingResponse.parse(listing));
});

router.post("/seller/listings/:id/renew", requireAuth, async (req, res): Promise<void> => {
  const params = RenewSellerListingParams.safeParse(req.params);
  const parsed = RenewSellerListingBody.safeParse(req.body ?? {});
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: validationError(
        params.success ? undefined : params,
        parsed.success ? undefined : parsed,
      ),
    });
    return;
  }
  const ownership = await ownedListing(params.data.id, ownerId);
  if (!ownership.listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  if (ownership.forbidden) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  const [listing] = await db
    .update(listingsTable)
    .set({
      status: "active",
      attributes: {
        ...(ownership.listing.attributes ?? {}),
        availability: "available",
      },
      expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
      isPremium: false,
      premiumCheckoutSessionId: null,
      premiumPaymentIntentId: null,
      premiumPaidAt: null,
      premiumExpiresAt: null,
    })
    .where(eq(listingsTable.id, params.data.id))
    .returning();
  res.json(RenewSellerListingResponse.parse(listing));
});

async function reconcilePremiumListing(listingId: string): Promise<void> {
  let [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, listingId));
  if (!listing) return;
  if (listing.isPremium && listing.premiumExpiresAt && listing.premiumExpiresAt.getTime() <= Date.now()) {
    [listing] = await db.update(listingsTable).set({
      isPremium: false,
      premiumCheckoutSessionId: null,
      premiumPaymentIntentId: null,
      premiumPaidAt: null,
      premiumExpiresAt: null,
    }).where(eq(listingsTable.id, listingId)).returning();
  }
  if (listing.isPremium) return;

  const attempts = (await pool.query<{
    id: string;
    owner_id: string;
    stripe_checkout_session_id: string;
    amount_minor: number;
    currency: string;
  }>(
    "SELECT id,owner_id,stripe_checkout_session_id,amount_minor,currency FROM listing_premium_payments WHERE listing_id=$1 AND status='pending' ORDER BY created_at",
    [listingId],
  )).rows;

  for (const attempt of attempts) {
    const session = await stripeConnector.retrieveCheckoutSession(attempt.stripe_checkout_session_id);
    if (session.payment_status !== "paid") {
      if (session.status === "expired") {
        await pool.query("UPDATE listing_premium_payments SET status='expired' WHERE id=$1 AND status='pending'", [attempt.id]);
      }
      continue;
    }
    const metadata = session.metadata && typeof session.metadata === "object"
      ? session.metadata as Record<string, unknown>
      : {};
    const paymentIntentId = typeof session.payment_intent === "string" ? session.payment_intent : null;
    const valid =
      session.mode === "payment" &&
      session.amount_total === attempt.amount_minor &&
      String(session.currency).toUpperCase() === attempt.currency &&
      metadata["listingId"] === listingId &&
      metadata["userId"] === attempt.owner_id &&
      metadata["productType"] === "premiumListing" &&
      session.client_reference_id === listingId &&
      paymentIntentId !== null;
    if (!valid) {
      await pool.query("UPDATE listing_premium_payments SET status='invalid' WHERE id=$1 AND status='pending'", [attempt.id]);
      continue;
    }
    const paidAt = new Date(typeof session.created === "number" ? session.created * 1000 : Date.now());
    const activated = await pool.query(
      `UPDATE listings SET is_premium=true,premium_paid_at=$2,premium_expires_at=expires_at,
        premium_payment_intent_id=$3,premium_checkout_session_id=$4,updated_at=now()
       WHERE id=$1 AND owner_id=$5 AND status='active' AND expires_at>now() AND is_premium=false
       RETURNING id`,
      [listingId, paidAt, paymentIntentId, attempt.stripe_checkout_session_id, attempt.owner_id],
    );
    await pool.query(
      "UPDATE listing_premium_payments SET status=$2,stripe_payment_intent_id=$3,paid_at=$4 WHERE id=$1 AND status='pending'",
      [attempt.id, activated.rowCount ? "paid" : "paid_ineligible", paymentIntentId, paidAt],
    );
    if (activated.rowCount) return;
  }
}

async function closeOpenPremiumSessions(listingId: string): Promise<void> {
  await reconcilePremiumListing(listingId);
  const attempts = (await pool.query<{ id: string; stripe_checkout_session_id: string }>(
    "SELECT id,stripe_checkout_session_id FROM listing_premium_payments WHERE listing_id=$1 AND status='pending'",
    [listingId],
  )).rows;
  for (const attempt of attempts) {
    const session = await stripeConnector.retrieveCheckoutSession(attempt.stripe_checkout_session_id);
    if (session.status === "open") await stripeConnector.expireCheckoutSession(attempt.stripe_checkout_session_id);
    await pool.query("UPDATE listing_premium_payments SET status='expired' WHERE id=$1 AND status='pending'", [attempt.id]);
  }
}

function checkoutFrontendBase(req: Request): string {
  const requestOrigin = `${req.protocol}://${req.get("host")}`;
  const configured = process.env["PUBLIC_APP_URL"];
  if (configured) return configured.replace(/\/$/, "");
  const referer = req.get("referer");
  if (!referer) return requestOrigin;
  try {
    const url = new URL(referer);
    if (url.origin !== requestOrigin) return requestOrigin;
    const match = url.pathname.match(/^(.*)\/seller(?:\/|$)/);
    return `${url.origin}${match?.[1] ?? ""}`.replace(/\/$/, "");
  } catch {
    return requestOrigin;
  }
}

router.post("/seller/listings/:id/premium-checkout", requireAuth, async (req, res): Promise<void> => {
  const params = CreateListingPremiumCheckoutParams.safeParse(req.params);
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) { res.status(401).json({ error: "Unauthorized" }); return; }
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const ownership = await ownedListing(params.data.id, ownerId);
  if (!ownership.listing) { res.status(404).json({ error: "Listing not found" }); return; }
  if (ownership.forbidden) { res.status(403).json({ error: "Forbidden" }); return; }
  await reconcilePremiumListing(params.data.id);
  const stripePriceId = await ensurePremiumListingInventory();
  const frontendBase = checkoutFrontendBase(req);
  const client = await pool.connect();
  let createdSessionId: string | null = null;
  try {
    await client.query("BEGIN");
    const listing = (await client.query<{
      id: string; owner_id: string; status: string; expires_at: Date; is_premium: boolean;
    }>("SELECT id,owner_id,status,expires_at,is_premium FROM listings WHERE id=$1 FOR UPDATE", [params.data.id])).rows[0];
    if (!listing) { await client.query("ROLLBACK"); res.status(404).json({ error: "Listing not found" }); return; }
    if (listing.owner_id !== ownerId) { await client.query("ROLLBACK"); res.status(403).json({ error: "Forbidden" }); return; }
    if (listing.status !== "active" || listing.expires_at.getTime() <= Date.now()) {
      await client.query("ROLLBACK");
      res.status(409).json({ error: "Only active, unexpired listings can be made premium" });
      return;
    }
    if (listing.is_premium) { await client.query("ROLLBACK"); res.status(409).json({ error: "This listing is already premium" }); return; }
    const existingAttempt = (await client.query<{ stripe_checkout_session_id: string }>(
      "SELECT stripe_checkout_session_id FROM listing_premium_payments WHERE listing_id=$1 AND status='pending' ORDER BY created_at DESC LIMIT 1",
      [listing.id],
    )).rows[0];
    if (existingAttempt) {
      const existing = await stripeConnector.retrieveCheckoutSession(existingAttempt.stripe_checkout_session_id);
      if (existing.status === "open" && typeof existing.url === "string") {
        await client.query("COMMIT");
        res.status(201).json(CreateListingPremiumCheckoutResponse.parse({ listingId: listing.id, checkoutUrl: existing.url }));
        return;
      }
      await client.query("UPDATE listing_premium_payments SET status='expired' WHERE stripe_checkout_session_id=$1", [existingAttempt.stripe_checkout_session_id]);
    }
    const values = {
      mode: "payment",
      "line_items[0][price]": stripePriceId,
      "line_items[0][quantity]": "1",
      success_url: `${frontendBase}/seller/premium-checkout?listing_id=${listing.id}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${frontendBase}/seller?premium_cancelled=1`,
      "metadata[listingId]": listing.id,
      "metadata[userId]": ownerId,
      "metadata[productType]": "premiumListing",
      client_reference_id: listing.id,
    };
    let session;
    try {
      session = await stripeConnector.createCheckoutSession(values);
    } catch (error) {
      if (!(error instanceof StripeConnectorError) || error.stripeCode !== "resource_missing") throw error;
      const repairedPriceId = await ensurePremiumListingInventory();
      session = await stripeConnector.createCheckoutSession({ ...values, "line_items[0][price]": repairedPriceId });
    }
    if (typeof session.id !== "string" || typeof session.url !== "string") throw new Error("Invalid Stripe Checkout response");
    createdSessionId = session.id;
    await client.query(
      `INSERT INTO listing_premium_payments
        (id,listing_id,owner_id,stripe_checkout_session_id,amount_minor,currency,status)
       VALUES ($1,$2,$3,$4,999,'CAD','pending')`,
      [randomUUID(), listing.id, ownerId, session.id],
    );
    await client.query("UPDATE listings SET premium_checkout_session_id=$2,updated_at=now() WHERE id=$1", [listing.id, session.id]);
    await client.query("COMMIT");
    res.status(201).json(CreateListingPremiumCheckoutResponse.parse({ listingId: listing.id, checkoutUrl: session.url }));
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    if (createdSessionId) await stripeConnector.expireCheckoutSession(createdSessionId).catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
});

router.get("/seller/listings/:id/premium-status", requireAuth, async (req, res): Promise<void> => {
  const params = GetListingPremiumStatusParams.safeParse(req.params);
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) { res.status(401).json({ error: "Unauthorized" }); return; }
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const ownership = await ownedListing(params.data.id, ownerId);
  if (!ownership.listing) { res.status(404).json({ error: "Listing not found" }); return; }
  if (ownership.forbidden) { res.status(403).json({ error: "Forbidden" }); return; }
  await reconcilePremiumListing(params.data.id);
  const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, params.data.id));
  res.json(GetListingPremiumStatusResponse.parse(listing));
});

router.post("/listings/:id/inquiries", async (req, res): Promise<void> => {
  const params = CreateInquiryParams.safeParse(req.params);
  const parsed = CreateInquiryBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({
      error: validationError(
        params.success ? undefined : params,
        parsed.success ? undefined : parsed,
      ),
    });
    return;
  }
  const [listing] = await db
    .select()
    .from(listingsTable)
    .where(eq(listingsTable.id, params.data.id));
  if (!listing || publicListings([listing]).length === 0) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  const [inquiry] = await db
    .insert(inquiriesTable)
    .values({ id: randomUUID(), listingId: listing.id, ...parsed.data })
    .returning();
  try {
    await sendInquiryEmail(listing, inquiry);
  } catch (error) {
    // The inquiry is already saved. Do not turn a retry into a duplicate message.
    req.log.error({ err: error, inquiryId: inquiry.id, listingId: listing.id }, "Inquiry saved but seller email was not sent");
  }
  res.status(201).json(CreateInquiryResponse.parse(inquiry));
});

router.get("/seller/inquiries", requireAuth, async (req, res): Promise<void> => {
  const ownerId = getAuthenticatedUserId(req);
  if (!ownerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const inquiries = await db
    .select({
      id: inquiriesTable.id,
      listingId: inquiriesTable.listingId,
      name: inquiriesTable.name,
      email: inquiriesTable.email,
      message: inquiriesTable.message,
      createdAt: inquiriesTable.createdAt,
    })
    .from(inquiriesTable)
    .innerJoin(listingsTable, eq(inquiriesTable.listingId, listingsTable.id))
    .where(eq(listingsTable.ownerId, ownerId))
    .orderBy(desc(inquiriesTable.createdAt));
  res.json(ListSellerInquiriesResponse.parse(inquiries));
});

export default router;