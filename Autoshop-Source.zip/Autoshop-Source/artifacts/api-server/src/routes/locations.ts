import { Router, type IRouter } from "express";
import { ReverseLocationQueryParams, ReverseLocationResponse, SearchLocationsQueryParams, SearchLocationsResponse } from "@workspace/api-zod";
import { currencyForCountry } from "../lib/currency";

const router: IRouter = Router();
const PHOTON_URL = "https://photon.komoot.io/api";
const CACHE_TTL_MS = 60_000;
const MAX_CACHE_ENTRIES = 100;
const cache = new Map<string, { expiresAt: number; value: unknown }>();

type PhotonFeature = {
  geometry?: { coordinates?: unknown };
  properties?: Record<string, unknown>;
};

function stringProperty(properties: Record<string, unknown>, ...keys: string[]): string | null {
  for (const key of keys) {
    const value = properties[key];
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return null;
}

function addUniqueComponent(components: string[], value: string | null): void {
  if (!value) return;
  const normalized = value.toLocaleLowerCase();
  if (!components.some((component) => component.toLocaleLowerCase() === normalized)) {
    components.push(value);
  }
}

function comparableText(value: string | null): string {
  return (value ?? "").toLocaleLowerCase().replace(/[^a-z0-9]+/g, "");
}

function comparableAddress(value: string | null): string {
  return (value ?? "")
    .toLocaleLowerCase()
    .replace(/\bstreet\b/g, "st")
    .replace(/\bavenue\b/g, "ave")
    .replace(/\broad\b/g, "rd")
    .replace(/\bhighway\b/g, "hwy")
    .replace(/\bwest\b/g, "w")
    .replace(/\beast\b/g, "e")
    .replace(/\bnorth\b/g, "n")
    .replace(/\bsouth\b/g, "s")
    .replace(/[^a-z0-9]+/g, "");
}

function isDuplicateName(name: string, components: string[]): boolean {
  const comparableName = comparableText(name);
  if (!comparableName) return true;
  const comparableNameAsAddress = comparableAddress(name);
  return components.some(
    (component) =>
      comparableText(component) === comparableName ||
      comparableAddress(component) === comparableNameAsAddress,
  );
}

function normalizeFeature(feature: PhotonFeature) {
  const properties = feature.properties ?? {};
  const coordinates = feature.geometry?.coordinates;
  if (
    !Array.isArray(coordinates) ||
    typeof coordinates[0] !== "number" ||
    typeof coordinates[1] !== "number" ||
    !Number.isFinite(coordinates[0]) ||
    !Number.isFinite(coordinates[1])
  ) {
    return null;
  }

  const country = stringProperty(properties, "country");
  const countryCode = stringProperty(properties, "countrycode")?.toUpperCase();
  if (!country || !countryCode || !/^[A-Z]{2}$/.test(countryCode)) return null;

  const city = stringProperty(properties, "city", "town", "village", "municipality");
  const region = stringProperty(properties, "state", "region");
  const houseNumber = stringProperty(properties, "housenumber", "house_number");
  const street = stringProperty(properties, "street", "road");
  const providerPostalCode = stringProperty(properties, "postcode", "postalcode", "postal_code");
  const providerType = stringProperty(properties, "osm_value", "type")?.toLocaleLowerCase();
  const isPostalFeature = providerType === "postcode" || providerType === "postal_code";
  const comparablePostalCode = comparableText(providerPostalCode);
  const containsProviderPostalCode = (value: string | null): boolean =>
    comparablePostalCode.length >= 4 && comparableText(value).includes(comparablePostalCode);
  const name = stringProperty(properties, "name", "official_name", "housename");
  const addressLine = [houseNumber, street].filter(Boolean).join(" ");
  const components: string[] = [];
  if (!containsProviderPostalCode(addressLine || street)) addUniqueComponent(components, addressLine || street);
  if (!containsProviderPostalCode(city)) addUniqueComponent(components, city);
  if (!containsProviderPostalCode(region)) addUniqueComponent(components, region);
  if (!containsProviderPostalCode(country)) addUniqueComponent(components, country);
  const labelParts = components.join(", ");
  const label = name && !isPostalFeature && !containsProviderPostalCode(name) && !isDuplicateName(name, components)
    ? (labelParts ? `${name} — ${labelParts}` : name)
    : labelParts;
  if (!label) return null;

  return {
    label,
    city,
    region,
    country,
    countryCode,
    latitude: coordinates[1],
    longitude: coordinates[0],
    currencyCode: currencyForCountry(countryCode),
  };
}

function featureRelevance(feature: PhotonFeature, query: string): number {
  const properties = feature.properties ?? {};
  const houseNumber = stringProperty(properties, "housenumber", "house_number");
  const street = stringProperty(properties, "street", "road");
  const name = stringProperty(properties, "name", "official_name", "housename");
  const queryComparable = comparableText(query);
  const candidateParts = [
    name,
    houseNumber,
    street,
    stringProperty(properties, "city", "town", "village"),
  ];
  const candidateComparable = candidateParts.map(comparableText).filter(Boolean);
  const candidateText = candidateComparable.join("");
  const queryTokens = query.toLocaleLowerCase().match(/[a-z0-9]+/g) ?? [];
  const queryHouseNumber = query.match(/(?:^|\s)(\d+[a-z]?)(?:\s|$)/i)?.[1].toLowerCase();
  let score = 0;

  // Keep Photon ordering as the tie-breaker, but put an exact address match
  // ahead of nearby/fuzzy results when the provider supplies it.
  if (candidateComparable.some((part) => part === queryComparable)) score += 100;
  if (queryComparable && candidateText.includes(queryComparable)) score += 40;
  if (queryTokens.length > 0 && queryTokens.every((token) => candidateText.includes(token))) score += 20;
  if (queryHouseNumber) {
    if (comparableText(houseNumber) === queryHouseNumber) score += 35;
    else if (houseNumber) score -= 10;
  }
  if (street && queryTokens.some((token) => comparableText(street).includes(token))) score += 10;
  return score;
}

router.get("/locations/search", async (req, res): Promise<void> => {
  const parsed = SearchLocationsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const q = parsed.data.q.trim();
  if (q.length < 2) {
    res.status(400).json({ error: "q must contain at least 2 non-whitespace characters" });
    return;
  }
  const cacheKey = q.toLowerCase();
  const cached = cache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) {
    res.json(SearchLocationsResponse.parse(cached.value));
    return;
  }
  if (cached) cache.delete(cacheKey);

  try {
    const url = new URL(PHOTON_URL);
    url.searchParams.set("q", q);
    url.searchParams.set("limit", "8");
    url.searchParams.set("lang", "en");
    const upstream = await fetch(url, {
      signal: AbortSignal.timeout(5_000),
      headers: { "User-Agent": "AutoshopSource/1.0 (location search)" },
    });
    if (!upstream.ok) {
      res.status(502).json({ error: `Location provider returned HTTP ${upstream.status}` });
      return;
    }
    const payload: unknown = await upstream.json();
    if (
      payload === null ||
      typeof payload !== "object" ||
      !("features" in payload) ||
      !Array.isArray((payload as { features?: unknown }).features)
    ) {
      res.status(502).json({ error: "Location provider returned an invalid response" });
      return;
    }
    const features = (payload as { features: PhotonFeature[] }).features;
    const seen = new Set<string>();
    const suggestions = features
      .filter((feature) => {
        const properties = feature.properties ?? {};
        const value = properties.osm_value;
        const type = properties.type;
        const usefulTypes = [
          "address",
          "house",
          "street",
          "residential",
          "road",
          "postcode",
          "place",
          "city",
          "town",
          "village",
          "municipality",
          "locality",
          "district",
          "state",
          "country",
        ];
        return (
          (typeof value === "string" && usefulTypes.includes(value.toLowerCase())) ||
          (typeof type === "string" && usefulTypes.includes(type.toLowerCase())) ||
          Boolean(
            stringProperty(
              properties,
              "street",
              "housenumber",
              "house_number",
              "postcode",
              "postalcode",
              "name",
            ),
          )
        );
      })
      .map((feature, index) => ({
        feature,
        index,
        suggestion: normalizeFeature(feature),
        relevance: featureRelevance(feature, q),
      }))
      .filter(
        (entry): entry is {
          feature: PhotonFeature;
          index: number;
          suggestion: NonNullable<ReturnType<typeof normalizeFeature>>;
          relevance: number;
        } => entry.suggestion !== null,
      )
      .sort((left, right) => right.relevance - left.relevance || left.index - right.index)
      .map(({ suggestion }) => suggestion)
      .filter((suggestion) => {
        const key = suggestion.label.toLocaleLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .slice(0, 8);
    const result = SearchLocationsResponse.parse(suggestions);
    cache.set(cacheKey, { expiresAt: Date.now() + CACHE_TTL_MS, value: result });
    while (cache.size > MAX_CACHE_ENTRIES) cache.delete(cache.keys().next().value as string);
    res.json(result);
  } catch (error) {
    const message =
      error instanceof Error &&
      (error.name === "AbortError" || error.name === "TimeoutError")
      ? "Location provider timed out"
      : "Unable to reach location provider";
    req.log.warn({ error }, message);
    res.status(502).json({ error: message });
  }
});

router.get("/locations/reverse", async (req, res): Promise<void> => {
  const parsed = ReverseLocationQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a valid latitude and longitude." });
    return;
  }
  const { latitude, longitude } = parsed.data;
  try {
    const url = new URL("https://photon.komoot.io/reverse");
    url.searchParams.set("lat", String(latitude));
    url.searchParams.set("lon", String(longitude));
    url.searchParams.set("lang", "en");
    url.searchParams.set("limit", "8");
    const upstream = await fetch(url, {
      signal: AbortSignal.timeout(5_000),
      headers: { "User-Agent": "AutoshopSource/1.0 (nearby city)" },
    });
    if (!upstream.ok) {
      res.status(502).json({ error: "Nearby locations are unavailable right now." });
      return;
    }
    const payload: unknown = await upstream.json();
    if (!payload || typeof payload !== "object" || !("features" in payload) || !Array.isArray(payload.features)) {
      res.status(502).json({ error: "Could not read the nearby location." });
      return;
    }
    // Never expose a street address or the exact device coordinates in a public profile/listing.
    const nearby = (payload.features as PhotonFeature[])
      .map(feature => {
        const properties = feature.properties ?? {};
        const city = stringProperty(properties, "city", "town", "village", "municipality");
        const region = stringProperty(properties, "state", "region");
        const country = stringProperty(properties, "country");
        const countryCode = stringProperty(properties, "countrycode")?.toUpperCase();
        if ((!city && !region) || !country || !countryCode || !/^[A-Z]{2}$/.test(countryCode)) return null;
        const parts: string[] = [];
        addUniqueComponent(parts, city);
        addUniqueComponent(parts, region);
        addUniqueComponent(parts, country);
        return {
          label: parts.join(", "),
          city,
          region,
          country,
          countryCode,
          latitude: Math.round(latitude * 100) / 100,
          longitude: Math.round(longitude * 100) / 100,
          currencyCode: currencyForCountry(countryCode),
        };
      })
      .find(Boolean);
    if (!nearby) {
      res.status(404).json({ error: "No nearby city was found. Search for a location instead." });
      return;
    }
    res.json(ReverseLocationResponse.parse(nearby));
  } catch (error) {
    req.log.warn({ error }, "Unable to find nearby city");
    res.status(502).json({ error: "Could not find a nearby city right now. Search for a location instead." });
  }
});

export default router;