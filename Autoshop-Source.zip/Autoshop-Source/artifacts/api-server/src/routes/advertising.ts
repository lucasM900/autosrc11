import { randomUUID } from "node:crypto";
import { Router, type IRouter } from "express";
import { z } from "zod";
import { advertisingInquiriesTable, db } from "@workspace/db";

const router: IRouter = Router();

const advertisingInquirySchema = z
  .object({
    name: z.string().trim().min(2).max(100),
    company: z.string().trim().min(2).max(160),
    email: z.string().trim().email().max(254),
    phone: z.string().trim().max(40).optional(),
    placement: z.enum(["brand", "category", "international"]),
    budget: z.enum(["under_1k", "1k_5k", "5k_plus"]).optional(),
    message: z.string().trim().min(10).max(3000),
    website: z.string().max(0).optional(),
  })
  .strict();

const requestHistory = new Map<string, number[]>();
const WINDOW_MS = 60 * 60 * 1000;
const MAX_REQUESTS = 5;

function isRateLimited(key: string) {
  const now = Date.now();
  const recent = (requestHistory.get(key) ?? []).filter(
    (timestamp) => now - timestamp < WINDOW_MS,
  );
  if (recent.length >= MAX_REQUESTS) return true;
  recent.push(now);
  requestHistory.set(key, recent);
  return false;
}

router.post(
  "/advertising-inquiries",
  async (req, res): Promise<void> => {
    const parsed = advertisingInquirySchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Please check the inquiry details." });
      return;
    }

    if (parsed.data.website) {
      res.status(201).json({ received: true });
      return;
    }

    const rateLimitKey = `${req.ip}:${parsed.data.email.toLowerCase()}`;
    if (isRateLimited(rateLimitKey)) {
      res.status(429).json({ error: "Too many inquiries. Please try again later." });
      return;
    }

    const { website: _website, ...inquiryData } = parsed.data;
    const [inquiry] = await db
      .insert(advertisingInquiriesTable)
      .values({
        id: randomUUID(),
        ...inquiryData,
        phone: inquiryData.phone || null,
        budget: inquiryData.budget || null,
      })
      .returning({
        id: advertisingInquiriesTable.id,
        status: advertisingInquiriesTable.status,
        createdAt: advertisingInquiriesTable.createdAt,
      });

    res.status(201).json(inquiry);
  },
);

export default router;