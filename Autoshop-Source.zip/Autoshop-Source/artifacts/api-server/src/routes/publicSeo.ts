import { readFile } from "node:fs/promises";
import path from "node:path";
import { Router, type IRouter } from "express";
import { db, listingsTable, type Listing } from "@workspace/db";
import { eq } from "drizzle-orm";
import { publicListings } from "./listings";

const router: IRouter = Router();
const siteUrl = "https://autoshopsource.com";
const webRoot = path.resolve(process.cwd(), "artifacts/tool-bay-direct");

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[character]!);
}

function escapeXml(value: string): string {
  return escapeHtml(value);
}

function availability(listing: Listing): string {
  if (listing.status === "sold") return "sold";
  const value = listing.attributes?.availability;
  return typeof value === "string" && ["available", "pending", "sold"].includes(value.toLowerCase())
    ? value.toLowerCase()
    : "available";
}

function listingDescription(listing: Listing): string {
  const summary = `${listing.title} in ${listing.location}. ${listing.description || listing.spec || "View equipment details on Autoshop Source."}`;
  return summary.replace(/\s+/g, " ").trim().slice(0, 160);
}

async function webShell(): Promise<string> {
  if (process.env.NODE_ENV === "production") {
    return readFile(path.join(webRoot, "dist/public/index.html"), "utf8");
  }
  // Vite transforms the HTML in development (including its client entrypoint).
  const response = await fetch("http://localhost:80/");
  if (!response.ok) throw new Error(`Unable to load web shell: ${response.status}`);
  return response.text();
}

function renderListing(shell: string, listing: Listing, indexable: boolean): string {
  const title = `${listing.title} | Autoshop Source`;
  const description = listingDescription(listing);
  const url = `${siteUrl}/listings/${encodeURIComponent(listing.id)}`;
  const status = availability(listing);
  const price = new Intl.NumberFormat("en", {
    style: "currency",
    currency: listing.currencyCode || "CAD",
  }).format(listing.price);
  const provenance = listing.attributes?.externalListing
    ? `<p>Imported from ${escapeHtml(String(listing.attributes.sourcePlatform || "an external marketplace"))}. The source seller did not create or manage this listing. Inquiries are recorded as relay requests; confirm availability, price, condition and specifications before purchasing.</p>`
    : "";
  const image = listing.imagePaths?.[0]
    ? `/api/storage${listing.imagePaths[0]}`
    : listing.image;
  const body = `<main><article>
    <p><a href="/">Back to the equipment marketplace</a></p>
    <h1>${escapeHtml(listing.title)}</h1>
    <p>Availability: ${escapeHtml(status)} · Condition: ${escapeHtml(listing.condition)} · ${escapeHtml(price)}</p>
    <p>Location: ${escapeHtml(listing.location)}</p>
    ${image ? `<img src="${escapeHtml(image)}" alt="${escapeHtml(listing.title)}" />` : ""}
    <h2>Equipment description</h2>
    <p>${escapeHtml(listing.description || listing.spec || "Contact the seller for equipment details.")}</p>
    ${listing.spec && listing.description ? `<p>Key specs: ${escapeHtml(listing.spec)}</p>` : ""}
    ${provenance}
    <p>Enable JavaScript to view photos and contact the seller on Autoshop Source.</p>
  </article></main>`;
  const head = `<link rel="canonical" href="${escapeHtml(url)}" />
    <meta property="og:type" content="product" />`;

  // Replace shell defaults, rather than adding competing page metadata.
  return shell
    .replace(/<title>[\s\S]*?<\/title>/, `<title>${escapeHtml(title)}</title>`)
    .replace(/<meta name="description"[^>]*>/, `<meta name="description" content="${escapeHtml(description)}" />`)
    .replace(/<meta name="robots"[^>]*>/, indexable ? '<meta name="robots" content="index, follow" />' : '<meta name="robots" content="noindex, follow" />')
    .replace(/<meta property="og:title"[^>]*>/, `<meta property="og:title" content="${escapeHtml(title)}" />`)
    .replace(/<meta property="og:description"[^>]*>/, `<meta property="og:description" content="${escapeHtml(description)}" />`)
    .replace(/<meta property="og:url"[^>]*>/, `<meta property="og:url" content="${escapeHtml(url)}" />`)
    .replace(/<meta property="og:type"[^>]*>/, "")
    .replace(/<meta name="twitter:title"[^>]*>/, `<meta name="twitter:title" content="${escapeHtml(title)}" />`)
    .replace(/<meta name="twitter:description"[^>]*>/, `<meta name="twitter:description" content="${escapeHtml(description)}" />`)
    .replace("</head>", `${head}</head>`)
    .replace(/<div id="root">[\s\S]*?<\/div>/, `<div id="root">${body}</div>`);
}

router.get("/listings/:id", async (req, res): Promise<void> => {
  const id = req.params.id;
  if (typeof id !== "string" || id.length > 200) {
    res.status(404).type("html").send("<!doctype html><title>Listing not found</title><meta name=\"robots\" content=\"noindex\"><h1>Listing not found</h1>");
    return;
  }
  const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, id));
  const requestedAvailability = typeof req.query.availability === "string" ? req.query.availability : undefined;
  const visible = listing && publicListings([listing], undefined, requestedAvailability).length > 0;
  if (!visible) {
    res.status(404).type("html").send("<!doctype html><title>Listing not found</title><meta name=\"robots\" content=\"noindex\"><h1>Listing not found</h1>");
    return;
  }
  const indexable = publicListings([listing]).length > 0;
  res.set("Cache-Control", "no-store");
  res.type("html").send(renderListing(await webShell(), listing, indexable));
});

router.get("/sitemap.xml", async (_req, res): Promise<void> => {
  const listings = publicListings(await db.select().from(listingsTable));
  const urls = [
    `${siteUrl}/`,
    `${siteUrl}/advertise`,
    ...listings.map(listing => `${siteUrl}/listings/${encodeURIComponent(listing.id)}`),
  ];
  res.set("Cache-Control", "no-store");
  res.type("application/xml").send(`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(url => `  <url><loc>${escapeXml(url)}</loc></url>`).join("\n")}
</urlset>`);
});

export default router;