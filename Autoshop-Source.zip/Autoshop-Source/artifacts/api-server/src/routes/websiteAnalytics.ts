import { createHmac } from "node:crypto";
import { Router, type IRouter } from "express";
import {
  GetAdminWebsiteAnalyticsQueryParams,
  GetAdminWebsiteAnalyticsResponse,
  RecordWebsiteAnalyticsEventBody,
  RecordWebsiteAnalyticsEventResponse,
} from "@workspace/api-zod";
import { pool } from "@workspace/db";
import { getAuthenticatedUserId, requireAdmin } from "../middlewares/auth";

const router: IRouter = Router();
const botPattern = /bot|crawler|spider|headless|lighthouse|preview|facebookexternalhit|slurp|bingpreview/i;

const analyticsReady = pool.query(`
  CREATE TABLE IF NOT EXISTS website_analytics_events (
    event_id uuid PRIMARY KEY,
    visitor_hash text NOT NULL,
    session_hash text NOT NULL,
    event_type text NOT NULL CHECK (event_type IN ('page_view', 'login', 'signup')),
    path text NOT NULL,
    referrer_host text,
    authenticated boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now()
  );
  CREATE INDEX IF NOT EXISTS website_analytics_events_created_at_idx ON website_analytics_events(created_at);
  CREATE INDEX IF NOT EXISTS website_analytics_events_type_created_idx ON website_analytics_events(event_type, created_at);
  DELETE FROM website_analytics_events WHERE created_at < now() - interval '13 months';
`);

function anonymousHash(value: string): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET is required for analytics hashing");
  return createHmac("sha256", secret).update(value).digest("hex");
}

router.post("/analytics/events", async (req, res): Promise<void> => {
  const parsed = RecordWebsiteAnalyticsEventBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const userAgent = req.get("user-agent") ?? "";
  if (!userAgent || botPattern.test(userAgent)) {
    res.status(202).json(RecordWebsiteAnalyticsEventResponse.parse({ accepted: false }));
    return;
  }

  await analyticsReady;
  const event = parsed.data;
  await pool.query(
    `INSERT INTO website_analytics_events
      (event_id, visitor_hash, session_hash, event_type, path, referrer_host, authenticated)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     ON CONFLICT (event_id) DO NOTHING`,
    [
      event.eventId,
      anonymousHash(event.visitorId),
      anonymousHash(event.sessionId),
      event.eventType,
      event.path,
      event.referrerHost ?? null,
      Boolean(getAuthenticatedUserId(req)),
    ],
  );
  res.status(202).json(RecordWebsiteAnalyticsEventResponse.parse({ accepted: true }));
});

router.get("/admin/analytics/summary", requireAdmin, async (req, res): Promise<void> => {
  const query = {
    ...req.query,
    days: typeof req.query.days === "string" ? Number(req.query.days) : req.query.days,
  };
  const parsed = GetAdminWebsiteAnalyticsQueryParams.safeParse(query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  await analyticsReady;
  const days = parsed.data.days;
  const [totals, daily, pages] = await Promise.all([
    pool.query(
      `SELECT
         COUNT(DISTINCT visitor_hash)::int AS unique_visitors,
         COUNT(DISTINCT session_hash)::int AS sessions,
         COUNT(*) FILTER (WHERE event_type='page_view')::int AS page_views,
         COUNT(*) FILTER (WHERE event_type='login')::int AS logins,
         COUNT(*) FILTER (WHERE event_type='signup')::int AS signups,
         COUNT(DISTINCT visitor_hash) FILTER (WHERE authenticated)::int AS authenticated_visitors
       FROM website_analytics_events
       WHERE created_at >= now() - ($1::int * interval '1 day')`,
      [days],
    ),
    pool.query(
      `WITH dates AS (
         SELECT generate_series(current_date - ($1::int - 1), current_date, interval '1 day')::date AS day
       )
       SELECT dates.day::text AS date,
         COUNT(DISTINCT e.visitor_hash)::int AS visitors,
         COUNT(DISTINCT e.session_hash)::int AS sessions,
         COUNT(*) FILTER (WHERE e.event_type='page_view')::int AS page_views,
         COUNT(*) FILTER (WHERE e.event_type='login')::int AS logins,
         COUNT(*) FILTER (WHERE e.event_type='signup')::int AS signups
       FROM dates
       LEFT JOIN website_analytics_events e ON e.created_at::date=dates.day
       GROUP BY dates.day ORDER BY dates.day`,
      [days],
    ),
    pool.query(
      `SELECT path, COUNT(*)::int AS views, COUNT(DISTINCT visitor_hash)::int AS visitors
       FROM website_analytics_events
       WHERE event_type='page_view' AND created_at >= now() - ($1::int * interval '1 day')
       GROUP BY path ORDER BY views DESC, path LIMIT 10`,
      [days],
    ),
  ]);

  const total = totals.rows[0];
  res.json(GetAdminWebsiteAnalyticsResponse.parse({
    days,
    uniqueVisitors: total.unique_visitors,
    sessions: total.sessions,
    pageViews: total.page_views,
    logins: total.logins,
    signups: total.signups,
    authenticatedVisitors: total.authenticated_visitors,
    daily: daily.rows.map(row => ({
      date: row.date,
      visitors: row.visitors,
      sessions: row.sessions,
      pageViews: row.page_views,
      logins: row.logins,
      signups: row.signups,
    })),
    topPages: pages.rows,
  }));
});

export default router;