import { createHash, randomUUID } from "node:crypto";
import { Router, type Request, type Response } from "express";
import { z } from "zod";
import { db, pool } from "@workspace/db";
import { sql } from "drizzle-orm";
import { getAuthenticatedUserId, isOwnerAdmin, requireAdmin, requireAuth } from "../middlewares/auth";
import { StripeConnectorError, stripeConnector } from "../stripeConnector";
import { ensureBannerInventory } from "../lib/ensureBannerInventory";

const router = Router();
const durations = [1, 3, 6, 12] as const;
const creativeSchema = z.object({
  objectPath: z.string().regex(/^\/objects\/[A-Za-z0-9/_-]+$/),
  width: z.number().int().positive(),
  height: z.number().int().positive(),
  sizeBytes: z.number().int().positive().max(5 * 1024 * 1024),
  contentType: z.enum(["image/jpeg", "image/jpg", "image/png", "image/webp"]),
});
const destinationSchema = z.string().url().refine((value) => /^https?:\/\//i.test(value), "Destination must use http or https");
const campaignSchema = z.object({
  locationId: z.string().min(1),
  durationMonths: z.number().int().refine((v) => durations.includes(v as (typeof durations)[number])),
  desktop: creativeSchema,
  mobile: creativeSchema.nullable().optional(),
  destinationUrl: destinationSchema,
});
const locationSchema = z.object({
  id: z.string().min(1).optional(),
  placementKey: z.string().regex(/^[a-z0-9-]+$/),
  name: z.string().min(1),
  description: z.string().optional().nullable(),
  page: z.string().min(1),
  desktopWidth: z.number().int().positive(),
  desktopHeight: z.number().int().positive(),
  mobileWidth: z.number().int().positive().optional().nullable(),
  mobileHeight: z.number().int().positive().optional().nullable(),
  maxFileSizeBytes: z.number().int().positive().max(5 * 1024 * 1024).default(5 * 1024 * 1024),
  isActive: z.boolean().default(true),
  approvalRequired: z.boolean().default(false),
});
const id = (prefix: string) => `${prefix}_${randomUUID()}`;
const formatLocation = (row: Record<string, unknown>) => ({
  id: row.id, placementKey: row.placement_key, name: row.name, description: row.description, page: row.page,
  desktopWidth: row.desktop_width, desktopHeight: row.desktop_height, mobileWidth: row.mobile_width, mobileHeight: row.mobile_height,
  maxFileSizeBytes: row.max_file_size_bytes, isActive: row.is_active, approvalRequired: row.approval_required,
  occupied: row.occupied, nextAvailableAt: row.next_available_at, prices: row.prices,
});
const formatCampaign = (row: Record<string, unknown>) => ({
  ...row, userId: row.user_id, locationId: row.location_id, desktopImagePath: row.desktop_image_path, mobileImagePath: row.mobile_image_path,
  desktopWidth: row.desktop_width, desktopHeight: row.desktop_height, mobileWidth: row.mobile_width, mobileHeight: row.mobile_height,
  destinationUrl: row.destination_url, durationMonths: row.duration_months, amountMinor: row.amount_minor, checkoutSessionId: row.checkout_session_id,
  paymentIntentId: row.payment_intent_id, purchaseAt: row.purchase_at, startAt: row.start_at, endAt: row.end_at,
  reservationExpiresAt: row.reservation_expires_at, impressions: row.impressions, clicks: row.clicks,
});
const validCreative = (creative: z.infer<typeof creativeSchema>, location: Record<string, unknown>, mobile: boolean) => {
  const width = Number(location[mobile ? "mobile_width" : "desktop_width"]);
  const height = Number(location[mobile ? "mobile_height" : "desktop_height"]);
  if (!width || !height) return !mobile;
  return creative.width === width && creative.height === height;
};
async function reconcileCampaign(adId: string): Promise<void> {
  const found = await db.execute(sql`SELECT id,checkout_session_id,status,duration_months,purchase_at FROM banner_advertisements WHERE id=${adId}`);
  const campaign = found.rows[0] as { id: string; checkout_session_id: string | null; status: string; duration_months: number; purchase_at: Date | null } | undefined;
  if (!campaign?.checkout_session_id || campaign.status !== "pending_payment") return;
  const session = await stripeConnector.retrieveCheckoutSession(campaign.checkout_session_id);
  if (session.payment_status !== "paid") {
    if (session.status === "expired") await db.execute(sql`UPDATE banner_advertisements SET status='cancelled',reservation_expires_at=NULL,updated_at=now() WHERE id=${adId} AND status='pending_payment'`);
    return;
  }
  const paidAt = new Date(typeof session.created === "number" ? session.created * 1000 : Date.now());
  const endAt = new Date(paidAt);
  endAt.setUTCMonth(endAt.getUTCMonth() + campaign.duration_months);
  await db.execute(sql`
    UPDATE banner_advertisements a SET status=CASE WHEN l.approval_required THEN 'pending_approval'::banner_ad_status ELSE 'active'::banner_ad_status END,
    purchase_at=${paidAt},start_at=${paidAt},end_at=${endAt},payment_intent_id=${typeof session.payment_intent === "string" ? session.payment_intent : null},reservation_expires_at=NULL,updated_at=now()
    FROM banner_locations l WHERE a.id=${adId} AND a.location_id=l.id AND a.status='pending_payment'
  `);
}

router.get("/banner-advertising/locations", async (_req, res): Promise<void> => {
  await db.execute(sql`
    UPDATE banner_advertisements
    SET status=CASE WHEN status='active' THEN 'expired'::banner_ad_status ELSE 'cancelled'::banner_ad_status END,
        reservation_expires_at=CASE WHEN status='pending_payment' THEN NULL ELSE reservation_expires_at END,
        updated_at=now()
    WHERE (status='active' AND end_at <= now())
       OR (status='pending_payment' AND reservation_expires_at <= now())
  `);
  const result = await db.execute(sql`
    SELECT l.*,
      EXISTS(SELECT 1 FROM banner_advertisements a WHERE a.location_id=l.id AND (a.status IN ('active','pending_approval') OR (a.status='pending_payment' AND a.reservation_expires_at > now()))) AS occupied,
      (SELECT MIN(COALESCE(a.end_at,a.reservation_expires_at)) FROM banner_advertisements a WHERE a.location_id=l.id AND (a.status IN ('active','pending_approval') OR (a.status='pending_payment' AND a.reservation_expires_at > now()))) AS next_available_at,
      COALESCE(json_agg(json_build_object('id',p.id,'durationMonths',p.duration_months,'amountMinor',p.amount_minor,'currency',p.currency,'isActive',p.is_active) ORDER BY p.duration_months) FILTER (WHERE p.id IS NOT NULL), '[]') AS prices
    FROM banner_locations l LEFT JOIN banner_duration_prices p ON p.location_id=l.id
    WHERE l.is_active=true GROUP BY l.id ORDER BY l.name
  `);
  res.json(result.rows.map((row) => formatLocation(row as Record<string, unknown>)));
});

router.get("/admin/banner-advertising/locations", requireAdmin, async (_req, res): Promise<void> => {
  await db.execute(sql`
    UPDATE banner_advertisements
    SET status=CASE WHEN status='active' THEN 'expired'::banner_ad_status ELSE 'cancelled'::banner_ad_status END,
        reservation_expires_at=CASE WHEN status='pending_payment' THEN NULL ELSE reservation_expires_at END,
        updated_at=now()
    WHERE (status='active' AND end_at <= now())
       OR (status='pending_payment' AND reservation_expires_at <= now())
  `);
  const result = await db.execute(sql`
    SELECT l.*, EXISTS(SELECT 1 FROM banner_advertisements a WHERE a.location_id=l.id AND (a.status IN ('active','pending_approval') OR (a.status='pending_payment' AND a.reservation_expires_at > now()))) AS occupied,
    (SELECT MIN(COALESCE(a.end_at,a.reservation_expires_at)) FROM banner_advertisements a WHERE a.location_id=l.id AND a.status IN ('active','pending_approval','pending_payment')) AS next_available_at,
    COALESCE(json_agg(json_build_object('id',p.id,'durationMonths',p.duration_months,'amountMinor',p.amount_minor,'currency',p.currency,'stripePriceId',p.stripe_price_id,'isActive',p.is_active) ORDER BY p.duration_months) FILTER (WHERE p.id IS NOT NULL), '[]') AS prices
    FROM banner_locations l LEFT JOIN banner_duration_prices p ON p.location_id=l.id GROUP BY l.id ORDER BY l.name
  `);
  res.json(result.rows.map((row) => formatLocation(row as Record<string, unknown>)));
});

router.get("/admin/banner-advertising/access", requireAuth, async (req, res): Promise<void> => {
  try {
    res.json({ isAdmin: await isOwnerAdmin(req) });
  } catch {
    res.status(503).json({ error: "Unable to verify owner access" });
  }
});

router.get("/banner-advertising/locations/:placementKey/active", async (req, res): Promise<void> => {
  const placementKey = Array.isArray(req.params.placementKey) ? req.params.placementKey[0] : req.params.placementKey;
  await db.execute(sql`UPDATE banner_advertisements SET status='expired', updated_at=now() WHERE status='active' AND end_at <= now()`);
  const result = await db.execute(sql`
    SELECT a.*, l.placement_key, l.name AS location_name
    FROM banner_advertisements a JOIN banner_locations l ON l.id=a.location_id
    WHERE l.placement_key=${placementKey} AND a.status='active' AND a.start_at <= now() AND a.end_at > now()
    LIMIT 1
  `);
  const ad = result.rows[0];
  if (!ad) { res.json({ ad: null }); return; }
  await db.execute(sql`UPDATE banner_advertisements SET impressions=impressions+1, updated_at=now() WHERE id=${ad.id}`);
  await db.execute(sql`INSERT INTO banner_analytics_events (id,advertisement_id,event_type) VALUES (${id("event")},${ad.id},'impression')`);
  res.json({ ad: formatCampaign(ad as Record<string, unknown>) });
});

router.get("/banner-advertising/ads/:adId/click", async (req, res): Promise<void> => {
  const adId = Array.isArray(req.params.adId) ? req.params.adId[0] : req.params.adId;
  const result = await db.execute(sql`SELECT destination_url FROM banner_advertisements WHERE id=${adId} AND status='active' AND start_at <= now() AND end_at > now()`);
  const ad = result.rows[0] as { destination_url?: string } | undefined;
  if (!ad?.destination_url || !/^https?:\/\//i.test(ad.destination_url)) { res.status(404).json({ error: "Advertisement not found" }); return; }
  const ip = String(req.ip ?? "").split(",")[0];
  const ipHash = createHash("sha256").update(ip).digest("hex");
  await db.execute(sql`UPDATE banner_advertisements SET clicks=clicks+1, updated_at=now() WHERE id=${adId}`);
  await db.execute(sql`INSERT INTO banner_analytics_events (id,advertisement_id,event_type,ip_hash,user_agent) VALUES (${id("event")},${adId},'click',${ipHash},${req.get("user-agent") ?? null})`);
  res.redirect(302, ad.destination_url);
});

router.get("/banner-advertising/campaigns", requireAuth, async (req, res): Promise<void> => {
  const userId = getAuthenticatedUserId(req)!;
  const pending = await db.execute(sql`SELECT id FROM banner_advertisements WHERE user_id=${userId} AND status='pending_payment' AND reservation_expires_at > now()`);
  await Promise.all(pending.rows.map((row) => reconcileCampaign(String(row.id))));
  await db.execute(sql`UPDATE banner_advertisements SET status='expired',updated_at=now() WHERE user_id=${userId} AND status='active' AND end_at <= now()`);
  const result = await db.execute(sql`
    SELECT a.*, l.name AS "locationName", l.placement_key AS "placementKey", l.desktop_width AS "desktopWidth", l.desktop_height AS "desktopHeight", l.mobile_width AS "mobileWidth", l.mobile_height AS "mobileHeight"
    FROM banner_advertisements a JOIN banner_locations l ON l.id=a.location_id
    WHERE a.user_id=${userId} ORDER BY a.created_at DESC
  `);
  res.json(result.rows.map((row) => formatCampaign(row as Record<string, unknown>)));
});

router.post("/banner-advertising/campaigns", requireAuth, async (req, res): Promise<void> => {
  const parsed = campaignSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const userId = getAuthenticatedUserId(req)!;
  const { locationId, durationMonths, desktop, mobile, destinationUrl } = parsed.data;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(hashtextextended($1, 0))", [locationId]);
    const location = (await client.query("SELECT * FROM banner_locations WHERE id=$1 AND is_active=true", [locationId])).rows[0];
    if (!location) { await client.query("ROLLBACK"); res.status(404).json({ error: "Advertising location not found" }); return; }
    if (desktop.sizeBytes > Number(location.max_file_size_bytes) || (mobile && mobile.sizeBytes > Number(location.max_file_size_bytes)) || !validCreative(desktop, location, false) || (mobile && !validCreative(mobile, location, true))) {
      await client.query("ROLLBACK"); res.status(400).json({ error: "Creative dimensions do not match this advertising location" }); return;
    }
    let pricing = (await client.query("SELECT * FROM banner_duration_prices WHERE location_id=$1 AND duration_months=$2 AND is_active=true", [locationId, durationMonths])).rows[0];
    if (!pricing?.stripe_price_id) { await client.query("ROLLBACK"); res.status(409).json({ error: "This duration is not currently available" }); return; }
    await client.query("UPDATE banner_advertisements SET status='cancelled', updated_at=now() WHERE status='pending_payment' AND reservation_expires_at < now()");
    const collision = (await client.query(
      "SELECT id FROM banner_advertisements WHERE location_id=$1 AND (status IN ('active','pending_approval') OR (status='pending_payment' AND reservation_expires_at > now())) LIMIT 1",
      [locationId],
    )).rows[0];
    if (collision) { await client.query("ROLLBACK"); res.status(409).json({ error: "This advertising location is already reserved" }); return; }
    const adId = id("ad");
    await client.query(
      `INSERT INTO banner_advertisements (id,user_id,location_id,desktop_image_path,mobile_image_path,desktop_width,desktop_height,mobile_width,mobile_height,destination_url,duration_months,amount_minor,currency,reservation_expires_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,now()+interval '30 minutes')`,
      [adId, userId, locationId, desktop.objectPath, mobile?.objectPath ?? null, desktop.width, desktop.height, mobile?.width ?? null, mobile?.height ?? null, destinationUrl, durationMonths, pricing.amount_minor, pricing.currency],
    );
    const origin = `${req.protocol}://${req.get("host")}`;
    let frontendBase = origin;
    const referer = req.get("referer");
    if (referer) {
      try {
        const refererUrl = new URL(referer);
        const advertiseIndex = refererUrl.pathname.indexOf("/advertise");
        const basePath = advertiseIndex >= 0 ? refererUrl.pathname.slice(0, advertiseIndex) : "";
        frontendBase = `${refererUrl.origin}${basePath}`;
      } catch {
        // Fall back to the API request origin when no valid browser referrer exists.
      }
    }
    const checkoutValues = () => ({
      "mode": "payment",
      "line_items[0][price]": String(pricing.stripe_price_id),
      "line_items[0][quantity]": "1",
      "success_url": `${frontendBase}/advertise/checkout?session_id={CHECKOUT_SESSION_ID}&campaign_id=${adId}`,
      "cancel_url": `${frontendBase}/advertise/checkout?cancelled=1&campaign_id=${adId}`,
      "metadata[advertisementId]": adId,
      "metadata[userId]": userId,
      "metadata[locationId]": locationId,
      "metadata[durationMonths]": String(durationMonths),
      "client_reference_id": adId,
    });
    let session;
    try {
      session = await stripeConnector.createCheckoutSession(checkoutValues());
    } catch (error) {
      if (!(error instanceof StripeConnectorError) || error.stripeCode !== "resource_missing") throw error;
      req.log.warn({ stripeCode: error.stripeCode }, "Stored Stripe price is stale; refreshing banner inventory");
      await ensureBannerInventory();
      pricing = (await client.query(
        "SELECT * FROM banner_duration_prices WHERE location_id=$1 AND duration_months=$2 AND is_active=true",
        [locationId, durationMonths],
      )).rows[0];
      if (!pricing?.stripe_price_id) throw error;
      session = await stripeConnector.createCheckoutSession(checkoutValues());
    }
    if (typeof session.id !== "string" || typeof session.url !== "string") {
      throw new Error("Stripe Checkout Session response is missing its ID or URL");
    }
    await client.query("UPDATE banner_advertisements SET checkout_session_id=$1, updated_at=now() WHERE id=$2", [session.id, adId]);
    await client.query("COMMIT");
    res.status(201).json({ id: adId, checkoutUrl: session.url, reservationExpiresAt: new Date(Date.now() + 30 * 60_000).toISOString() });
  } catch (error) {
    await client.query("ROLLBACK");
    req.log.error({ err: error }, "Banner checkout creation failed");
    res.status(500).json({ error: "Unable to create checkout session" });
  } finally { client.release(); }
});

router.post("/banner-advertising/campaigns/:adId/cancel", requireAuth, async (req, res): Promise<void> => {
  const adId = Array.isArray(req.params.adId) ? req.params.adId[0] : req.params.adId;
  const userId = getAuthenticatedUserId(req)!;
  await reconcileCampaign(adId);
  const checkout = await db.execute(sql`SELECT checkout_session_id FROM banner_advertisements WHERE id=${adId} AND user_id=${userId} AND status='pending_payment'`);
  const checkoutSessionId = checkout.rows[0]?.checkout_session_id;
  if (typeof checkoutSessionId === "string") {
    try { await stripeConnector.expireCheckoutSession(checkoutSessionId); } catch (error) { req.log.warn({ err: error }, "Unable to expire Stripe Checkout session"); }
  }
  const result = await db.execute(sql`UPDATE banner_advertisements SET status='cancelled', updated_at=now() WHERE id=${adId} AND user_id=${userId} AND status='pending_payment' RETURNING id`);
  if (!result.rows[0]) { res.status(404).json({ error: "Campaign not found or cannot be cancelled" }); return; }
  res.json({ cancelled: true });
});

router.get("/banner-advertising/campaigns/:adId/checkout-status", requireAuth, async (req, res): Promise<void> => {
  const adId = Array.isArray(req.params.adId) ? req.params.adId[0] : req.params.adId;
  const userId = getAuthenticatedUserId(req)!;
  await reconcileCampaign(adId);
  const result = await db.execute(sql`SELECT id,status,checkout_session_id,purchase_at,start_at,end_at FROM banner_advertisements WHERE id=${adId} AND user_id=${userId}`);
  if (!result.rows[0]) { res.status(404).json({ error: "Campaign not found" }); return; }
  const row = result.rows[0] as Record<string, unknown>;
  res.json({ id: row.id, status: row.status, checkoutSessionId: row.checkout_session_id, purchaseAt: row.purchase_at, startAt: row.start_at, endAt: row.end_at });
});

router.get("/admin/banner-advertising/campaigns", requireAdmin, async (req, res): Promise<void> => {
  const status = typeof req.query.status === "string" ? req.query.status : null;
  const result = status
     ? await db.execute(sql`SELECT a.*,l.name AS "locationName",l.placement_key AS "placementKey",l.desktop_width AS "desktopWidth",l.desktop_height AS "desktopHeight",l.mobile_width AS "mobileWidth",l.mobile_height AS "mobileHeight" FROM banner_advertisements a JOIN banner_locations l ON l.id=a.location_id WHERE a.status=${status} ORDER BY a.created_at DESC`)
    : await db.execute(sql`SELECT a.*,l.name AS "locationName",l.placement_key AS "placementKey",l.desktop_width AS "desktopWidth",l.desktop_height AS "desktopHeight",l.mobile_width AS "mobileWidth",l.mobile_height AS "mobileHeight" FROM banner_advertisements a JOIN banner_locations l ON l.id=a.location_id ORDER BY a.created_at DESC`);
  res.json(result.rows.map((row) => formatCampaign(row as Record<string, unknown>)));
});

router.post("/admin/banner-advertising/locations", requireAdmin, async (req, res): Promise<void> => {
  const parsed = locationSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const value = parsed.data;
  const result = await db.execute(sql`
    INSERT INTO banner_locations (id,placement_key,name,description,page,desktop_width,desktop_height,mobile_width,mobile_height,max_file_size_bytes,is_active,approval_required)
    VALUES (${value.id ?? id("location")},${value.placementKey},${value.name},${value.description ?? null},${value.page},${value.desktopWidth},${value.desktopHeight},${value.mobileWidth ?? null},${value.mobileHeight ?? null},${value.maxFileSizeBytes},${value.isActive},${value.approvalRequired}) RETURNING *
  `);
  res.status(201).json(result.rows[0]);
});

router.patch("/admin/banner-advertising/locations/:locationId", requireAdmin, async (req, res): Promise<void> => {
  const parsed = locationSchema.partial().safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const locationId = Array.isArray(req.params.locationId) ? req.params.locationId[0] : req.params.locationId;
  const value = parsed.data;
  const result = await db.execute(sql`
    UPDATE banner_locations SET
      placement_key=COALESCE(${value.placementKey ?? null},placement_key), page=COALESCE(${value.page ?? null},page),
      name=COALESCE(${value.name ?? null},name), description=COALESCE(${value.description ?? null},description),
      desktop_width=COALESCE(${value.desktopWidth ?? null},desktop_width), desktop_height=COALESCE(${value.desktopHeight ?? null},desktop_height),
      mobile_width=COALESCE(${value.mobileWidth ?? null},mobile_width), mobile_height=COALESCE(${value.mobileHeight ?? null},mobile_height),
      max_file_size_bytes=COALESCE(${value.maxFileSizeBytes ?? null},max_file_size_bytes),
      is_active=COALESCE(${value.isActive ?? null},is_active), approval_required=COALESCE(${value.approvalRequired ?? null},approval_required), updated_at=now()
    WHERE id=${locationId} RETURNING *
  `);
  if (!result.rows[0]) { res.status(404).json({ error: "Location not found" }); return; }
  res.json(result.rows[0]);
});

router.put("/admin/banner-advertising/locations/:locationId/prices/:durationMonths", requireAdmin, async (req, res): Promise<void> => {
  const locationId = Array.isArray(req.params.locationId) ? req.params.locationId[0] : req.params.locationId;
  const durationMonths = Number(Array.isArray(req.params.durationMonths) ? req.params.durationMonths[0] : req.params.durationMonths);
  const body = z.object({ amountMinor: z.number().int().positive(), isActive: z.boolean().optional() }).safeParse(req.body);
  if (!body.success || !durations.includes(durationMonths as (typeof durations)[number])) { res.status(400).json({ error: "Invalid price" }); return; }
  const existing = (await db.execute(sql`SELECT * FROM banner_duration_prices WHERE location_id=${locationId} AND duration_months=${durationMonths}`)).rows[0] as { id?: string; stripe_product_id?: string; stripe_price_id?: string } | undefined;
  let productId = existing?.stripe_product_id;
  if (!productId) {
    const product = await stripeConnector.createProduct(`Banner advertising — ${durationMonths} month${durationMonths === 1 ? "" : "s"}`, { bannerLocationId: locationId, durationMonths: String(durationMonths) });
    productId = typeof product.id === "string" ? product.id : undefined;
  }
  if (!productId) { res.status(502).json({ error: "Stripe product creation failed" }); return; }
  const price = await stripeConnector.createPrice(productId, body.data.amountMinor, { bannerLocationId: locationId, durationMonths: String(durationMonths) });
  const result = await db.execute(sql`
    INSERT INTO banner_duration_prices (id,location_id,duration_months,amount_minor,currency,stripe_product_id,stripe_price_id,is_active)
    VALUES (${existing?.id ?? id("price")},${locationId},${durationMonths},${body.data.amountMinor},'CAD',${productId},${String(price.id)},${body.data.isActive ?? true})
    ON CONFLICT (location_id,duration_months) DO UPDATE SET amount_minor=excluded.amount_minor,stripe_product_id=excluded.stripe_product_id,stripe_price_id=excluded.stripe_price_id,is_active=excluded.is_active,updated_at=now()
    RETURNING *
  `);
  res.json(result.rows[0]);
});

router.patch("/admin/banner-advertising/campaigns/:adId", requireAdmin, async (req, res): Promise<void> => {
  const adId = Array.isArray(req.params.adId) ? req.params.adId[0] : req.params.adId;
  const body = z.object({ destinationUrl: destinationSchema, desktop: creativeSchema, mobile: creativeSchema.nullable().optional() }).partial().safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: body.error.message }); return; }
  const found = await db.execute(sql`SELECT a.*,l.desktop_width,l.desktop_height,l.mobile_width,l.mobile_height,l.max_file_size_bytes FROM banner_advertisements a JOIN banner_locations l ON l.id=a.location_id WHERE a.id=${adId}`);
  const current = found.rows[0] as Record<string, unknown> | undefined;
  if (!current) { res.status(404).json({ error: "Campaign not found" }); return; }
  if (body.data.desktop && (!validCreative(body.data.desktop, current, false) || body.data.desktop.sizeBytes > Number(current.max_file_size_bytes)) || body.data.mobile && (!validCreative(body.data.mobile, current, true) || body.data.mobile.sizeBytes > Number(current.max_file_size_bytes))) {
    res.status(400).json({ error: "Creative dimensions or file size do not match this location" }); return;
  }
  const result = await db.execute(sql`UPDATE banner_advertisements SET destination_url=COALESCE(${body.data.destinationUrl ?? null},destination_url),desktop_image_path=COALESCE(${body.data.desktop?.objectPath ?? null},desktop_image_path),mobile_image_path=COALESCE(${body.data.mobile?.objectPath ?? null},mobile_image_path),desktop_width=COALESCE(${body.data.desktop?.width ?? null},desktop_width),desktop_height=COALESCE(${body.data.desktop?.height ?? null},desktop_height),mobile_width=COALESCE(${body.data.mobile?.width ?? null},mobile_width),mobile_height=COALESCE(${body.data.mobile?.height ?? null},mobile_height),updated_at=now() WHERE id=${adId} RETURNING *`);
  res.json(result.rows[0]);
});

router.post("/admin/banner-advertising/campaigns/:adId/cancel", requireAdmin, async (req, res): Promise<void> => {
  const adId = Array.isArray(req.params.adId) ? req.params.adId[0] : req.params.adId;
  const result = await db.execute(sql`UPDATE banner_advertisements SET status='cancelled',reservation_expires_at=NULL,updated_at=now() WHERE id=${adId} AND status NOT IN ('expired','cancelled','rejected') RETURNING id`);
  if (!result.rows[0]) { res.status(404).json({ error: "Campaign not found" }); return; }
  res.json({ cancelled: true });
});

router.delete("/admin/banner-advertising/campaigns/:adId", requireAdmin, async (req, res): Promise<void> => {
  const adId = Array.isArray(req.params.adId) ? req.params.adId[0] : req.params.adId;
  const result = await db.execute(sql`DELETE FROM banner_advertisements WHERE id=${adId} RETURNING id`);
  if (!result.rows[0]) { res.status(404).json({ error: "Campaign not found" }); return; }
  res.status(204).send();
});

router.post("/admin/banner-advertising/campaigns/:adId/extend", requireAdmin, async (req, res): Promise<void> => {
  const adId = Array.isArray(req.params.adId) ? req.params.adId[0] : req.params.adId;
  const parsed = z.object({ durationMonths: z.number().int().refine((v) => durations.includes(v as (typeof durations)[number])) }).safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const current = (await client.query("SELECT * FROM banner_advertisements WHERE id=$1 FOR UPDATE", [adId])).rows[0];
    if (!current) { await client.query("ROLLBACK"); res.status(404).json({ error: "Campaign not found" }); return; }
    await client.query("SELECT pg_advisory_xact_lock(hashtextextended($1, 0))", [current.location_id]);
    const end = new Date(current.end_at ?? new Date());
    end.setUTCMonth(end.getUTCMonth() + parsed.data.durationMonths);
    const collision = (await client.query("SELECT id FROM banner_advertisements WHERE location_id=$1 AND id<>$2 AND status IN ('active','pending_approval','pending_payment') AND COALESCE(start_at,now()) < $3 AND COALESCE(end_at,reservation_expires_at,now()) > $4 LIMIT 1", [current.location_id, adId, end, current.end_at ?? new Date()])).rows[0];
    if (collision) { await client.query("ROLLBACK"); res.status(409).json({ error: "Extension overlaps another campaign" }); return; }
    const updated = (await client.query("UPDATE banner_advertisements SET end_at=$1,duration_months=duration_months+$2,updated_at=now() WHERE id=$3 RETURNING *", [end, parsed.data.durationMonths, adId])).rows[0];
    await client.query("COMMIT");
    res.json(updated);
  } catch (error) { await client.query("ROLLBACK"); req.log.error({ err: error }, "Campaign extension failed"); res.status(500).json({ error: "Unable to extend campaign" }); }
  finally { client.release(); }
});

router.post("/admin/banner-advertising/campaigns/:adId/approve", requireAdmin, async (req, res): Promise<void> => {
  const adId = Array.isArray(req.params.adId) ? req.params.adId[0] : req.params.adId;
  const result = await db.execute(sql`UPDATE banner_advertisements SET status='active',start_at=COALESCE(start_at,purchase_at,now()),end_at=COALESCE(end_at,now()+make_interval(months=>duration_months)),updated_at=now() WHERE id=${adId} AND status='pending_approval' RETURNING *`);
  if (!result.rows[0]) { res.status(404).json({ error: "Pending campaign not found" }); return; }
  res.json(result.rows[0]);
});

router.post("/admin/banner-advertising/campaigns/:adId/reject", requireAdmin, async (req, res): Promise<void> => {
  const adId = Array.isArray(req.params.adId) ? req.params.adId[0] : req.params.adId;
  const result = await db.execute(sql`UPDATE banner_advertisements SET status='rejected',updated_at=now() WHERE id=${adId} AND status='pending_approval' RETURNING *`);
  if (!result.rows[0]) { res.status(404).json({ error: "Pending campaign not found" }); return; }
  res.json(result.rows[0]);
});

export default router;