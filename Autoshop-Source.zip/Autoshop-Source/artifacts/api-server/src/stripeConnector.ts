import { ReplitConnectors } from "@replit/connectors-sdk";

type StripeObject = Record<string, unknown>;

export class StripeConnectorError extends Error {
  constructor(
    public readonly status: number,
    public readonly stripeCode?: string,
    message = "Stripe request failed",
  ) {
    super(message);
    this.name = "StripeConnectorError";
  }
}

async function stripeRequest(path: string, method: "GET" | "POST", values?: Record<string, string>): Promise<StripeObject> {
  const connectors = new ReplitConnectors();
  const response = await connectors.proxy("stripe", path, {
    method,
    ...(values ? { body: new URLSearchParams(values), headers: { "Content-Type": "application/x-www-form-urlencoded" } } : {}),
  });
  const payload = (await response.json()) as StripeObject;
  if (!response.ok) {
    const stripeError = payload.error && typeof payload.error === "object"
      ? payload.error as Record<string, unknown>
      : {};
    throw new StripeConnectorError(
      response.status,
      typeof stripeError.code === "string" ? stripeError.code : undefined,
      typeof stripeError.message === "string" ? stripeError.message : `Stripe request failed (${response.status})`,
    );
  }
  return payload;
}

export const stripeConnector = {
  createProduct(name: string, metadata: Record<string, string>) {
    return stripeRequest("/v1/products", "POST", { name, ...Object.fromEntries(Object.entries(metadata).map(([key, value]) => [`metadata[${key}]`, value])) });
  },
  createPrice(product: string, amountMinor: number, metadata: Record<string, string>) {
    return stripeRequest("/v1/prices", "POST", {
      product, currency: "cad", unit_amount: String(amountMinor),
      ...Object.fromEntries(Object.entries(metadata).map(([key, value]) => [`metadata[${key}]`, value])),
    });
  },
  createCheckoutSession(values: Record<string, string>) {
    return stripeRequest("/v1/checkout/sessions", "POST", values);
  },
  retrievePrice(priceId: string) {
    return stripeRequest(`/v1/prices/${encodeURIComponent(priceId)}`, "GET");
  },
  retrieveCheckoutSession(sessionId: string) {
    return stripeRequest(`/v1/checkout/sessions/${encodeURIComponent(sessionId)}`, "GET");
  },
  expireCheckoutSession(sessionId: string) {
    return stripeRequest(`/v1/checkout/sessions/${encodeURIComponent(sessionId)}/expire`, "POST");
  },
};