import { createClerkClient, getAuth } from "@clerk/express";
import type { NextFunction, Request, Response } from "express";

const clerkClient = createClerkClient({ secretKey: process.env.CLERK_SECRET_KEY });

export function getAuthenticatedUserId(req: Request): string | null {
  const auth = getAuth(req);
  const userId = auth?.sessionClaims?.userId || auth?.userId;
  return typeof userId === "string" && userId.length > 0 ? userId : null;
}

export function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  if (!getAuthenticatedUserId(req)) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

export async function isOwnerAdmin(req: Request): Promise<boolean> {
  const userId = getAuthenticatedUserId(req);
  const ownerEmail = process.env.OWNER_ADMIN_EMAIL?.trim().toLowerCase();
  if (!userId || !ownerEmail) return false;

  const user = await clerkClient.users.getUser(userId);
  return user.emailAddresses.some(
    ({ emailAddress }) => emailAddress.trim().toLowerCase() === ownerEmail,
  );
}

export async function requireAdmin(req: Request, res: Response, next: NextFunction): Promise<void> {
  const userId = getAuthenticatedUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  try {
    if (!(await isOwnerAdmin(req))) {
      res.status(403).json({ error: "Owner access required" });
      return;
    }
    next();
  } catch {
    res.status(503).json({ error: "Unable to verify owner access" });
  }
}