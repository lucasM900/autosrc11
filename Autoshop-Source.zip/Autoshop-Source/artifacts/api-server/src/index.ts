import app from "./app";
import { ensureBannerInventory } from "./lib/ensureBannerInventory";
import { ensureDemoPremiumListing } from "./lib/ensureDemoPremiumListing";
import { ensurePremiumListingInventory } from "./lib/ensurePremiumListingInventory";
import { logger } from "./lib/logger";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

await ensureBannerInventory();
await ensurePremiumListingInventory();
await ensureDemoPremiumListing();

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
