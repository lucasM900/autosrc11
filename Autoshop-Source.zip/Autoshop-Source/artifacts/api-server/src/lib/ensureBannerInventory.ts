import { pool } from "@workspace/db";
import { StripeConnectorError, stripeConnector } from "../stripeConnector";

const horizontalLocations = Array.from({ length: 40 }, (_, index) => {
  const slot = index + 1;
  const id = slot === 1 ? "horizontal-listings" : `horizontal-listings-${slot}`;
  return {
    id,
    name: slot === 1 ? "Horizontal Listings" : `Horizontal Listings ${slot}`,
    desktopWidth: 970,
    desktopHeight: 250,
    mobileWidth: 320,
    mobileHeight: 100,
  };
});

const locations = [
  ...horizontalLocations,
  { id: "right-rail-1", name: "Right Rail 1", desktopWidth: 300, desktopHeight: 600, mobileWidth: null, mobileHeight: null },
  { id: "right-rail-2", name: "Right Rail 2", desktopWidth: 300, desktopHeight: 600, mobileWidth: null, mobileHeight: null },
];

const prices = [
  { months: 1, amountMinor: 2999 },
  { months: 3, amountMinor: 4999 },
  { months: 6, amountMinor: 9999 },
  { months: 12, amountMinor: 119900 },
] as const;

export async function ensureBannerInventory(): Promise<void> {
  const client = await pool.connect();
  const validatedPriceIds = new Set<string>();
  try {
    await client.query("SELECT pg_advisory_lock($1)", [7_314_221]);

    for (const location of locations) {
      await client.query(
        `INSERT INTO banner_locations
          (id, placement_key, name, description, page, desktop_width, desktop_height, mobile_width, mobile_height)
         VALUES ($1, $1, $2, $3, 'listings', $4, $5, $6, $7)
         ON CONFLICT (id) DO NOTHING`,
        [
          location.id,
          location.name,
          "Reach automotive professionals and shop owners.",
          location.desktopWidth,
          location.desktopHeight,
          location.mobileWidth,
          location.mobileHeight,
        ],
      );
    }

    for (const price of prices) {
      const existing = await client.query<{
        stripe_product_id: string;
        stripe_price_id: string;
        amount_minor: number;
        currency: string;
      }>(
        `SELECT stripe_product_id, stripe_price_id, amount_minor, currency
         FROM banner_duration_prices
         WHERE duration_months=$1 AND stripe_product_id IS NOT NULL AND stripe_price_id IS NOT NULL
         ORDER BY CASE WHEN location_id='horizontal-listings' THEN 0 ELSE 1 END
         LIMIT 1`,
        [price.months],
      );

      let canonical: typeof existing.rows[0] | undefined = existing.rows[0];
      if (canonical) {
        try {
          await stripeConnector.retrievePrice(canonical.stripe_price_id);
          validatedPriceIds.add(canonical.stripe_price_id);
        } catch (error) {
          if (error instanceof StripeConnectorError && error.stripeCode === "resource_missing") {
            canonical = undefined;
          } else {
            throw error;
          }
        }
      }
      if (!canonical) {
        const product = await stripeConnector.createProduct(
          `Banner advertising — ${price.months} month${price.months === 1 ? "" : "s"}`,
          { durationMonths: String(price.months) },
        );
        const productId = String(product.id);
        const stripePrice = await stripeConnector.createPrice(productId, price.amountMinor, {
          durationMonths: String(price.months),
        });
        canonical = {
          stripe_product_id: productId,
          stripe_price_id: String(stripePrice.id),
          amount_minor: price.amountMinor,
          currency: "CAD",
        };
      }

      for (const location of locations) {
        await client.query(
          `INSERT INTO banner_duration_prices
            (id, location_id, duration_months, amount_minor, currency, stripe_product_id, stripe_price_id)
           VALUES ($1, $2, $3, $4, $5, $6, $7)
            ON CONFLICT (location_id, duration_months) DO UPDATE SET
              amount_minor=excluded.amount_minor,
              currency=excluded.currency,
              stripe_product_id=excluded.stripe_product_id,
              stripe_price_id=excluded.stripe_price_id,
              is_active=true,
              updated_at=now()`,
          [
            `banner-price-${location.id}-${price.months}`,
            location.id,
            price.months,
            canonical.amount_minor,
            canonical.currency,
            canonical.stripe_product_id,
            canonical.stripe_price_id,
          ],
        );
      }
    }

    const legacyPrices = await client.query<{
      stripe_price_id: string;
      duration_months: number;
      amount_minor: number;
    }>(
      `SELECT DISTINCT p.stripe_price_id, p.duration_months, p.amount_minor
       FROM banner_duration_prices p
       JOIN banner_locations l ON l.id=p.location_id
       WHERE p.is_active=true AND l.is_active=true AND p.stripe_price_id IS NOT NULL`,
    );
    for (const legacy of legacyPrices.rows) {
      if (validatedPriceIds.has(legacy.stripe_price_id)) continue;
      try {
        await stripeConnector.retrievePrice(legacy.stripe_price_id);
        validatedPriceIds.add(legacy.stripe_price_id);
      } catch (error) {
        if (!(error instanceof StripeConnectorError) || error.stripeCode !== "resource_missing") throw error;
        const product = await stripeConnector.createProduct(
          `Banner advertising — ${legacy.duration_months} month${legacy.duration_months === 1 ? "" : "s"}`,
          { durationMonths: String(legacy.duration_months) },
        );
        const productId = String(product.id);
        const replacement = await stripeConnector.createPrice(productId, legacy.amount_minor, {
          durationMonths: String(legacy.duration_months),
        });
        await client.query(
          `UPDATE banner_duration_prices
           SET stripe_product_id=$1, stripe_price_id=$2, updated_at=now()
           WHERE stripe_price_id=$3`,
          [productId, String(replacement.id), legacy.stripe_price_id],
        );
        validatedPriceIds.add(String(replacement.id));
      }
    }
  } finally {
    try {
      await client.query("SELECT pg_advisory_unlock($1)", [7_314_221]);
    } finally {
      client.release();
    }
  }
}