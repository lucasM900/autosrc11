import { createClerkClient } from "@clerk/express";
import { ReplitConnectors } from "@replit/connectors-sdk";
import type { Inquiry, Listing } from "@workspace/db";

const clerk = createClerkClient({ secretKey: process.env.CLERK_SECRET_KEY });
const connectors = new ReplitConnectors();

export async function sendInquiryEmail(listing: Listing, inquiry: Inquiry): Promise<boolean> {
  // Imported marketplace records belong to a relay, not to the source seller.
  if (!listing.ownerId || listing.attributes?.externalListing === true) return false;

  const from = process.env.INQUIRY_EMAIL_FROM?.trim();
  if (!from) throw new Error("INQUIRY_EMAIL_FROM must be a verified Resend sender address");

  const owner = await clerk.users.getUser(listing.ownerId);
  const primaryEmail = owner.emailAddresses.find(
    address => address.id === owner.primaryEmailAddressId && address.verification?.status === "verified",
  );
  if (!primaryEmail) throw new Error("Listing owner has no verified primary email address");

  const response = await connectors.proxy("resend", "/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Idempotency-Key": inquiry.id,
    },
    body: JSON.stringify({
      from,
      to: [primaryEmail.emailAddress],
      reply_to: inquiry.email,
      subject: `New inquiry about your listing: ${listing.title}`,
      text: [
        `You have a new inquiry for "${listing.title}" on Autoshop Source.`,
        "",
        `From: ${inquiry.name} <${inquiry.email}>`,
        "",
        inquiry.message,
        "",
        "Reply to this email to respond to the buyer, or view the inquiry in your seller dashboard.",
      ].join("\n"),
    }),
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Resend rejected inquiry email (${response.status}): ${body.slice(0, 500)}`);
  }
  return true;
}