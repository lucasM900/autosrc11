import { ReplitConnectors } from "@replit/connectors-sdk";
import type { Listing } from "@workspace/db";

const connectors = new ReplitConnectors();

export async function sendListingCreatedEmail(listing: Listing): Promise<void> {
  const from = process.env.INQUIRY_EMAIL_FROM?.trim();
  const to = process.env.OWNER_ADMIN_EMAIL?.trim();
  if (!from || !to) {
    throw new Error("INQUIRY_EMAIL_FROM and OWNER_ADMIN_EMAIL must be configured for listing alerts");
  }

  const response = await connectors.proxy("resend", "/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Idempotency-Key": `listing-created-${listing.id}`,
    },
    body: JSON.stringify({
      from,
      to: [to],
      subject: `New listing on Autoshop Source: ${listing.title}`,
      text: [
        "A user created a new listing on Autoshop Source.",
        "",
        `Title: ${listing.title}`,
        `Listing ID: ${listing.id}`,
        `Status: ${listing.status}`,
        `Price: ${listing.price} ${listing.currencyCode}`,
        "",
        "Sign in to Autoshop Source to review it.",
      ].join("\n"),
    }),
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Resend rejected new-listing notification (${response.status}): ${body.slice(0, 500)}`);
  }
}