import { pool } from "@workspace/db";
import { StripeConnectorError, stripeConnector } from "../stripeConnector";

const PREMIUM_PRICE_ID = "premium-listing-90-days";
export const PREMIUM_LISTING_AMOUNT_MINOR = 999;

export async function ensurePremiumListingInventory(): Promise<string> {
  const client = await pool.connect();
  try {
    await client.query("SELECT pg_advisory_lock($1)", [7_314_299]);
    const existing = (await client.query<{
      stripe_price_id: string | null;
    }>("SELECT stripe_price_id FROM premium_listing_pricing WHERE id=$1", [PREMIUM_PRICE_ID])).rows[0];

    if (existing?.stripe_price_id) {
      try {
        await stripeConnector.retrievePrice(existing.stripe_price_id);
        return existing.stripe_price_id;
      } catch (error) {
        if (!(error instanceof StripeConnectorError) || error.stripeCode !== "resource_missing") throw error;
      }
    }

    const product = await stripeConnector.createProduct("Premium equipment listing — 90 days", {
      productType: "premiumListing",
      durationDays: "90",
    });
    const productId = String(product.id);
    const price = await stripeConnector.createPrice(productId, PREMIUM_LISTING_AMOUNT_MINOR, {
      productType: "premiumListing",
      durationDays: "90",
    });
    const stripePriceId = String(price.id);
    await client.query(
      `INSERT INTO premium_listing_pricing
        (id,amount_minor,currency,stripe_product_id,stripe_price_id,updated_at)
       VALUES ($1,$2,'CAD',$3,$4,now())
       ON CONFLICT (id) DO UPDATE SET
         amount_minor=excluded.amount_minor,
         currency=excluded.currency,
         stripe_product_id=excluded.stripe_product_id,
         stripe_price_id=excluded.stripe_price_id,
         updated_at=now()`,
      [PREMIUM_PRICE_ID, PREMIUM_LISTING_AMOUNT_MINOR, productId, stripePriceId],
    );
    return stripePriceId;
  } finally {
    try {
      await client.query("SELECT pg_advisory_unlock($1)", [7_314_299]);
    } finally {
      client.release();
    }
  }
}