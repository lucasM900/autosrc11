import { pool } from "@workspace/db";

const DEMO_PREMIUM_LISTING_ID = "kijiji-1593300242";

/**
 * Promote the known demo listing once per environment. The marker prevents
 * server restarts from continually extending the demonstration period.
 */
export async function ensureDemoPremiumListing(): Promise<void> {
  await pool.query(
    `UPDATE listings
        SET is_premium = true,
            premium_expires_at = now() + interval '90 days',
            expires_at = GREATEST(
              COALESCE(expires_at, now() + interval '90 days'),
              now() + interval '90 days'
            ),
            attributes = attributes || '{"demoPremium":true}'::jsonb,
            updated_at = now()
      WHERE id = $1
        AND COALESCE((attributes->>'demoPremium')::boolean, false) = false`,
    [DEMO_PREMIUM_LISTING_ID],
  );
}