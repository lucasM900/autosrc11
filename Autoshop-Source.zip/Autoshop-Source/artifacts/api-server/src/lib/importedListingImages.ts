import { objectStorageClient } from "./objectStorage";

const allowedContentTypes = new Map([
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
]);
const maxImageBytes = 8 * 1024 * 1024;

function privateStorageTarget(relativePath: string) {
  const privateDir = process.env.PRIVATE_OBJECT_DIR?.replace(/\/+$/, "");
  if (!privateDir) throw new Error("PRIVATE_OBJECT_DIR is not configured");
  const parts = privateDir.replace(/^\/+/, "").split("/");
  const bucketName = parts.shift();
  if (!bucketName) throw new Error("PRIVATE_OBJECT_DIR is invalid");
  const prefix = parts.join("/");
  return {
    file: objectStorageClient.bucket(bucketName).file(`${prefix}/${relativePath}`),
    objectPath: `/objects/${relativePath}`,
  };
}

export async function storeImportedListingImages(
  listingId: string,
  urls: string[],
): Promise<string[]> {
  const stored: string[] = [];

  for (const [index, url] of urls.slice(0, 7).entries()) {
    try {
      const initialTarget = privateStorageTarget(`imports/kijiji/${listingId}/${index + 1}`);
      const [matches] = await initialTarget.file.bucket.getFiles({
        prefix: initialTarget.file.name,
        maxResults: 1,
      });
      if (matches[0]) {
        stored.push(`/objects/${matches[0].name.split("/imports/kijiji/")[1] ? `imports/kijiji/${matches[0].name.split("/imports/kijiji/")[1]}` : matches[0].name}`);
        continue;
      }

      const response = await fetch(url, {
        headers: { "User-Agent": "AutoshopSource/1.0 image-import" },
        signal: AbortSignal.timeout(20_000),
      });
      if (!response.ok) continue;

      const contentType = response.headers.get("content-type")?.split(";")[0]?.trim().toLowerCase() ?? "";
      const extension = allowedContentTypes.get(contentType);
      if (!extension) continue;

      const declaredSize = Number(response.headers.get("content-length") ?? 0);
      if (declaredSize > maxImageBytes) continue;
      const bytes = Buffer.from(await response.arrayBuffer());
      if (bytes.length === 0 || bytes.length > maxImageBytes) continue;

      const target = privateStorageTarget(`imports/kijiji/${listingId}/${index + 1}.${extension}`);
      await target.file.save(bytes, {
        contentType,
        resumable: false,
        metadata: {
          cacheControl: "public, max-age=86400",
          metadata: { sourcePlatform: "Kijiji", importedListingId: listingId },
        },
      });
      stored.push(target.objectPath);
    } catch {
      // A single unavailable image must not prevent the listing import.
    }
  }

  return stored;
}