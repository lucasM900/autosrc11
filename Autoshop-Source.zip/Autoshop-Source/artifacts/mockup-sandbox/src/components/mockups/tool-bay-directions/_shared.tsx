import { ArrowUpRight, ChevronDown, MapPin, Search, ShieldCheck, Wrench } from "lucide-react";
import type { ReactNode } from "react";
import "./_group.css";

type Direction = "catalog" | "editorial" | "command";

const listings = [
  { condition: "Used", title: "Rotary SPOA10 2-post lift", spec: "10,000 lb · symmetric arms · ALI certified", category: "Vehicle lifts", location: "Mississauga, ON", price: "$5,800" },
  { condition: "Refurbished", title: "Miller Millermatic 252", spec: "200/230V · cart and regulator included", category: "Welding", location: "Hamilton, ON", price: "$3,450" },
  { condition: "Used", title: "Sullair 185 portable compressor", spec: "185 CFM · 2,180 hours · diesel", category: "Compressors", location: "Oshawa, ON", price: "$12,900" },
];

const directionCopy: Record<Direction, { eyebrow: string; title: string; lede: string; action: string }> = {
  catalog: {
    eyebrow: "GTA equipment index / live inventory",
    title: "The working equipment catalog.",
    lede: "Compare specifications, condition, location, and asking price without sales noise.",
    action: "Search inventory",
  },
  editorial: {
    eyebrow: "Bought from people who used it",
    title: "Good equipment deserves another shop.",
    lede: "Find proven machines, learn their history, and deal directly with mechanics and owners across the GTA.",
    action: "Find equipment",
  },
  command: {
    eyebrow: "Live board / Greater Toronto Area",
    title: "Equipment moves fast. Move faster.",
    lede: "Active shop equipment, direct seller access, no auction delay, no marketplace markup.",
    action: "Scan the board",
  },
};

function Filters({ direction }: { direction: Direction }) {
  return (
    <aside className="filters">
      <div className="filters-heading">
        <span>Filter inventory</span>
        <button type="button">Reset</button>
      </div>
      {["Category", "Equipment type", "Condition"].map((label, index) => (
        <label className="filter-control" key={label}>
          <span>{label}</span>
          <button type="button">{index === 0 ? "All categories" : index === 1 ? "Select type" : "Select condition"} <ChevronDown size={15} /></button>
        </label>
      ))}
      <label className="filter-control">
        <span>Price range</span>
        <div className="price-pair"><input placeholder="Min" /><input placeholder="Max" /></div>
      </label>
      <label className="filter-control">
        <span>Location</span>
        <button type="button"><MapPin size={14} /> Address or city</button>
      </label>
      <div className="filter-note">{direction === "catalog" ? "Filters update the index instantly." : direction === "editorial" ? "Direct listings from verified account holders." : "Showing active listings only."}</div>
    </aside>
  );
}

function Listing({ item, index, direction }: { item: typeof listings[number]; index: number; direction: Direction }) {
  return (
    <article className="listing">
      <div className={`listing-media media-${index + 1}`}>
        <span>{direction === "catalog" ? `0${index + 1}` : item.category}</span>
        <Wrench size={32} strokeWidth={1.3} />
      </div>
      <div className="listing-main">
        <div className="listing-title-line">
          <span className="condition">{item.condition}</span>
          <h3>{item.title}</h3>
        </div>
        <p>{item.spec}</p>
      </div>
      <div className="listing-fact"><span>Category</span><strong>{item.category}</strong></div>
      <div className="listing-fact"><span>Location</span><strong>{item.location}</strong></div>
      <div className="listing-price"><span>Asking</span><strong>{item.price}</strong></div>
      <button className="view-button" aria-label={`View ${item.title}`}><ArrowUpRight size={18} /></button>
    </article>
  );
}

export function ToolBayDirection({ direction }: { direction: Direction }) {
  const copy = directionCopy[direction];
  return (
    <div className={`tool-bay direction-${direction}`}>
      <header className="topbar">
        <div className="wordmark"><Wrench size={22} /> TOOL BAY <b>DIRECT</b></div>
        <div className="trust-note"><ShieldCheck size={16} /> Direct from GTA shops and owners</div>
        <nav><button>Sign in</button><button className="list-button">List equipment</button></nav>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">{copy.eyebrow}</p>
          <h1>{copy.title}</h1>
          <p className="lede">{copy.lede}</p>
          <div className="search">
            <Search size={20} />
            <input placeholder="Search lifts, welders, compressors..." />
            <button>{copy.action} <ArrowUpRight size={16} /></button>
          </div>
        </div>
        {direction === "editorial" && (
          <div className="editorial-story">
            <p>Seller note</p>
            <blockquote>“Maintained in our own service bay. Ready for removal next week.”</blockquote>
            <span>Rotary SPOA10 · Mississauga</span>
          </div>
        )}
        {direction === "command" && (
          <div className="command-metrics"><strong>47</strong><span>active listings</span><strong>12</strong><span>added this week</span></div>
        )}
      </section>

      <main>
        <div className="market-heading">
          <div><p>Open board</p><h2>Available equipment</h2></div>
          <div className="market-status"><i /> 47 active · Updated now</div>
        </div>
        <div className="market-layout">
          <Filters direction={direction} />
          <section className="results">
            <div className="summary">
              {[["47", "Active"], ["12", "Vehicle lifts"], ["9", "Welding"], ["8", "Compressors"]].map(([value, label]) => (
                <div key={label}><strong>{value}</strong><span>{label}</span></div>
              ))}
            </div>
            <div className="listings">
              {listings.map((item, index) => <Listing key={item.title} item={item} index={index} direction={direction} />)}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}