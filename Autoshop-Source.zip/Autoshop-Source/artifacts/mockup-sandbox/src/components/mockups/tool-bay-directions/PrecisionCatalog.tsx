import { ToolBayDirection } from "./_shared";

export function PrecisionCatalog() {
  return <ToolBayDirection direction="catalog" />;
}