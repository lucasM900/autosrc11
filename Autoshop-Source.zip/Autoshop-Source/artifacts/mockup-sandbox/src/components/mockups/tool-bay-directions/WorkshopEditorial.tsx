import { ToolBayDirection } from "./_shared";

export function WorkshopEditorial() {
  return <ToolBayDirection direction="editorial" />;
}