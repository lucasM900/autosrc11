import { ToolBayDirection } from "./_shared";

export function IndustrialCommand() {
  return <ToolBayDirection direction="command" />;
}