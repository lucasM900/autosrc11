import { Link } from 'wouter';
import { AlertCircle, LockKeyhole, Mail } from 'lucide-react';

export function AccountHeading({ label, title, description }: { label: string; title: string; description?: string }) {
  return <div className="account-heading"><div><span className="account-kicker">{label}</span><h1>{title}</h1>{description && <p>{description}</p>}</div></div>;
}

export function AccountLoading() {
  return <div aria-label="Loading" data-testid="status-account-loading"><div className="skeleton-row account-skeleton" /><div className="skeleton-row account-skeleton" /><div className="skeleton-row account-skeleton" /></div>;
}

export function AccountError({ onRetry, title = 'Could not load this page' }: { onRetry: () => void; title?: string }) {
  return <div className="state-panel" role="alert" data-testid="status-account-error"><AlertCircle size={30} /><h3>{title}</h3><p>Check your connection and try again.</p><button type="button" className="state-action" onClick={onRetry} data-testid="button-retry-account">Try again</button></div>;
}

export function AccountSignIn({ message = 'Sign in to access your account.' }: { message?: string }) {
  return <div className="state-panel" data-testid="status-sign-in-required"><LockKeyhole size={30} /><h3>Sign in required</h3><p>{message}</p><Link href="/sign-in" className="state-action inline-block" data-testid="link-sign-in-account">Sign in</Link></div>;
}

export function AccountEmpty({ title, description }: { title: string; description: string }) {
  return <div className="state-panel" data-testid="status-account-empty"><Mail size={30} /><h3>{title}</h3><p>{description}</p></div>;
}