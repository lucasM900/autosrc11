import { useEffect, useRef } from 'react';
import { useClerk } from '@clerk/react';
import { useLocation } from 'wouter';
import { trackWebsiteEvent } from '../lib/analytics';

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
  }
}

export function WebsiteAnalyticsTracker() {
  const [location] = useLocation();
  const { addListener } = useClerk();
  const previousUserId = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    trackWebsiteEvent('page_view', location.split('?')[0] || '/');

    // The shared tag disables its automatic initial page view so this records
    // exactly one view for both the first load and client-side route changes.
    window.gtag?.('event', 'page_view', {
      page_path: location,
      page_location: window.location.href,
      page_title: document.title,
    });
  }, [location]);

  useEffect(() => {
    return addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (previousUserId.current === null && userId) {
        const authEvent = window.location.pathname.includes('/sign-up') ? 'signup' : 'login';
        trackWebsiteEvent(authEvent, window.location.pathname);
      }
      previousUserId.current = userId;
    });
  }, [addListener]);

  return null;
}