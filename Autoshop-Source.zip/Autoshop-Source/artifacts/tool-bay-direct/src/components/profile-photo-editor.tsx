import { useEffect, useRef, useState } from 'react';
import type { ChangeEvent, PointerEvent } from 'react';

type Mode = 'fit' | 'fill';
type Props = {
  file: File;
  busy: boolean;
  stage: string;
  uploadError: string;
  onCancel: () => void;
  onReplace: (file: File) => void;
  onSave: (file: File) => Promise<void>;
};

const SIZE = 512;
const FIT_SIZE = SIZE / Math.SQRT2;
const BACKGROUND = '#e8eee9';

export function ProfilePhotoEditor({ file, busy, stage, uploadError, onCancel, onReplace, onSave }: Props) {
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [loadError, setLoadError] = useState(false);
  const [exportError, setExportError] = useState(false);
  const [mode, setMode] = useState<Mode>('fill');
  const [zoom, setZoom] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [preparing, setPreparing] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const pointerRef = useRef<{ x: number; y: number; id: number } | null>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  imageRef.current = image;
  const isBusy = busy || preparing;

  useEffect(() => {
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const priorOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    closeRef.current?.focus();
    return () => {
      document.body.style.overflow = priorOverflow;
      previousFocus?.focus();
    };
  }, []);

  useEffect(() => {
    const url = URL.createObjectURL(file);
    const next = new Image();
    let active = true;
    setImage(null);
    setLoadError(false);
    setExportError(false);
    setPosition({ x: 0, y: 0 });
    setZoom(1);
    setMode('fill');
    next.onload = () => {
      if (!active) return;
      if (!next.naturalWidth || !next.naturalHeight) setLoadError(true);
      else setImage(next);
    };
    next.onerror = () => { if (active) setLoadError(true); };
    next.src = url;
    return () => {
      active = false;
      next.onload = null;
      next.onerror = null;
      URL.revokeObjectURL(url);
    };
  }, [file]);

  const dimensions = image ? {
    width: image.naturalWidth * (mode === 'fill'
      ? Math.max(SIZE / image.naturalWidth, SIZE / image.naturalHeight)
      : Math.min(FIT_SIZE / image.naturalWidth, FIT_SIZE / image.naturalHeight)) * zoom,
    height: image.naturalHeight * (mode === 'fill'
      ? Math.max(SIZE / image.naturalWidth, SIZE / image.naturalHeight)
      : Math.min(FIT_SIZE / image.naturalWidth, FIT_SIZE / image.naturalHeight)) * zoom,
  } : null;

  const constrain = (x: number, y: number, width = dimensions?.width ?? SIZE, height = dimensions?.height ?? SIZE) => {
    const limitX = mode === 'fit' && width <= FIT_SIZE ? (FIT_SIZE - width) / 2 : mode === 'fit' && width < SIZE ? 0 : Math.abs(width - SIZE) / 2;
    const limitY = mode === 'fit' && height <= FIT_SIZE ? (FIT_SIZE - height) / 2 : mode === 'fit' && height < SIZE ? 0 : Math.abs(height - SIZE) / 2;
    return { x: Math.max(-limitX, Math.min(limitX, x)), y: Math.max(-limitY, Math.min(limitY, y)) };
  };

  const draw = (canvas: HTMLCanvasElement) => {
    const source = imageRef.current;
    if (!source || !source.naturalWidth || !source.naturalHeight) throw new Error('Image unavailable');
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas unavailable');
    const base = (mode === 'fill'
      ? Math.max(SIZE / source.naturalWidth, SIZE / source.naturalHeight)
      : Math.min(FIT_SIZE / source.naturalWidth, FIT_SIZE / source.naturalHeight)) * zoom;
    const width = source.naturalWidth * base;
    const height = source.naturalHeight * base;
    const offset = constrain(position.x, position.y, width, height);
    ctx.fillStyle = BACKGROUND;
    ctx.fillRect(0, 0, SIZE, SIZE);
    ctx.save();
    ctx.beginPath();
    ctx.arc(SIZE / 2, SIZE / 2, SIZE / 2, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(source, (SIZE - width) / 2 + offset.x, (SIZE - height) / 2 + offset.y, width, height);
    ctx.restore();
  };

  useEffect(() => {
    if (!image || !canvasRef.current) return;
    try {
      draw(canvasRef.current);
      setExportError(false);
    } catch {
      setExportError(true);
    }
  }, [image, mode, zoom, position]);

  const nudge = (dx: number, dy: number) => setPosition(previous => constrain(previous.x + dx, previous.y + dy));

  const pointerStart = (event: PointerEvent<HTMLDivElement>) => {
    if (isBusy || !image) return;
    pointerRef.current = { x: event.clientX, y: event.clientY, id: event.pointerId };
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const pointerMove = (event: PointerEvent<HTMLDivElement>) => {
    const previous = pointerRef.current;
    if (!previous || previous.id !== event.pointerId || isBusy) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const ratio = SIZE / rect.width;
    nudge((event.clientX - previous.x) * ratio, (event.clientY - previous.y) * ratio);
    pointerRef.current = { x: event.clientX, y: event.clientY, id: event.pointerId };
  };

  const save = async () => {
    if (!image || isBusy) return;
    setPreparing(true);
    setExportError(false);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = SIZE;
      canvas.height = SIZE;
      draw(canvas);
      const blob = await new Promise<Blob>((resolve, reject) => {
        canvas.toBlob(result => result ? resolve(result) : reject(new Error('Export unavailable')), 'image/jpeg', 0.9);
      });
      await onSave(new File([blob], 'profile-photo.jpg', { type: 'image/jpeg' }));
    } catch {
      // Upload errors are shown separately by the page; only canvas failures reach here.
      if (!uploadError) setExportError(true);
    } finally {
      setPreparing(false);
    }
  };

  const replace = (event: ChangeEvent<HTMLInputElement>) => {
    const replacement = event.currentTarget.files?.[0];
    event.currentTarget.value = '';
    if (replacement) onReplace(replacement);
  };

  return <div className="profile-photo-editor-backdrop" onMouseDown={event => { if (event.target === event.currentTarget && !isBusy) onCancel(); }}>
    <div className="profile-photo-editor" role="dialog" aria-modal="true" aria-labelledby="photo-editor-title" aria-describedby="photo-editor-description" ref={dialogRef}
      onKeyDown={event => {
        if (event.key === 'Escape' && !isBusy) { event.preventDefault(); onCancel(); }
        if (event.key !== 'Tab') return;
        const elements = Array.from(dialogRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled)') ?? []).filter(el => el.getClientRects().length);
        if (!elements.length) return;
        if (event.shiftKey && document.activeElement === elements[0]) { event.preventDefault(); elements[elements.length - 1].focus(); }
        else if (!event.shiftKey && document.activeElement === elements[elements.length - 1]) { event.preventDefault(); elements[0].focus(); }
      }}>
      <header>
        <div><h2 id="photo-editor-title">Position your picture</h2><p id="photo-editor-description">Make it yours before it appears on your profile.</p></div>
        <button ref={closeRef} type="button" className="profile-photo-editor-close" aria-label="Close picture editor" onClick={onCancel} disabled={isBusy} data-testid="button-close-photo-editor">×</button>
      </header>
      <div className="profile-photo-editor-grid">
        <div className="profile-photo-preview-wrap">
          <div className="profile-photo-preview" onPointerDown={pointerStart} onPointerMove={pointerMove} onPointerUp={() => { pointerRef.current = null; }} onPointerCancel={() => { pointerRef.current = null; }} role="img" aria-label="Circular preview of your profile picture; drag to reposition">
            <canvas ref={canvasRef} width={SIZE} height={SIZE} data-testid="canvas-profile-photo-preview" />
          </div>
          <small>Drag the picture to position it within the circle.</small>
        </div>
        <div className="profile-photo-editor-controls">
          <fieldset disabled={isBusy || !image}><legend>Picture style</legend>
            <div className="profile-photo-mode">
              <label><input type="radio" name="photo-mode" value="fill" checked={mode === 'fill'} onChange={() => { setMode('fill'); setPosition({ x: 0, y: 0 }); }} data-testid="input-photo-fill" />Fill</label>
              <label><input type="radio" name="photo-mode" value="fit" checked={mode === 'fit'} onChange={() => { setMode('fit'); setPosition({ x: 0, y: 0 }); }} data-testid="input-photo-fit" />Fit</label>
            </div>
          </fieldset>
          <small>{mode === 'fit' ? 'Fit keeps the whole picture visible at 100%, with a soft background.' : 'Fill covers the circle, trimming the edges.'}</small>
          <div><label htmlFor="profile-photo-zoom" className="profile-photo-zoom-label">Zoom · {Math.round(zoom * 100)}%</label>
            <input id="profile-photo-zoom" type="range" min="1" max="3" step="0.01" value={zoom} onChange={event => setZoom(Number(event.target.value))} disabled={isBusy || !image} data-testid="input-photo-zoom" />
          </div>
          <div className="profile-photo-nudge"><span>Move precisely</span>
            <button type="button" aria-label="Move picture left" onClick={() => nudge(-16, 0)} disabled={isBusy || !image} data-testid="button-photo-left">←</button>
            <button type="button" aria-label="Move picture up" onClick={() => nudge(0, -16)} disabled={isBusy || !image} data-testid="button-photo-up">↑</button>
            <button type="button" aria-label="Move picture down" onClick={() => nudge(0, 16)} disabled={isBusy || !image} data-testid="button-photo-down">↓</button>
            <button type="button" aria-label="Move picture right" onClick={() => nudge(16, 0)} disabled={isBusy || !image} data-testid="button-photo-right">→</button>
          </div>
        </div>
      </div>
      {loadError && <p role="alert" className="account-feedback error profile-photo-editor-error">This picture could not be opened. Try a different JPEG, PNG or WebP file.</p>}
      {exportError && !loadError && <p role="alert" className="account-feedback error profile-photo-editor-error">We could not prepare this picture. Try a different file or adjust the crop and retry.</p>}
      {uploadError && <p role="alert" className="account-feedback error profile-photo-editor-error" data-testid="status-profile-photo-error">{uploadError}</p>}
      {isBusy && <p role="status" data-testid="status-profile-photo-loading">{stage || 'Preparing picture…'}</p>}
      <div className="profile-photo-editor-footer">
        <div><input className="profile-photo-input" id="profile-photo-replace" type="file" accept="image/jpeg,image/png,image/webp" onChange={replace} disabled={isBusy} data-testid="input-replace-profile-photo" /><label className="button-secondary" aria-disabled={isBusy} htmlFor="profile-photo-replace">Replace picture</label>
          <button type="button" className="button-secondary" onClick={onCancel} disabled={isBusy} data-testid="button-cancel-photo-editor">Cancel</button></div>
        <button type="button" className="button-primary" onClick={() => void save()} disabled={isBusy || !image || loadError} data-testid="button-save-profile-photo">{busy ? stage : uploadError ? 'Retry upload' : 'Save picture'}</button>
      </div>
    </div>
  </div>;
}