import { useState, useRef, useEffect, useId, KeyboardEvent, ChangeEvent } from 'react';
import { useSearchLocations, LocationSuggestion, getSearchLocationsQueryKey } from '@workspace/api-client-react';
import { reverseLocation } from '@workspace/api-client-react';
import { LoaderCircle, LocateFixed, MapPin } from 'lucide-react';

interface LocationAutocompleteProps {
  value: string;
  onChange: (value: string, suggestion?: LocationSuggestion) => void;
  onClear: () => void;
  placeholder?: string;
  inputId?: string;
  inputName?: string;
  onBlur?: () => void;
  maxLength?: number;
  testId?: string;
  onCurrentLocation?: (coordinates: { latitude: number; longitude: number }) => void;
}

export function LocationAutocomplete({ value, onChange, onClear, placeholder, inputId, inputName, onBlur, maxLength, testId, onCurrentLocation }: LocationAutocompleteProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [locating, setLocating] = useState(false);
  const [locationError, setLocationError] = useState('');
  const locateRequest = useRef(0);
  const generatedId = useId();
  const listId = `${inputId || generatedId}-suggestions`;
  const [inputValue, setInputValue] = useState(value);
  const [debouncedValue, setDebouncedValue] = useState(value);
  
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Update internal input when external value changes completely 
  // (like form reset or initial load)
  useEffect(() => {
    setInputValue(value);
  }, [value]);

  useEffect(() => () => { locateRequest.current += 1; }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedValue(inputValue);
    }, 300);
    return () => clearTimeout(timer);
  }, [inputValue]);

  const { data: suggestions, isLoading, isError } = useSearchLocations(
    { q: debouncedValue },
    { query: { enabled: debouncedValue.length >= 2, retry: false, queryKey: getSearchLocationsQueryKey({ q: debouncedValue }) } }
  );

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const visibleSuggestions = debouncedValue === inputValue ? suggestions : undefined;
  const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Escape' && isOpen) {
      setIsOpen(false);
      setActiveIndex(-1);
      e.stopPropagation();
    } else if (e.key === 'ArrowDown' && visibleSuggestions?.length) {
      e.preventDefault();
      setIsOpen(true);
      setActiveIndex(i => (i + 1) % visibleSuggestions.length);
    } else if (e.key === 'ArrowUp' && visibleSuggestions?.length) {
      e.preventDefault();
      setIsOpen(true);
      setActiveIndex(i => i <= 0 ? visibleSuggestions.length - 1 : i - 1);
    } else if (e.key === 'Enter' && isOpen && activeIndex >= 0 && visibleSuggestions?.[activeIndex]) {
      e.preventDefault();
      handleSelect(visibleSuggestions[activeIndex]);
    }
  };

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    locateRequest.current += 1;
    setLocating(false);
    setLocationError('');
    const newVal = e.target.value;
    setInputValue(newVal);
    setIsOpen(true);
    setActiveIndex(-1);
    
    // Clear selected suggestion details on manual typing
    if (newVal !== value) {
      onClear();
      onChange(newVal); // just emit text string, no suggestion attached
    }
  };

  const handleSelect = (suggestion: LocationSuggestion) => {
    locateRequest.current += 1;
    setLocating(false);
    setLocationError('');
    setInputValue(suggestion.label);
    onChange(suggestion.label, suggestion);
    setIsOpen(false);
    setActiveIndex(-1);
  };

  const useMyLocation = () => {
    if (locating) return;
    setLocationError('');
    if (!navigator.geolocation) {
      setLocationError('Your browser cannot share your location. Search for a city instead.');
      return;
    }
    const request = ++locateRequest.current;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      async ({ coords }) => {
        if (request !== locateRequest.current) return;
        try {
          if (onCurrentLocation) {
            onChange('Current Location');
            onCurrentLocation({ latitude: coords.latitude, longitude: coords.longitude });
            setInputValue('Current Location');
          } else {
            const nearby = await reverseLocation({ latitude: coords.latitude, longitude: coords.longitude });
            if (request !== locateRequest.current) return;
            onChange(nearby.label, nearby);
            setInputValue(nearby.label);
          }
          setIsOpen(false);
          setActiveIndex(-1);
        } catch {
          if (request === locateRequest.current) setLocationError('We found your position but could not find a nearby city. Search for a city instead.');
        } finally {
          if (request === locateRequest.current) setLocating(false);
        }
      },
      (error) => {
        if (request !== locateRequest.current) return;
        setLocating(false);
        setLocationError(error.code === 1
          ? 'Location access was blocked. Allow it in your browser settings, or search for a city.'
          : error.code === 3
            ? 'Finding your location took too long. Try again or search for a city.'
            : 'We could not determine your location. Try again or search for a city.');
      },
      { enableHighAccuracy: false, timeout: 12_000, maximumAge: 60_000 },
    );
  };

  return (
    <div className="relative" ref={containerRef} onKeyDown={handleKeyDown}>
      <div className="relative filter-input-wrap">
        <input
          type="text"
          id={inputId}
          name={inputName}
          value={inputValue}
          onChange={handleInputChange}
          onBlur={onBlur}
          onFocus={() => {
            if (inputValue.length >= 2) setIsOpen(true);
          }}
          placeholder={placeholder || 'Search for a location...'}
          className="filter-control pr-10"
          role="combobox"
          aria-expanded={isOpen}
          aria-autocomplete="list"
          autoComplete="off"
          maxLength={maxLength}
          data-testid={testId}
          aria-controls={listId}
          aria-activedescendant={isOpen && activeIndex >= 0 && visibleSuggestions?.[activeIndex] ? `${listId}-option-${activeIndex}` : undefined}
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-steel-line">
          {isLoading && debouncedValue.length >= 2 ? (
            <LoaderCircle size={16} className="spin-icon" />
          ) : (
            <MapPin size={16} />
          )}
        </div>
      </div>

      {isOpen && inputValue.length >= 2 && (
        <div id={listId} className="filter-panel-body" role="listbox" aria-label="Location suggestions">
          <div className="py-1 flex flex-col max-h-60 overflow-y-auto">
            {isLoading && (
              <div className="p-3 text-sm text-steel-line text-center">
                Loading...
              </div>
            )}
            
            {isError && !isLoading && (
              <div className="p-3 text-sm text-oxide text-center">
                Failed to load locations
              </div>
            )}

            {!isLoading && !isError && visibleSuggestions && visibleSuggestions.length === 0 && (
              <div className="p-3 text-sm text-steel-line text-center">
                No locations found
              </div>
            )}

            {!isLoading && !isError && visibleSuggestions && visibleSuggestions.map((s, idx) => (
              <button
                id={`${listId}-option-${idx}`}
                key={`${s.label}-${idx}`}
                type="button"
                onClick={() => handleSelect(s)}
                className="filter-option font-medium"
                role="option"
                aria-selected={activeIndex === idx}
                data-testid={`option-location-${idx}`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      )}
      <button type="button" className="location-use-button" onClick={useMyLocation} disabled={locating} data-testid="button-use-my-location">
        {locating ? <LoaderCircle size={16} className="spin-icon" aria-hidden="true" /> : <LocateFixed size={16} aria-hidden="true" />}
        {locating ? 'Finding your location…' : 'Use My Location'}
      </button>
      <p className="location-use-help">Your browser will ask for permission. You can search for a city instead.</p>
      {locationError && <p className="location-use-error" role="alert">{locationError}</p>}
    </div>
  );
}
