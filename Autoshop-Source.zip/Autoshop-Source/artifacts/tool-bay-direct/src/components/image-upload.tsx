import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useUpload } from '../hooks/use-upload';
import { ArrowLeft, ArrowRight, Check, LoaderCircle, X, ImagePlus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ImageUploadProps {
  value: string[];
  onChange: (value: string[]) => void;
  maxFiles?: number;
}

export function ImageUpload({ value, onChange, maxFiles = 7 }: ImageUploadProps) {
  const { uploadFile, isUploading } = useUpload();
  const { toast } = useToast();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (value.length + acceptedFiles.length > maxFiles) {
      toast({
        variant: "destructive",
        title: "Too many files",
        description: `You can only upload up to ${maxFiles} images.`,
      });
      return;
    }

    const newPaths = [...value];
    
    for (const file of acceptedFiles) {
      try {
        const objectPath = await uploadFile(file);
        newPaths.push(objectPath);
        onChange([...newPaths]);
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Upload failed",
          description: error instanceof Error ? error.message : "Failed to upload image.",
        });
      }
    }
  }, [value, maxFiles, uploadFile, onChange, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.webp']
    },
    disabled: isUploading || value.length >= maxFiles
  });

  const removeImage = (index: number) => {
    const newPaths = [...value];
    newPaths.splice(index, 1);
    onChange(newPaths);
  };

  const moveImage = (index: number, direction: -1 | 1) => {
    const nextIndex = index + direction;
    if (nextIndex < 0 || nextIndex >= value.length) return;
    const newPaths = [...value];
    [newPaths[index], newPaths[nextIndex]] = [newPaths[nextIndex], newPaths[index]];
    onChange(newPaths);
  };

  const setCover = (index: number) => {
    if (index === 0) return;
    const newPaths = [...value];
    const [cover] = newPaths.splice(index, 1);
    newPaths.unshift(cover);
    onChange(newPaths);
  };

  return (
    <div>
      {value.length < maxFiles && (
        <div 
          {...getRootProps()} 
          className={`image-upload-area ${isDragActive ? 'active' : ''} ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <input {...getInputProps()} data-testid="input-image-upload" />
          {isUploading ? (
            <div className="flex flex-col items-center gap-2 text-steel-line">
              <LoaderCircle className="animate-spin" />
              <span>Uploading...</span>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2 text-steel-line">
              <ImagePlus size={32} />
              <span>Drag & drop images here, or click to select</span>
              <span className="text-xs">Supports JPG, PNG, WEBP (Max {maxFiles})</span>
            </div>
          )}
        </div>
      )}

      {value.length > 0 && (
        <div className="image-preview-grid">
          {value.map((path, index) => (
            <div key={`${path}-${index}`} className={`image-preview-item ${index === 0 ? 'is-cover' : ''}`}>
              <img src={`/api/storage${path}`} alt={`${index === 0 ? 'Cover image, ' : ''}Upload ${index + 1}`} />
              {index === 0 && <span className="image-cover-badge"><Check size={12} /> Cover</span>}
              <div className="image-order-controls" aria-label={`Controls for image ${index + 1}`}>
                <button
                  type="button"
                  onClick={() => moveImage(index, -1)}
                  className="image-order-btn"
                  title="Move image left"
                  aria-label={`Move image ${index + 1} left`}
                  disabled={index === 0}
                  data-testid={`btn-move-image-left-${index}`}
                >
                  <ArrowLeft size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => moveImage(index, 1)}
                  className="image-order-btn"
                  title="Move image right"
                  aria-label={`Move image ${index + 1} right`}
                  disabled={index === value.length - 1}
                  data-testid={`btn-move-image-right-${index}`}
                >
                  <ArrowRight size={14} />
                </button>
              </div>
              {index !== 0 && (
                <button
                  type="button"
                  onClick={() => setCover(index)}
                  className="image-cover-btn"
                  aria-label={`Set image ${index + 1} as cover`}
                  data-testid={`btn-set-cover-${index}`}
                >
                  Set as cover
                </button>
              )}
              <button
                type="button" 
                onClick={() => removeImage(index)}
                className="image-remove-btn"
                title="Remove image"
                aria-label={`Remove image ${index + 1}`}
                data-testid={`btn-remove-image-${index}`}
              >
                <X size={14} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
