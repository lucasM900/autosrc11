import { Link } from 'wouter';
import { ShieldCheck, Wrench, Megaphone, Settings2, UserRound, MessageCircle, LayoutDashboard, LogOut, Plus } from 'lucide-react';
import { Show, useAuth, useClerk } from '@clerk/react';
import { getGetOwnerAdminAccessQueryKey, getListBannerCampaignsQueryKey, useGetOwnerAdminAccess, useListBannerCampaigns } from '@workspace/api-client-react';

export function Header() {
  const { signOut } = useClerk();
  const { isSignedIn } = useAuth();
  const ownerAccess = useGetOwnerAdminAccess({
    query: {
      queryKey: getGetOwnerAdminAccessQueryKey(),
      enabled: isSignedIn === true,
      retry: false,
      staleTime: 5 * 60 * 1000,
    },
  });
  const campaigns = useListBannerCampaigns({
    query: {
      queryKey: getListBannerCampaignsQueryKey(),
      enabled: isSignedIn === true,
      retry: false,
      staleTime: 60_000,
    },
  });
  const hasPaidAd = campaigns.data?.some(campaign => Boolean(campaign.purchaseAt)) ?? false;

  return (
    <header className="site-header">
      <div className="site-header-inner">
        <Link href="/" className="brand-mark" data-testid="link-home">
          <span className="brand-icon"><Wrench size={19} strokeWidth={2.2} aria-hidden="true" /></span> AUTOSHOP <span>SOURCE</span>
        </Link>
        <div className="header-note">
          <ShieldCheck size={16} strokeWidth={1.9} aria-hidden="true" /> Direct listings from mechanics, shops, and equipment owners worldwide
        </div>
        <div className="header-actions">
          <Show when="signed-in">
            <Link href="/messages" className="header-link" data-testid="link-header-messages">
              <MessageCircle aria-hidden="true" /> Messages
            </Link>
            <Link href="/profile" className="header-link" data-testid="link-header-profile">
              <UserRound aria-hidden="true" /> Profile
            </Link>
            {hasPaidAd && (
              <Link href="/advertise/dashboard" className="header-link" data-testid="link-ad-dashboard">
                <Megaphone aria-hidden="true" /> My ads
              </Link>
            )}
            {ownerAccess.data?.isAdmin && (
              <Link href="/admin/advertising" className="header-link font-bold text-[var(--yellow)]" data-testid="link-owner-admin">
                <Settings2 aria-hidden="true" /> Owner admin
              </Link>
            )}
            <Link href="/seller" className="header-link" data-testid="link-dashboard">
              <LayoutDashboard aria-hidden="true" /> Dashboard
            </Link>
            <button 
              type="button" 
              className="header-link" 
              onClick={() => signOut({ redirectUrl: '/' })}
              data-testid="button-sign-out"
            >
              <LogOut aria-hidden="true" /> Sign out
            </button>
            <Link href="/seller/listings/new" className="header-button" data-testid="link-create-listing">
              <Plus size={16} strokeWidth={2.2} aria-hidden="true" /> List equipment
            </Link>
          </Show>
          <Show when="signed-out">
            <Link href="/sign-in" className="header-link" data-testid="link-sign-in">Sign in</Link>
            <Link href="/sign-up" className="header-button" data-testid="link-sign-up">Sign up</Link>
          </Show>
        </div>
      </div>
    </header>
  );
}
