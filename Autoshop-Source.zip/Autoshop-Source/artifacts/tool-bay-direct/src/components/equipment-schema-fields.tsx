import { useFormContext } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from './ui/form';
import { getCategoryFields, getCategorySchema, getFieldOptions } from '../lib/equipment-schema';
import { ChevronDown } from 'lucide-react';
import { MultiSelect } from './multi-select';
import { SuggestionInput } from './suggestion-input';
import { getManufacturerSuggestions, getModelSuggestions } from '../lib/equipment-catalog';
import { getAttributeWithLegacyAliases } from '@workspace/api-zod';

interface EquipmentSchemaFieldsProps {
  category: string;
}

export function EquipmentSchemaFields({ category }: EquipmentSchemaFieldsProps) {
  const { control, watch, setValue } = useFormContext();
  const schema = getCategorySchema(category);

  if (!schema) return null;

  const equipmentType = watch('attributes.equipmentType');
  const manufacturer = watch('attributes.manufacturer') || '';
  const currentAttributes = watch('attributes') || {};
  const fields = getCategoryFields(category);

  return (
    <>
      <FormField
        control={control}
        name="attributes.equipmentType"
        render={({ field }) => (
          <FormItem className="form-field full">
            <FormLabel>Equipment Type</FormLabel>
            <FormControl>
              <div className="select-wrap">
                <select
                  {...field}
                  value={field.value || ''}
                  onChange={(e) => {
                    // Atomically set equipmentType and wipe out other attributes
                    setValue('attributes', { equipmentType: e.target.value }, { shouldValidate: true, shouldDirty: true });
                  }}
                >
                  <option value="" disabled>Select Type...</option>
                  {schema.types.map((type) => (
                    <option key={type.id} value={type.id}>
                      {type.label}
                    </option>
                  ))}
                </select>
                <ChevronDown size={15} />
              </div>
            </FormControl>
            <FormMessage className="field-error" />
          </FormItem>
        )}
      />

      {equipmentType && (
        <div className="form-field full specification-guide">
          <span className="specification-guide-kicker">Searchable specifications</span>
          <strong>Choose the details buyers can filter by</strong>
          <p>These options are identical to the marketplace filters, helping the right buyers find this equipment.</p>
        </div>
      )}

      {equipmentType && fields.map((fieldDef) => {
        const fieldName = `attributes.${fieldDef.key}`;
        const options = getFieldOptions(fieldDef);
        
        return (
          <FormField
            key={fieldDef.key}
            control={control}
            name={fieldName}
            render={({ field }) => {
              const legacyValue = getAttributeWithLegacyAliases(currentAttributes, fieldDef.key);
              const fieldValue = field.value !== undefined && field.value !== '' ? field.value : legacyValue;

              if (fieldDef.key === 'manufacturer') {
                return (
                  <FormItem className="form-field">
                    <FormLabel>{fieldDef.label}</FormLabel>
                    <FormControl>
                      <SuggestionInput
                        value={field.value || ''}
                        onChange={value => {
                          field.onChange(value);
                          const currentModel = watch('attributes.model');
                          if (currentModel) setValue('attributes.model', '', { shouldDirty: true });
                        }}
                        suggestions={getManufacturerSuggestions(category, equipmentType)}
                        placeholder="Start typing a brand..."
                        ariaLabel="Manufacturer or brand"
                      />
                    </FormControl>
                    <FormMessage className="field-error" />
                  </FormItem>
                );
              }

              if (fieldDef.key === 'model') {
                return (
                  <FormItem className="form-field">
                    <FormLabel>{fieldDef.label}</FormLabel>
                    <FormControl>
                      <SuggestionInput
                        value={field.value || ''}
                        onChange={field.onChange}
                        suggestions={getModelSuggestions(category, equipmentType, manufacturer)}
                        placeholder={manufacturer ? `Search ${manufacturer} models...` : 'Choose a brand or type a model...'}
                        ariaLabel="Equipment model"
                      />
                    </FormControl>
                    <FormMessage className="field-error" />
                  </FormItem>
                );
              }

              if (fieldDef.kind === 'select') {
                return (
                  <FormItem className="form-field">
                    <FormLabel>{fieldDef.label} {fieldDef.units && `(${fieldDef.units})`}</FormLabel>
                    <FormControl>
                      <div className="select-wrap">
                        <select {...field} value={fieldValue || ''}>
                          <option value="">Not Specified</option>
                          {options.map(opt => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                          ))}
                        </select>
                        <ChevronDown size={15} />
                      </div>
                    </FormControl>
                  </FormItem>
                );
              }

              if (fieldDef.kind === 'multi-select') {
                const values = Array.isArray(fieldValue) ? fieldValue : [];
                return (
                  <FormItem className="form-field full">
                    <FormLabel>{fieldDef.label}</FormLabel>
                    <FormControl>
                      <MultiSelect
                        options={options}
                        values={values}
                        onChange={field.onChange}
                        placeholder={`Select ${fieldDef.label.toLowerCase()}`}
                      />
                    </FormControl>
                    <FormMessage className="field-error" />
                  </FormItem>
                );
              }

              if (fieldDef.kind === 'yes-no') {
                return (
                  <FormItem className="form-field">
                    <FormLabel>{fieldDef.label}</FormLabel>
                    <FormControl>
                      <div className="select-wrap">
                        <select
                          name={field.name}
                          onBlur={field.onBlur}
                          ref={field.ref}
                           value={fieldValue !== undefined && fieldValue !== '' ? String(fieldValue) : ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            field.onChange(val === '' ? undefined : val);
                          }}
                        >
                          <option value="">Not Specified</option>
                          {options.map(opt => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                          ))}
                        </select>
                        <ChevronDown size={15} />
                      </div>
                    </FormControl>
                  </FormItem>
                );
              }

              if (fieldDef.kind === 'number') {
                return (
                  <FormItem className="form-field">
                    <FormLabel>{fieldDef.label} {fieldDef.units && `(${fieldDef.units})`}</FormLabel>
                    <FormControl>
                      <input 
                        type="number" 
                        {...field} 
                         value={fieldValue ?? ''}
                        onChange={(e) => {
                          const val = e.target.value === '' ? undefined : Number(e.target.value);
                          field.onChange(val);
                        }}
                      />
                    </FormControl>
                  </FormItem>
                );
              }

              return (
                <FormItem className="form-field">
                  <FormLabel>{fieldDef.label} {fieldDef.units && `(${fieldDef.units})`}</FormLabel>
                   <FormControl>
                     <input type={fieldDef.kind === 'date' ? 'date' : 'text'} {...field} value={fieldValue || ''} />
                  </FormControl>
                </FormItem>
              );
            }}
          />
        );
      })}
    </>
  );
}
