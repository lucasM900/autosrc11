import { getCategoryFields, getCategorySchema } from '../lib/equipment-schema';
import { getAttributeWithLegacyAliases, legacyAttributeKeys } from '@workspace/api-zod';

export function ListingAttributesDisplay({ category, attributes }: { category: string, attributes?: Record<string, any> }) {
  if (!attributes || Object.keys(attributes).length === 0) return null;

  const schema = getCategorySchema(category);
  const equipmentType = schema?.types.find(t => t.id === attributes.equipmentType);
  
  // Create a sorted list of known attributes, then unknown attributes
  const fields = getCategoryFields(category);
  const knownKeys = fields.map(f => f.key);
  const legacyKeys = legacyAttributeKeys();
  const internalKeys = new Set([
    'externalListing',
    'sourcePlatform',
    'sourceListingId',
    'sourceUrl',
    'sourcePostedAt',
    'sourceAdType',
    'inquiryMode',
    'sellerManaged',
    'importedAt',
  ]);
  
  const displayItems = [];

  if (equipmentType) {
    displayItems.push({ label: 'Equipment Type', value: equipmentType.label });
  } else if (attributes.equipmentType) {
    displayItems.push({ label: 'Equipment Type', value: String(attributes.equipmentType) });
  }

  // Iterate schema fields first to preserve order
  if (schema) {
    fields.forEach(field => {
      const val = getAttributeWithLegacyAliases(attributes, field.key);
      if (val !== undefined && val !== null && val !== '') {
        let displayVal = String(val);
        
        if (field.kind === 'yes-no') {
          displayVal = String(val) === 'true' ? 'Yes' : 'No';
        } else if (field.kind === 'select' && field.options) {
          const opt = field.options.find(o => o.value === String(val));
          if (opt) displayVal = opt.label;
        } else if (field.kind === 'multi-select' && Array.isArray(val)) {
          displayVal = val.map(v => {
            const opt = field.options?.find(o => o.value === v);
            return opt ? opt.label : v;
          }).join(', ');
        }
        
        if (field.units && field.kind === 'number') {
          displayVal = `${displayVal} ${field.units}`;
        }
        
        displayItems.push({ label: field.label, value: displayVal });
      }
    });
  }

  // Add any legacy/unknown attributes at the end
  Object.keys(attributes).forEach(key => {
    if (key === 'equipmentType') return;
    if (internalKeys.has(key)) return;
    if (knownKeys.includes(key)) return;
    if (legacyKeys.has(key)) return;
    
    const val = attributes[key];
    if (val !== undefined && val !== null && val !== '') {
      let displayVal = String(val);
      if (Array.isArray(val)) displayVal = val.join(', ');
      else if (typeof val === 'boolean') displayVal = val ? 'Yes' : 'No';
      
      displayItems.push({ label: key, value: displayVal });
    }
  });

  if (displayItems.length === 0) return null;

  return (
    <div className="mt-12">
      <h2 className="font-oswald text-xl uppercase mb-4 border-b-2 border-steel-dark pb-2">Equipment Specifications</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {displayItems.map((item, i) => (
          <div key={i} className="flex flex-col p-3 bg-paper border border-steel-line">
            <span className="text-xs font-bold uppercase tracking-wider text-steel-line mb-1">{item.label}</span>
            <span className="font-medium text-steel-dark">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
