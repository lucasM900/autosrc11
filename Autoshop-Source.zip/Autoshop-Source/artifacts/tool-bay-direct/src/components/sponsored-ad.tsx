import { ExternalLink } from 'lucide-react';
import { Link } from 'wouter';
import { useGetActiveBanner, getGetActiveBannerQueryKey } from '@workspace/api-client-react';

interface SponsoredAdProps {
  variant: 'horizontal' | 'vertical';
  placementKey: string;
}

export function SponsoredAd({ variant, placementKey }: SponsoredAdProps) {
  const { data } = useGetActiveBanner(placementKey, {
    query: { queryKey: getGetActiveBannerQueryKey(placementKey), staleTime: 60000, retry: false }
  });

  const ad = data?.ad;

  if (ad) {
    return (
      <a 
        href={`/api/banner-advertising/ads/${ad.id}/click`}
        target="_blank"
        rel="noopener noreferrer"
        className={`sponsored-ad-active ${variant}`}
        data-testid={`sponsored-ad-${placementKey}`}
      >
        <div className="absolute top-0 left-0 bg-white/90 text-xs px-2 py-1 z-10 text-[var(--steel-dark)] font-bold uppercase border-b border-r border-[var(--steel-dark)]">
          Sponsored
        </div>
        {ad.mobileImagePath ? (
          <>
            <img src={`/api/storage${ad.desktopImagePath}`} alt="Advertisement" className="hidden md:block w-full h-full object-cover" />
            <img src={`/api/storage${ad.mobileImagePath}`} alt="Advertisement" className="block md:hidden w-full h-full object-cover" />
          </>
        ) : (
          <img src={`/api/storage${ad.desktopImagePath}`} alt="Advertisement" className="w-full h-full object-cover" />
        )}
      </a>
    );
  }

  // Empty placeholder
  return (
    <Link href={`/advertise?placement=${placementKey}`} className={`sponsored-ad-placeholder ${variant}`} data-testid={`sponsored-ad-placeholder-${placementKey}`}>
      <div className="absolute top-0 left-0 bg-[var(--steel-dark)]/10 text-xs px-2 py-1 text-[var(--steel-dark)] font-bold uppercase">
        Sponsored
      </div>
      <div className="placeholder-content">
        <h4>Click Here to Place Your Ad</h4>
        <p>Advertise your automotive business here</p>
        <span className="placeholder-cta">Advertise here <ExternalLink size={15} /></span>
      </div>
    </Link>
  );
}
