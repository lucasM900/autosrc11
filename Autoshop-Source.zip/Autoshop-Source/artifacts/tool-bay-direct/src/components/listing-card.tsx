import { useState } from 'react';
import { Link } from 'wouter';
import { ArrowLeft, ArrowRight, ArrowUpRight, MapPin, PackageOpen, Sparkles } from 'lucide-react';
import type { Listing } from '@workspace/api-client-react';
import { categoryName, formatPrice } from '../lib/constants';

export function ListingCard({ listing, index }: { listing: Listing; index: number }) {
  const images = listing.imagePaths?.length
    ? listing.imagePaths.map(path => `/api/storage${path}`)
    : listing.image ? [listing.image] : [];
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const primaryImage = images[activeImageIndex] || null;
  const availability = listing.status === 'sold'
    ? 'sold'
    : String(listing.attributes?.availability || 'available');
  const availabilityLabel = availability === 'pending' ? 'Pending' : availability === 'sold' ? 'Sold' : null;
  const isActivePremium = Boolean(
    listing.isPremium &&
    listing.premiumExpiresAt &&
    new Date(listing.premiumExpiresAt).getTime() > Date.now(),
  );
  const detailHref = `/listings/${listing.id}?availability=${encodeURIComponent(availability)}`;

  return (
    <article className={`listing-row${isActivePremium ? ' listing-row-premium' : ''}`} style={{ animationDelay: `${Math.min(index, 8) * 45}ms` }} data-testid={`card-listing-${listing.id}`} data-premium={isActivePremium ? 'true' : 'false'}>
      {isActivePremium && <div className="premium-priority-label"><Sparkles size={12} /> Priority placement</div>}
      <div className="listing-photo">
        {primaryImage ? (
          <>
            <img src={primaryImage} alt={`${listing.title} image ${activeImageIndex + 1} of ${images.length}`} data-testid={`img-listing-${listing.id}`} />
            {images.length > 1 && (
              <div className="listing-photo-controls" aria-label="Listing image controls">
                <button
                  type="button"
                  className="listing-photo-arrow"
                  onClick={() => setActiveImageIndex(current => (current - 1 + images.length) % images.length)}
                  aria-label="Show previous listing image"
                >
                  <ArrowLeft size={16} />
                </button>
                <span className="listing-photo-count" aria-live="polite">{activeImageIndex + 1}/{images.length}</span>
                <button
                  type="button"
                  className="listing-photo-arrow"
                  onClick={() => setActiveImageIndex(current => (current + 1) % images.length)}
                  aria-label="Show next listing image"
                >
                  <ArrowRight size={16} />
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="no-photo"><PackageOpen size={28} strokeWidth={1.4} /><br />Photo not supplied</div>
        )}
      </div>
      <div className="listing-body">
        <div className="listing-title-block">
          <div className="listing-badges">
            <span className={`condition-badge condition-${listing.condition}`}>{listing.condition}</span>
            {isActivePremium && <span className="premium-badge"><Sparkles size={11} /> Premium</span>}
            {availabilityLabel && <span className={`condition-badge condition-${availability}`}>{availabilityLabel}</span>}
          </div>
          <Link href={detailHref} target="_blank" className="listing-title-link" data-testid={`link-listing-${listing.id}`}><h3 className="listing-title" data-testid={`text-title-${listing.id}`}>{listing.title}</h3></Link>
          <p className="listing-spec" data-testid={`text-spec-${listing.id}`}>{listing.spec}</p>
        </div>
        <div className="listing-fact">
          <span className="fact-label">Category</span>
          <span className="fact-value" data-testid={`text-category-${listing.id}`}>{categoryName(listing.category)}</span>
        </div>
        <div className="listing-fact">
          <span className="fact-label"><MapPin size={12} /> Location</span>
          <span className="fact-value" data-testid={`text-location-${listing.id}`}>{listing.location}</span>
        </div>
        <div className="listing-fact">
          <span className="fact-label">Asking</span>
          <span className="price" data-testid={`text-price-${listing.id}`}>{formatPrice(listing.price, listing.currencyCode)}</span>
        </div>
        <div className="listing-contact">
          <Link href={detailHref} target="_blank" className="contact-button" data-testid={`link-contact-${listing.id}`}>
            View details <ArrowUpRight size={14} />
          </Link>
        </div>
      </div>
    </article>
  );
}
