import { useState } from 'react';

type Props = {
  name: string;
  avatarPath?: string | null;
  size?: 'small' | 'medium' | 'large';
  testId?: string;
};

export function MemberAvatar({ name, avatarPath, size = 'small', testId }: Props) {
  const [failedPath, setFailedPath] = useState<string | null>(null);
  const initials = name.trim().split(/\s+/).slice(0, 2).map(part => part.charAt(0)).join('').toUpperCase() || 'M';
  return <span className={`member-avatar${size === 'small' ? '' : ` member-avatar--${size}`}`} data-testid={testId}>
    {avatarPath && failedPath !== avatarPath
      ? <img src={`/api/storage${avatarPath}`} alt={`${name}'s profile picture`} onError={() => setFailedPath(avatarPath)} />
      : <span aria-label={`${name}'s initials`}>{initials}</span>}
  </span>;
}