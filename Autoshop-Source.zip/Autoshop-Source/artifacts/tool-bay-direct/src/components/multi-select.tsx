import { useState, useRef, useEffect, KeyboardEvent } from 'react';
import { ChevronDown, X } from 'lucide-react';

interface MultiSelectProps {
  options: { label: string; value: string }[];
  values: string[];
  onChange: (values: string[]) => void;
  placeholder: string;
}

export function MultiSelect({ options, values, onChange, placeholder }: MultiSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    
    if (isOpen) {
      // Use the completed click rather than mousedown. A category selection
      // can re-render the next multiselect (Equipment Type) between those
      // events; closing on mousedown would remove the clicked control before
      // its click handler runs.
      document.addEventListener('click', handleClickOutside);
    }
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [isOpen]);

  const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Escape') {
      setIsOpen(false);
    }
  };

  // Handle summary
  let summary = placeholder;
  if (values.length === 1) {
    summary = options.find(o => o.value === values[0])?.label || values[0];
  } else if (values.length > 1) {
    summary = `${values.length} selected`;
  }

  return (
    <div className="multi-select relative" ref={containerRef} onKeyDown={handleKeyDown}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="filter-control flex items-center justify-between"
        aria-haspopup="listbox"
        aria-expanded={isOpen}
      >
        <span className={`min-w-0 flex-1 mr-2 text-left leading-snug break-words ${values.length > 0 ? 'font-medium text-steel-dark' : 'text-steel-dark/70'}`}>{summary}</span>
        <ChevronDown size={16} strokeWidth={2.5} className={`shrink-0 transition-transform text-steel-line ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="filter-panel-body multi-select-menu flex flex-col" role="listbox">
          {values.length > 0 && (
            <button
              type="button"
              onClick={(e) => { e.preventDefault(); onChange([]); setIsOpen(false); }}
              className="filter-clear-btn"
            >
              <X size={14} strokeWidth={2.5} /> Clear Selection
            </button>
          )}
          <div className="py-1 flex flex-col max-h-60 overflow-y-auto">
            {options.map(opt => {
              const isSelected = values.includes(opt.value);
              return (
                <label key={opt.value} className="filter-option group">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={(e) => {
                      if (e.target.checked) {
                        onChange([...values, opt.value]);
                      } else {
                        onChange(values.filter(v => v !== opt.value));
                      }
                    }}
                    className="filter-checkbox"
                  />
                  <span className={`min-w-0 flex-1 leading-snug break-words text-left ${isSelected ? 'font-medium text-steel-dark' : 'text-steel-dark/80 group-hover:text-teal'}`}>{opt.label}</span>
                </label>
              );
            })}
            {options.length === 0 && (
              <div className="p-3 text-sm text-steel-line text-center">No options available</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
