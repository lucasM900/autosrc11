import { Dispatch, SetStateAction } from 'react';
import { CATEGORIES, normalizePriceRange } from '../lib/constants';
import {
  COMMON_EQUIPMENT_FIELDS,
  getCategorySchema,
  getCategorySpecificFields,
  getFieldOptions,
  type FieldDefinition,
} from '../lib/equipment-schema';
import { MapPin } from 'lucide-react';
import { MultiSelect } from './multi-select';
import { SingleSelect } from './single-select';
import { Slider } from './ui/slider';
import { LocationAutocomplete } from './location-autocomplete';
import { SuggestionInput } from './suggestion-input';
import { getManufacturerSuggestions, getModelSuggestions } from '../lib/equipment-catalog';
import { normalizeRegisteredBrand, OTHER_BRAND_VALUE } from '@workspace/api-zod';

interface SidebarFiltersProps {
  activeCategories: string[];
  setActiveCategories: Dispatch<SetStateAction<string[]>>;
  condition: string[];
  setCondition: Dispatch<SetStateAction<string[]>>;
  minPrice: string;
  setMinPrice: Dispatch<SetStateAction<string>>;
  maxPrice: string;
  setMaxPrice: Dispatch<SetStateAction<string>>;
  userLocation: { lat: number; lng: number } | null;
  setUserLocation: Dispatch<SetStateAction<{ lat: number; lng: number } | null>>;
  locationLabel: string;
  setLocationLabel: Dispatch<SetStateAction<string>>;
  radius: string;
  setRadius: Dispatch<SetStateAction<string>>;
  equipmentTypes: string[];
  setEquipmentTypes: Dispatch<SetStateAction<string[]>>;
  attributeFilters: Record<string, any>;
  setAttributeFilters: Dispatch<SetStateAction<Record<string, any>>>;
}

const PRICE_SLIDER_MIN = 1;
const PRICE_SLIDER_MAX = 10_000;
const OTHER_BRAND = OTHER_BRAND_VALUE;

function selectedValues(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(String);
  return value === undefined || value === null || value === '' ? [] : [String(value)];
}

export function SidebarFilters({
  activeCategories, setActiveCategories,
  condition, setCondition,
  minPrice, setMinPrice,
  maxPrice, setMaxPrice,
  userLocation, setUserLocation,
  locationLabel, setLocationLabel,
  radius, setRadius,
  equipmentTypes, setEquipmentTypes,
  attributeFilters, setAttributeFilters,
}: SidebarFiltersProps) {
  const hasMultipleCategories = activeCategories.length > 1;
  const singleCategory = activeCategories.length === 1 ? activeCategories[0] : undefined;
  const schema = singleCategory ? getCategorySchema(singleCategory) : undefined;
  const schemaFields = getCategorySpecificFields(singleCategory);
  const selectedEquipmentType = equipmentTypes.length === 1 ? equipmentTypes[0] : '';
  const manufacturerValue = String(attributeFilters.manufacturer || '');

  const handleCategoriesChange = (values: string[]) => {
    setActiveCategories(values);
    setEquipmentTypes([]);
    setAttributeFilters({});
  };

  const handleEquipmentTypesChange = (values: string[]) => {
    setEquipmentTypes(values);
    setAttributeFilters({});
  };

  const setFilterValue = (key: string, value: unknown) => {
    setAttributeFilters(previous => {
      const next = { ...previous };
      if (value === undefined || value === '' || (Array.isArray(value) && value.length === 0)) {
        delete next[key];
      } else {
        next[key] = value;
      }
      return next;
    });
  };

  const setMinMaxFilter = (key: string, bound: 'min' | 'max', value: string) => {
    setAttributeFilters(previous => {
      const next = { ...previous };
      const current = next[key] && typeof next[key] === 'object' ? next[key] : {};
      const numberValue = value === '' ? undefined : Number(value);
      const newBound = { ...current, [bound]: numberValue };
      if (newBound.min === undefined && newBound.max === undefined) delete next[key];
      else next[key] = newBound;
      return next;
    });
  };

  const renderField = (field: FieldDefinition) => {
    if (field.kind === 'select' || field.kind === 'multi-select' || field.kind === 'yes-no') {
      const values = selectedValues(attributeFilters[field.key]);
      return (
        <div key={field.key}>
          <label className="filter-label">
            {field.label} {field.units && <span className="text-steel-line font-normal ml-1">({field.units})</span>}
          </label>
          <MultiSelect
            options={getFieldOptions(field)}
            values={values}
            onChange={nextValues => setFilterValue(field.key, nextValues.length === 2 && field.kind === 'yes-no' ? [] : nextValues)}
            placeholder={`Select ${field.label.toLowerCase()}`}
          />
        </div>
      );
    }

    if (field.kind === 'number') {
      const value = attributeFilters[field.key] && typeof attributeFilters[field.key] === 'object' ? attributeFilters[field.key] : {};
      return (
        <div key={field.key}>
          <label className="filter-label">
            {field.label} {field.units && <span className="text-steel-line font-normal ml-1">({field.units})</span>}
          </label>
          <div className="flex items-center gap-2">
            <input type="number" placeholder="Min" value={value.min ?? ''} onChange={event => setMinMaxFilter(field.key, 'min', event.target.value)} className="filter-control" />
            <span className="text-steel-line font-medium">-</span>
            <input type="number" placeholder="Max" value={value.max ?? ''} onChange={event => setMinMaxFilter(field.key, 'max', event.target.value)} className="filter-control" />
          </div>
        </div>
      );
    }

    if (field.key === 'manufacturer') {
      const suggestions = getManufacturerSuggestions(singleCategory || '', selectedEquipmentType);
      if (!singleCategory && suggestions.length === 0) {
        return (
          <div key={field.key}>
            <label className="filter-label">{field.label}</label>
            <input type="text" value={manufacturerValue} onChange={event => setFilterValue(field.key, event.target.value)} placeholder="Search brands..." className="filter-control" />
          </div>
        );
      }
      const currentValues = selectedValues(attributeFilters[field.key]);
       const knownCurrent = currentValues.filter(value => value !== OTHER_BRAND && !suggestions.some(suggestion => normalizeRegisteredBrand(suggestion) === normalizeRegisteredBrand(value)));
      const brandOptions = [
        ...suggestions.map(value => ({ label: value, value })),
        ...knownCurrent.map(value => ({ label: `${value} (custom)`, value })),
        { label: 'Other (not listed)', value: OTHER_BRAND },
      ];
      return (
        <div key={field.key}>
          <label className="filter-label">{field.label}</label>
          <MultiSelect
            options={brandOptions}
            values={currentValues}
            onChange={values => setFilterValue(field.key, values)}
            placeholder="Select brands"
          />
        </div>
      );
    }

    if (field.key === 'model') {
      return (
        <div key={field.key}>
          <label className="filter-label">{field.label}</label>
          <SuggestionInput
            value={String(attributeFilters[field.key] || '')}
            onChange={value => setFilterValue(field.key, value)}
            suggestions={getModelSuggestions(singleCategory || '', selectedEquipmentType, manufacturerValue)}
            placeholder="Search models..."
            ariaLabel="Filter by equipment model"
          />
        </div>
      );
    }

    return (
      <div key={field.key}>
        <label className="filter-label">
          {field.label} {field.units && <span className="text-steel-line font-normal ml-1">({field.units})</span>}
        </label>
        <input
          type={field.kind === 'date' ? 'date' : 'text'}
          value={attributeFilters[field.key] || ''}
          onChange={event => setFilterValue(field.key, event.target.value)}
          className="filter-control"
        />
      </div>
    );
  };

  const categoryOptions = CATEGORIES.filter(category => category.id !== 'all').map(category => ({ label: category.label, value: category.id }));
  const conditionOptions = [
    { label: 'New', value: 'new' },
    { label: 'Excellent', value: 'excellent' },
    { label: 'Good', value: 'good' },
    { label: 'Fair', value: 'fair' },
    { label: 'Parts', value: 'parts' },
    // Legacy values remain filterable.
    { label: 'Used', value: 'used' },
    { label: 'Refurbished', value: 'refurbished' },
  ];
  const normalizedPrice = normalizePriceRange(minPrice, maxPrice);
  const lowerPrice = Math.max(PRICE_SLIDER_MIN, Math.min(PRICE_SLIDER_MAX, normalizedPrice.min ?? PRICE_SLIDER_MIN));
  const upperPrice = Math.max(lowerPrice, Math.min(PRICE_SLIDER_MAX, normalizedPrice.max ?? PRICE_SLIDER_MAX));

  // Common fields are the buyer master list. Category-specific fields stay
  // below the type selector so a category never renders irrelevant inputs.
  const universalFields = COMMON_EQUIPMENT_FIELDS;
  const generalFilters = (
    <div className="filter-section-card">
      <h3 className="filter-section-title">General</h3>
      <div className="flex flex-col gap-5">
        <div>
          <label className="filter-label">Condition</label>
          <MultiSelect options={conditionOptions} values={condition} onChange={setCondition} placeholder="Select condition" />
        </div>

        <div>
          <label className="filter-label">Price Range (CAD)</label>
          <div className="px-2 pt-3">
            <Slider
              min={PRICE_SLIDER_MIN}
              max={PRICE_SLIDER_MAX}
              step={1}
              value={[lowerPrice, upperPrice]}
              onValueChange={values => {
                const [nextMin, nextMax] = values;
                if (nextMin !== lowerPrice) {
                  setMinPrice(nextMin > PRICE_SLIDER_MIN ? String(nextMin) : '');
                }
                // A typed upper value over the visual cap is intentionally
                // preserved while the lower handle is moved. Dragging the
                // upper handle down from the cap replaces it explicitly.
                if (nextMax !== upperPrice || normalizedPrice.max === undefined || normalizedPrice.max <= PRICE_SLIDER_MAX) {
                  setMaxPrice(nextMax < PRICE_SLIDER_MAX ? String(nextMax) : '');
                }
              }}
              aria-label="Price range"
            />
          </div>
          <div className="flex items-center gap-2 mt-3">
            <input type="number" min={PRICE_SLIDER_MIN} placeholder="Min" value={minPrice} onChange={event => setMinPrice(event.target.value)} className="filter-control" aria-label="Minimum price" />
            <span className="text-steel-line font-medium">-</span>
            <input type="number" min={PRICE_SLIDER_MIN} placeholder="Max (10,000+)" value={maxPrice} onChange={event => setMaxPrice(event.target.value)} className="filter-control" aria-label="Maximum price, values over 10,000 are supported" />
          </div>
          <div className="flex justify-between mt-2 text-xs text-steel-line font-mono">
            <span>$1</span><span>$10,000+</span>
          </div>
        </div>

        <div>
          <label className="filter-label">Location</label>
          <LocationAutocomplete
            value={locationLabel}
            onChange={(value, suggestion) => {
              setLocationLabel(value);
              setUserLocation(suggestion ? { lat: suggestion.latitude, lng: suggestion.longitude } : null);
            }}
            onClear={() => setUserLocation(null)}
            onCurrentLocation={({ latitude, longitude }) => setUserLocation({ lat: latitude, lng: longitude })}
            placeholder="City or postal code"
          />
          {userLocation ? (
            <div className="flex flex-col gap-3 mt-3 p-4 bg-surface-blue border border-[#c5d2d0] rounded-md">
              <div className="flex items-center gap-2"><MapPin size={16} className="text-teal" /><span className="text-sm font-semibold text-steel-dark">Search radius</span></div>
              <SingleSelect value={radius} onChange={setRadius} options={[{ label: '10 km', value: '10' }, { label: '25 km', value: '25' }, { label: '50 km', value: '50' }, { label: '100 km', value: '100' }, { label: '250 km', value: '250' }, { label: '500+ km', value: '500' }]} placeholder="Select radius" />
              <button onClick={() => { setUserLocation(null); setLocationLabel(''); }} className="text-sm font-medium text-oxide hover:text-[#8e3626] text-left transition-colors w-fit mt-1">Clear Location</button>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );

  return (
    <div className="filter-sidebar flex flex-col gap-8 h-full">
      <div className="filter-category-section">
        <h3 className="filter-section-title">Categories</h3>
        <MultiSelect options={categoryOptions} values={activeCategories} onChange={handleCategoriesChange} placeholder="All Categories" />
      </div>

      {hasMultipleCategories && <div className="filter-helper">Select a single category to filter by equipment type and specifications.</div>}

      {schema && schema.types.length > 0 && (
        <div className="filter-section-card">
          <h3 className="filter-section-title">Equipment Type</h3>
          <MultiSelect options={schema.types.map(type => ({ label: type.label, value: type.id }))} values={equipmentTypes} onChange={handleEquipmentTypesChange} placeholder="Select type (choose multiple)" />
        </div>
      )}

      {generalFilters}

      <div className="filter-section-card">
        <h3 className="filter-section-title">Universal Filters</h3>
        <div className="flex flex-col gap-5">
          {universalFields.map(renderField)}
        </div>
      </div>

      {schema && equipmentTypes.length > 0 && schemaFields.length > 0 && (
        <div className="filter-section-card">
          <h3 className="filter-section-title">Specifications</h3>
          <div className="flex flex-col gap-5">{schemaFields.map(renderField)}</div>
        </div>
      )}

    </div>
  );
}