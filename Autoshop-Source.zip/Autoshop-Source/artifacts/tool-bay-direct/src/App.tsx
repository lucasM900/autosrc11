import { useEffect, useRef, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, Show, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from './components/error-boundary';
import { Toaster } from './components/ui/toaster';
import { TooltipProvider } from './components/ui/tooltip';

import { Header } from './components/header';
import { WebsiteAnalyticsTracker } from './components/website-analytics-tracker';
import NotFound from './pages/not-found';
import Home from './pages/home';
import ListingDetail from './pages/listing-detail';
import SellerDashboard from './pages/seller-dashboard';
import CreateListing from './pages/create-listing';
import EditListing from './pages/edit-listing';
import SignInPage from './pages/sign-in';
import SignUpPage from './pages/sign-up';
import Advertise from './pages/advertise';
import AdvertiseDashboard from './pages/advertise-dashboard';
import AdvertiseCheckout from './pages/advertise-checkout';
import AdminAdvertising from './pages/admin-advertising';
import PremiumListingCheckout from './pages/premium-listing-checkout';
import Profile from './pages/profile';
import PublicProfile from './pages/public-profile';
import Messages from './pages/messages';
import MessageThread from './pages/message-thread';

const queryClient = new QueryClient();

// REQUIRED — copy verbatim. Resolves the key from window.location.hostname so the
// same build serves multiple Clerk custom domains. Do not inline the env var, leave
// publishableKey undefined, or replace publishableKeyFromHost with anything else.
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

// REQUIRED — copy verbatim. Empty in dev (Clerk hits dev FAPI directly), auto-set
// in prod. Do NOT gate on import.meta.env.PROD / NODE_ENV — the empty dev value
// is intentional, and any branching breaks the prod proxy.
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

// Clerk passes full paths to routerPush/routerReplace, but wouter's
// setLocation prepends the base — strip it to avoid doubling.
function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "#182735", // steel-dark
    colorForeground: "#182735", // steel-dark
    colorMutedForeground: "#78909a", // steel-line
    colorDanger: "#b24c3f", // oxide
    colorBackground: "#ffffff",
    colorInput: "#ffffff",
    colorInputForeground: "#182735",
    colorNeutral: "#d3dfdf",
    fontFamily: "var(--app-font-sans)",
    borderRadius: "0.4rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-white border border-[#d3dfdf] shadow-[0_16px_34px_rgba(24,39,53,0.14)] rounded-[0.65rem] w-[460px] max-w-full overflow-hidden",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "font-['Barlow_Condensed',_sans-serif] text-3xl text-[#182735] uppercase font-bold tracking-tight",
    headerSubtitle: "text-[#78909a] text-[0.95rem] mt-1",
    socialButtonsBlockButtonText: "!text-[#182735] font-['Barlow_Condensed',_sans-serif] uppercase tracking-wide font-bold text-[1.1rem]",
    formFieldLabel: "font-bold text-[0.85rem] text-[#182735]",
    footerActionLink: "text-[#2e7180] hover:text-[#182735] font-bold transition-colors",
    footerActionText: "text-[#78909a]",
    dividerText: "text-[#78909a] uppercase text-[0.7rem] font-['Space_Mono',_monospace] tracking-wider",
    identityPreviewEditButton: "text-[#2e7180] hover:text-[#182735]",
    formFieldSuccessText: "text-[#39766e]",
    alertText: "text-[#b24c3f]",
    logoBox: "mb-8 flex justify-center",
    logoImage: "h-11 object-contain",
    socialButtonsBlockButton: "border border-[#d3dfdf] rounded-[0.4rem] hover:bg-[#fbfaf6] hover:border-[#78909a] transition-all py-3",
    formButtonPrimary: "bg-[#f4bd22] border-none rounded-[0.4rem] text-[#182735] font-['Barlow_Condensed',_sans-serif] uppercase font-bold text-[1.2rem] tracking-wide shadow-[0_3px_0_rgba(0,0,0,0.2)] hover:bg-[#ffd45c] hover:-translate-y-[1px] transition-all active:translate-y-0 active:shadow-none py-3",
    formFieldInput: "border border-[#d3dfdf] rounded-[0.4rem] bg-white text-[#182735] px-3 py-3 focus:outline-none focus:border-[#2e7180] focus:ring-1 focus:ring-[#2e7180] transition-shadow text-[1rem]",
    footerAction: "mt-6 pt-5 border-t border-[#d3dfdf]",
    dividerLine: "bg-[#d3dfdf]",
    alert: "border border-[#b24c3f] bg-[#fff5f4] rounded-[0.4rem] p-3",
    otpCodeFieldInput: "border border-[#d3dfdf] rounded-[0.4rem] focus:border-[#2e7180] focus:ring-1 focus:ring-[#2e7180]",
    formFieldRow: "mb-5",
    main: "p-8 md:p-10",
  },
};

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (
        prevUserIdRef.current !== undefined &&
        prevUserIdRef.current !== userId
      ) {
        queryClient.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);

  return null;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  return (
    <div className="app-shell">
      <Header />
      <RoutedErrorBoundary>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/sign-in/*?" component={SignInPage} />
          <Route path="/sign-up/*?" component={SignUpPage} />
          <Route path="/seller" component={SellerDashboard} />
          <Route path="/seller/listings/new" component={CreateListing} />
          <Route path="/seller/listings/:id/edit" component={EditListing} />
          <Route path="/seller/premium-checkout" component={PremiumListingCheckout} />
          <Route path="/profile" component={Profile} />
          <Route path="/profiles/:userId" component={PublicProfile} />
          <Route path="/messages" component={Messages} />
          <Route path="/messages/:id" component={MessageThread} />
          <Route path="/listings/:id" component={ListingDetail} />
          <Route path="/advertise" component={Advertise} />
          <Route path="/advertise/dashboard" component={AdvertiseDashboard} />
          <Route path="/advertise/checkout" component={AdvertiseCheckout} />
          <Route path="/admin/advertising" component={AdminAdvertising} />
          <Route component={NotFound} />
        </Switch>
      </RoutedErrorBoundary>
      <footer className="site-footer">
        <strong>AUTOSHOP SOURCE</strong>
        <small>International equipment listings. Direct contact. No middleman markup.</small>
      </footer>
    </div>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "Welcome back",
            subtitle: "Sign in to access your dashboard",
          },
        },
        signUp: {
          start: {
            title: "Join Autoshop Source",
            subtitle: "Create an account to list equipment",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <WebsiteAnalyticsTracker />
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
