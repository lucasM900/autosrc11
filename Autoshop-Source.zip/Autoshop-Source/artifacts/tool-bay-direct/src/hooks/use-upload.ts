import { useState, useCallback } from 'react';
import { useRequestUploadUrl } from '@workspace/api-client-react';

export function useUpload(options?: { onSuccess?: (objectPath: string) => void, onError?: (error: Error) => void }) {
  const [isUploading, setIsUploading] = useState(false);
  const requestUploadUrl = useRequestUploadUrl();

  const uploadFile = useCallback(async (file: File) => {
    setIsUploading(true);
    try {
      // 1. Get presigned URL
      const { uploadURL, objectPath } = await requestUploadUrl.mutateAsync({
        data: {
          name: file.name,
          size: file.size,
          contentType: file.type,
        }
      });

      // 2. Upload file
      const response = await fetch(uploadURL, {
        method: 'PUT',
        body: file,
        headers: {
          'Content-Type': file.type,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to upload file to storage');
      }

      options?.onSuccess?.(objectPath);
      return objectPath;
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Upload failed');
      options?.onError?.(err);
      throw err;
    } finally {
      setIsUploading(false);
    }
  }, [requestUploadUrl, options]);

  return { uploadFile, isUploading };
}
