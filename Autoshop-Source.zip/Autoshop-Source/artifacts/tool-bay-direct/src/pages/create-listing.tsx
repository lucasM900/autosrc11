import { useState } from 'react';
import { useLocation, Link } from 'wouter';
import { useCreateSellerListing, useCreateListingPremiumCheckout, getListSellerListingsQueryKey, getGetListingsSummaryQueryKey, getListListingsQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '../components/ui/form';
import { ImageUpload } from '../components/image-upload';
import { EquipmentSchemaFields } from '../components/equipment-schema-fields';
import { LocationAutocomplete } from '../components/location-autocomplete';
import { CATEGORIES } from '../lib/constants';
import { ChevronDown, LoaderCircle, ArrowLeft, Sparkles } from 'lucide-react';

const listingSchema = z.object({
  title: z.string().trim().min(1, 'Add a clear title.'),
  category: z.string().min(1, 'Choose a category.'),
  condition: z.string().min(1, 'Choose a condition.'),
  price: z.preprocess(
    (value) => value === '' ? undefined : Number(value),
    z.number({ invalid_type_error: 'Enter a price.' }).min(0, 'Price cannot be negative.'),
  ),
  location: z.string().trim().min(1, 'Add a location.'),
  countryCode: z.string().optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  currencyCode: z.string().optional(),
  spec: z.string().trim().min(1, 'Add the key specifications.'),
  description: z.string().optional(),
  contact: z.string().trim().min(1, 'Add an email or phone number.'),
  imagePaths: z.array(z.string()).max(7, 'Max 7 images allowed').optional(),
  attributes: z.record(z.any()).optional().default({}),
});

type ListingFormValues = z.infer<typeof listingSchema>;

function listingPublishErrorMessage(error: unknown): string {
  if (!(error instanceof Error)) {
    return 'Could not post this listing. Try again.';
  }

  if (
    /^HTTP 5\d\d\b/i.test(error.message) ||
    /<!doctype html|internal server error/i.test(error.message)
  ) {
    return 'The marketplace server is temporarily unavailable. Your listing was not published. Please try again shortly.';
  }

  return error.message;
}

export default function CreateListing() {
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const createListing = useCreateSellerListing();
  const premiumCheckout = useCreateListingPremiumCheckout();
  const [submitError, setSubmitError] = useState('');
  const [makePremium, setMakePremium] = useState(false);
  const [publishedListingId, setPublishedListingId] = useState<string | null>(null);

  const form = useForm<ListingFormValues>({
    resolver: zodResolver(listingSchema),
    defaultValues: {
      title: '', category: 'vehicle-lifts', condition: 'used', price: 0, location: '', countryCode: '', latitude: undefined, longitude: undefined, currencyCode: 'CAD', spec: '', description: '', contact: '', imagePaths: [], attributes: {},
    },
  });

  const onSubmit = async (values: ListingFormValues) => {
    setSubmitError('');
    try {
      const listing = await createListing.mutateAsync({ data: values });
      setPublishedListingId(listing.id);
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getListSellerListingsQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getListListingsQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetListingsSummaryQueryKey() }),
      ]);
      if (makePremium) {
        try {
          const checkout = await premiumCheckout.mutateAsync({ id: listing.id });
          window.location.assign(checkout.checkoutUrl);
        } catch {
          setSubmitError('Your listing was published, but premium checkout could not start. You can retry from your dashboard.');
        }
      } else {
        setLocation('/seller');
      }
    } catch (error) {
      setSubmitError(listingPublishErrorMessage(error));
    }
  };

  return (
    <main className="content-shell" style={{ paddingTop: '40px' }}>
      <div className="max-w-[800px] mx-auto">
        <div className="mb-6">
          <Link href="/seller" className="inline-flex items-center gap-2 text-steel-line hover:text-steel-dark text-sm font-mono uppercase tracking-wider transition-colors">
            <ArrowLeft size={14} /> Back to dashboard
          </Link>
        </div>

        <div className="seller-card">
          <h1 className="font-oswald text-2xl uppercase mb-8 border-b-2 border-steel-dark pb-4">Create New Listing</h1>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} noValidate>
              <div className="form-grid">
                <FormField control={form.control} name="title" render={({ field }) => (
                  <FormItem className="form-field full"><FormLabel>Title</FormLabel><FormControl><input {...field} placeholder="e.g. Lincoln 180 MIG Welder" /></FormControl><FormMessage className="field-error" /></FormItem>
                )} />
                <FormField control={form.control} name="category" render={({ field }) => (
                  <FormItem className="form-field"><FormLabel>Category</FormLabel><FormControl><div className="select-wrap"><select {...field} onChange={(e) => { field.onChange(e); form.setValue('attributes', {}, { shouldValidate: true }); }}>{CATEGORIES.slice(1).map((category) => <option value={category.id} key={category.id}>{category.label}</option>)}</select><ChevronDown size={15} /></div></FormControl><FormMessage className="field-error" /></FormItem>
                )} />
                {form.watch('category') && <EquipmentSchemaFields category={form.watch('category')} />}
                <FormField control={form.control} name="condition" render={({ field }) => (
                  <FormItem className="form-field"><FormLabel>Condition</FormLabel><FormControl><div className="select-wrap"><select {...field}><option value="new">New</option><option value="excellent">Excellent</option><option value="good">Good</option><option value="fair">Fair</option><option value="parts">Parts</option><option value="used">Used</option><option value="refurbished">Refurbished</option></select><ChevronDown size={15} /></div></FormControl><FormMessage className="field-error" /></FormItem>
                )} />
                <FormField control={form.control} name="price" render={({ field }) => (
                  <FormItem className="form-field"><FormLabel>Price ({form.watch('currencyCode') || 'CAD'})</FormLabel><FormControl><input {...field} type="number" min="0" step="1" placeholder="650" /></FormControl><FormMessage className="field-error" /></FormItem>
                )} />
                <FormField control={form.control} name="location" render={({ field }) => (
                  <FormItem className="form-field">
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <LocationAutocomplete
                        value={field.value}
                        onChange={(val, suggestion) => {
                          field.onChange(val);
                          if (suggestion) {
                            form.setValue('countryCode', suggestion.countryCode, { shouldValidate: true });
                            form.setValue('latitude', suggestion.latitude, { shouldValidate: true });
                            form.setValue('longitude', suggestion.longitude, { shouldValidate: true });
                            form.setValue('currencyCode', suggestion.currencyCode, { shouldValidate: true });
                          }
                        }}
                        onClear={() => {
                          form.setValue('countryCode', undefined);
                          form.setValue('latitude', undefined);
                          form.setValue('longitude', undefined);
                          form.setValue('currencyCode', 'CAD');
                        }}
                        placeholder="e.g. Pickering, ON"
                      />
                    </FormControl>
                    <FormMessage className="field-error" />
                  </FormItem>
                )} />
                <FormField control={form.control} name="spec" render={({ field }) => (
                  <FormItem className="form-field full"><FormLabel>Key specifications</FormLabel><FormControl><input {...field} placeholder="e.g. 220V · handles up to 3/8in steel" /></FormControl><FormMessage className="field-error" /></FormItem>
                )} />
                <FormField control={form.control} name="description" render={({ field }) => (
                  <FormItem className="form-field full"><FormLabel>Full Description <span className="label-optional">optional</span></FormLabel><FormControl><textarea {...field} placeholder="Detailed description of the equipment condition, history, included accessories..." /></FormControl><FormMessage className="field-error" /></FormItem>
                )} />
                <FormField control={form.control} name="contact" render={({ field }) => (
                  <FormItem className="form-field full"><FormLabel>Contact Email or Phone</FormLabel><FormControl><input {...field} placeholder="you@example.com or (416) 555-0142" /></FormControl><FormMessage className="field-error" /></FormItem>
                )} />
                
                <FormField control={form.control} name="imagePaths" render={({ field }) => (
                  <FormItem className="form-field full">
                    <FormLabel>Equipment Photos <span className="label-optional">max 7</span></FormLabel>
                    <FormControl>
                      <ImageUpload value={field.value || []} onChange={field.onChange} maxFiles={7} />
                    </FormControl>
                    <FormMessage className="field-error" />
                  </FormItem>
                )} />

                <div className={`form-field full premium-option ${makePremium ? 'is-selected' : ''}`}>
                  <label className="flex items-start gap-4 cursor-pointer">
                    <input type="checkbox" checked={makePremium} onChange={event => setMakePremium(event.target.checked)} className="mt-1" />
                    <span className="flex-1">
                      <strong className="flex items-center gap-2 font-oswald text-xl uppercase"><Sparkles size={18} /> Premium listing</strong>
                      <span className="block text-sm text-steel-line mt-1">Reserve priority placement in the first three marketplace positions for the listing’s 90-day term.</span>
                    </span>
                    <strong className="premium-price font-oswald text-xl whitespace-nowrap">$9.99 CAD</strong>
                  </label>
                </div>
              </div>
              
              {submitError ? <p className="field-error mb-4" role="alert">{submitError} {publishedListingId ? <Link href="/seller" className="underline font-bold">Go to dashboard</Link> : null}</p> : null}
              
              <div className="flex justify-end gap-4 mt-8 pt-4 border-t-2 border-steel-line">
                <Link href="/seller" className="button-secondary">Cancel</Link>
                <button type="submit" className="button-primary" disabled={Boolean(publishedListingId) || createListing.isPending || premiumCheckout.isPending}>
                  {createListing.isPending || premiumCheckout.isPending ? <><LoaderCircle size={15} className="spin-icon" /> Saving...</> : makePremium ? 'Publish & Continue to Payment' : 'Publish Listing'}
                </button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </main>
  );
}
