import { useState } from 'react';
import { useAuth, useUser } from '@clerk/react';
import { useQueryClient } from '@tanstack/react-query';
import { Link, useRoute } from 'wouter';
import { ArrowLeft, Send } from 'lucide-react';
import { getGetConversationQueryKey, getListConversationsQueryKey, useGetConversation, useSendConversationMessage } from '@workspace/api-client-react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '../components/ui/form';
import { AccountEmpty, AccountError, AccountHeading, AccountLoading, AccountSignIn } from '../components/account-state';

const schema = z.object({ body: z.string().trim().min(1, 'Write a reply before sending').max(4000, 'Keep your reply under 4,000 characters') });
type Values = z.infer<typeof schema>;
const displayDate = (date: string) => { const parsed = new Date(date); return Number.isNaN(parsed.getTime()) ? '' : parsed.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }); };

export default function MessageThread() {
  const [, params] = useRoute('/messages/:id');
  const id = params?.id || '';
  const { isLoaded, isSignedIn } = useAuth();
  const { user } = useUser();
  const queryClient = useQueryClient();
  const thread = useGetConversation(id, { query: { queryKey: getGetConversationQueryKey(id), enabled: isSignedIn === true && !!id, refetchInterval: 15000 } });
  const send = useSendConversationMessage();
  const [sendError, setSendError] = useState('');
  const form = useForm<Values>({ resolver: zodResolver(schema), defaultValues: { body: '' } });
  const onSubmit = ({ body }: Values) => {
    setSendError('');
    send.mutate({ id, data: { body: body.trim() } }, {
      onSuccess: () => {
        form.reset();
        void queryClient.invalidateQueries({ queryKey: getGetConversationQueryKey(id) });
        void queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      },
      onError: () => setSendError('Your reply could not be sent. Please try again.'),
    });
  };

  return <main className="content-shell account-page">
    <Link href="/messages" className="inline-flex items-center gap-2 text-sm text-[var(--teal)] mb-5 no-underline hover:underline" data-testid="link-back-inbox"><ArrowLeft size={15} /> Back to inbox</Link>
    <AccountHeading label="Private conversation" title={thread.data?.conversation.otherUserName || 'Conversation'} description={thread.data?.conversation.listingTitle} />
    {!isLoaded ? <AccountLoading /> : !isSignedIn ? <AccountSignIn message="Sign in to read and reply to your private conversations." /> : thread.isLoading ? <AccountLoading /> : thread.isError || !thread.data ? <AccountError title="Conversation unavailable" onRetry={() => void thread.refetch()} /> :
      <>
        <div className="flex flex-wrap gap-4 items-center justify-between mb-5">
          <Link href={`/listings/${encodeURIComponent(thread.data.conversation.listingId)}`} className="text-[var(--teal)] font-semibold underline" data-testid="link-thread-listing">View listing: {thread.data.conversation.listingTitle}</Link>
          <Link href={`/profiles/${encodeURIComponent(thread.data.conversation.otherUserId)}`} className="text-[var(--teal)] font-semibold underline" data-testid="link-thread-profile">View {thread.data.conversation.otherUserName}'s profile</Link>
        </div>
        {thread.data.messages.length === 0 ? <AccountEmpty title="No messages yet" description="Start this conversation by sending a message below." /> :
          <div className="thread" aria-label="Conversation messages" data-testid="list-thread-messages">
            {thread.data.messages.map((message) => <div key={message.id} className={`thread-bubble ${message.senderId === user?.id ? 'mine' : ''}`} data-testid={`message-${message.id}`}>
              <p>{message.body}</p><time dateTime={message.createdAt}>{displayDate(message.createdAt)}</time>
            </div>)}
          </div>}
        <div className="account-panel thread-reply">
          <h2>Write a reply</h2>
          <Form {...form}><form onSubmit={form.handleSubmit(onSubmit)} className="account-form">
            <FormField control={form.control} name="body" render={({ field }) => <FormItem className="form-field"><FormLabel>Your message</FormLabel><FormControl><textarea {...field} maxLength={4000} placeholder="Write a reply…" data-testid="input-reply-message" /></FormControl><FormMessage className="field-error" /></FormItem>} />
            {sendError && <p role="alert" className="account-feedback error" data-testid="status-reply-error">{sendError}</p>}
            <button type="submit" className="button-primary" disabled={send.isPending} data-testid="button-send-reply"><Send size={16} /> {send.isPending ? 'Sending…' : 'Send reply'}</button>
          </form></Form>
        </div>
      </>}
  </main>;
}