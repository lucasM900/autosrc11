import { useMemo, useState } from 'react';
import {
  getAdminListBannerCampaignsQueryKey,
  getAdminListBannerLocationsQueryKey,
  getGetAdminWebsiteAnalyticsQueryKey,
  useAdminApproveBannerCampaign,
  useAdminCancelBannerCampaign,
  useAdminCreateBannerLocation,
  useAdminEditBannerCampaign,
  useAdminExtendBannerCampaign,
  useAdminListBannerCampaigns,
  useAdminListBannerLocations,
  useAdminRejectBannerCampaign,
  useAdminRemoveBannerCampaign,
  useAdminUpdateBannerLocation,
  useAdminUpdateBannerPrice,
  useGetAdminWebsiteAnalytics,
  type BannerAdvertisement,
  type BannerLocation,
} from '@workspace/api-client-react';
import { format } from 'date-fns';
import { Check, Database, DollarSign, Edit3, Eye, Layers3, LogIn, Plus, Power, ShieldAlert, Trash2, TrendingUp, UserPlus, Users, X } from 'lucide-react';

const durations = [1, 3, 6, 12] as const;
const money = (minor: number, currency = 'CAD') =>
  new Intl.NumberFormat('en-CA', { style: 'currency', currency }).format(minor / 100);

export default function AdminAdvertising() {
  const [tab, setTab] = useState<'campaigns' | 'locations'>('campaigns');
  const [statusFilter, setStatusFilter] = useState('all');
  const [actionError, setActionError] = useState('');
  const [importStatus, setImportStatus] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [analyticsDays, setAnalyticsDays] = useState<7 | 30 | 90>(30);
  const [newLocation, setNewLocation] = useState({
    name: '', placementKey: '', page: 'listings', desktopWidth: '300', desktopHeight: '200',
    mobileWidth: '', mobileHeight: '',
  });
  const locationQuery = useAdminListBannerLocations({
    query: { queryKey: getAdminListBannerLocationsQueryKey(), retry: false },
  });
  const campaignQuery = useAdminListBannerCampaigns({
    query: { queryKey: getAdminListBannerCampaignsQueryKey(), retry: false },
  });
  const createLocation = useAdminCreateBannerLocation();
  const updateLocation = useAdminUpdateBannerLocation();
  const updatePrice = useAdminUpdateBannerPrice();
  const approve = useAdminApproveBannerCampaign();
  const reject = useAdminRejectBannerCampaign();
  const cancel = useAdminCancelBannerCampaign();
  const remove = useAdminRemoveBannerCampaign();
  const extend = useAdminExtendBannerCampaign();
  const editCampaign = useAdminEditBannerCampaign();
  const analyticsQuery = useGetAdminWebsiteAnalytics(
    { days: analyticsDays },
    { query: { queryKey: getGetAdminWebsiteAnalyticsQueryKey({ days: analyticsDays }), retry: false, refetchInterval: 60_000 } },
  );

  const campaigns = useMemo(
    () => (campaignQuery.data ?? []).filter(campaign => statusFilter === 'all' || campaign.status === statusFilter),
    [campaignQuery.data, statusFilter],
  );
  const overview = useMemo(() => {
    const allCampaigns = campaignQuery.data ?? [];
    return {
      activeCampaigns: allCampaigns.filter(campaign => campaign.status === 'active').length,
      pendingApproval: allCampaigns.filter(campaign => campaign.status === 'pending_approval').length,
      activeLocations: (locationQuery.data ?? []).filter(location => location.isActive).length,
      bookedValue: allCampaigns
        .filter(campaign => !['cancelled', 'rejected'].includes(campaign.status))
        .reduce((total, campaign) => total + campaign.amountMinor, 0),
    };
  }, [campaignQuery.data, locationQuery.data]);

  if (locationQuery.isError) {
    return (
      <main className="content-shell py-20">
        <div className="state-panel border-[var(--oxide)]" role="alert" data-testid="status-admin-forbidden">
          <ShieldAlert size={48} />
          <h1>Owner access required</h1>
          <p>This area is available only to the configured Autoshop Source owner account.</p>
        </div>
      </main>
    );
  }

  const run = async (action: () => Promise<unknown>, refresh: 'campaigns' | 'locations') => {
    setActionError('');
    try {
      await action();
      await (refresh === 'campaigns' ? campaignQuery.refetch() : locationQuery.refetch());
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'The admin action could not be completed.');
    }
  };

  const createInventory = async (event: React.FormEvent) => {
    event.preventDefault();
    await run(() => createLocation.mutateAsync({
      data: {
        name: newLocation.name,
        placementKey: newLocation.placementKey,
        page: newLocation.page,
        desktopWidth: Number(newLocation.desktopWidth),
        desktopHeight: Number(newLocation.desktopHeight),
        mobileWidth: newLocation.mobileWidth ? Number(newLocation.mobileWidth) : null,
        mobileHeight: newLocation.mobileHeight ? Number(newLocation.mobileHeight) : null,
        isActive: true,
        approvalRequired: false,
      },
    }), 'locations');
    setNewLocation({ name: '', placementKey: '', page: 'listings', desktopWidth: '300', desktopHeight: '200', mobileWidth: '', mobileHeight: '' });
  };

  const editLocation = (location: BannerLocation) => {
    const name = prompt('Location name', location.name);
    if (!name) return;
    run(() => updateLocation.mutateAsync({
      locationId: location.id,
      data: { name, approvalRequired: confirm('Require admin approval for new paid campaigns in this location?') },
    }), 'locations');
  };

  const editLocationPrice = (location: BannerLocation, duration: typeof durations[number]) => {
    const current = location.prices.find(price => price.durationMonths === duration);
    const dollars = prompt(`Price for ${duration} month${duration > 1 ? 's' : ''} in CAD`, current ? String(current.amountMinor / 100) : '');
    if (!dollars || Number(dollars) <= 0) return;
    run(() => updatePrice.mutateAsync({
      locationId: location.id,
      durationMonths: duration,
      data: { amountMinor: Math.round(Number(dollars) * 100), isActive: true },
    }), 'locations');
  };

  const editDestination = (campaign: BannerAdvertisement) => {
    const destinationUrl = prompt('Destination URL', campaign.destinationUrl);
    if (!destinationUrl) return;
    run(() => editCampaign.mutateAsync({ adId: campaign.id, data: { destinationUrl } }), 'campaigns');
  };

  const importLatestApifyRun = async () => {
    setActionError('');
    setImportStatus('');
    setIsImporting(true);
    try {
      const response = await fetch('/api/admin/imports/apify/latest', { method: 'POST' });
      const result = await response.json() as { imported?: number; skipped?: number; received?: number; error?: string };
      if (!response.ok) throw new Error(result.error || 'The Apify import failed.');
      setImportStatus(`Imported ${result.imported ?? 0} of ${result.received ?? 0} records. ${result.skipped ?? 0} duplicate or invalid records were skipped.`);
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'The Apify import failed.');
    } finally {
      setIsImporting(false);
    }
  };

  const extendCampaign = (campaign: BannerAdvertisement) => {
    const raw = prompt('Extend by 1, 3, 6, or 12 months', '1');
    const duration = Number(raw);
    if (!durations.includes(duration as typeof durations[number])) return;
    run(() => extend.mutateAsync({
      adId: campaign.id,
      data: { durationMonths: duration as typeof durations[number] },
    }), 'campaigns');
  };

  return (
    <div className="min-h-[100dvh] bg-[var(--paper)]">
      <section className="bg-[var(--steel-dark)] border-b-4 border-[var(--oxide)] py-8">
        <div className="content-shell">
          <p className="section-kicker text-[var(--yellow)]">Restricted operations</p>
          <h1 className="font-oswald text-4xl uppercase text-white">Advertising Control Room</h1>
        </div>
      </section>
      <main className="content-shell py-8">
        <section className="seller-card mb-7" aria-labelledby="traffic-heading">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-5">
            <div>
              <p className="section-kicker">Website traffic</p>
              <h2 id="traffic-heading" className="font-oswald text-2xl uppercase">Real visitor activity</h2>
              <p className="text-sm text-[var(--steel-line)] mt-1">Approximate people based on anonymous browser IDs. Known bots are excluded; no names, emails, or raw IP addresses are stored.</p>
            </div>
            <label className="text-xs font-bold uppercase">Period
              <select className="block mt-1 border-2 border-[var(--steel-dark)] bg-white p-2" value={analyticsDays} onChange={event => setAnalyticsDays(Number(event.target.value) as 7 | 30 | 90)}>
                <option value={7}>Last 7 days</option>
                <option value={30}>Last 30 days</option>
                <option value={90}>Last 90 days</option>
              </select>
            </label>
          </div>
          {analyticsQuery.isLoading ? (
            <div className="skeleton-row h-32" />
          ) : analyticsQuery.isError || !analyticsQuery.data ? (
            <p className="border border-[var(--oxide)] bg-[#f8e5e2] p-3 text-sm font-bold text-[var(--oxide)]">Traffic data could not be loaded.</p>
          ) : (
            <>
              <div className="grid sm:grid-cols-2 xl:grid-cols-6 gap-3">
                {[
                  { label: 'Unique people', value: analyticsQuery.data.uniqueVisitors, icon: Users },
                  { label: 'Visits', value: analyticsQuery.data.sessions, icon: TrendingUp },
                  { label: 'Page views', value: analyticsQuery.data.pageViews, icon: Eye },
                  { label: 'Logged-in people', value: analyticsQuery.data.authenticatedVisitors, icon: ShieldAlert },
                  { label: 'Logins', value: analyticsQuery.data.logins, icon: LogIn },
                  { label: 'Sign-ups', value: analyticsQuery.data.signups, icon: UserPlus },
                ].map(metric => (
                  <article className="border border-[var(--steel-line)] bg-white p-3" key={metric.label}>
                    <metric.icon size={18} />
                    <small className="block uppercase font-bold text-[var(--steel-line)] mt-2">{metric.label}</small>
                    <strong className="font-oswald text-3xl">{metric.value.toLocaleString()}</strong>
                  </article>
                ))}
              </div>
              <div className="grid lg:grid-cols-[1.4fr_1fr] gap-6 mt-6">
                <div>
                  <h3 className="font-oswald uppercase mb-3">Daily people</h3>
                  <div className="flex items-end gap-1 h-36 border-b border-[var(--steel-line)]" aria-label="Daily unique visitor chart">
                    {analyticsQuery.data.daily.slice(-30).map(day => {
                      const max = Math.max(1, ...analyticsQuery.data.daily.map(item => item.visitors));
                      return <div key={day.date} className="flex-1 bg-[var(--teal)] min-w-[3px]" style={{ height: `${Math.max(day.visitors ? 8 : 2, (day.visitors / max) * 100)}%` }} title={`${day.date}: ${day.visitors} people`} />;
                    })}
                  </div>
                </div>
                <div>
                  <h3 className="font-oswald uppercase mb-3">Top pages</h3>
                  <div className="grid gap-2">
                    {analyticsQuery.data.topPages.map(page => (
                      <div key={page.path} className="flex justify-between gap-3 border-b border-[var(--steel-line)] pb-2 text-sm">
                        <span className="truncate font-mono">{page.path}</span>
                        <strong className="whitespace-nowrap">{page.visitors} people · {page.views} views</strong>
                      </div>
                    ))}
                    {analyticsQuery.data.topPages.length === 0 && <p className="text-sm text-[var(--steel-line)]">Traffic will appear here after people visit the published site.</p>}
                  </div>
                </div>
              </div>
            </>
          )}
        </section>
        <section className="seller-card mb-7">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <p className="section-kicker">External inventory</p>
              <h2 className="font-oswald text-2xl uppercase">Kijiji import via Apify</h2>
              <p className="text-sm text-[var(--steel-line)] mt-2 max-w-3xl">Imports the latest successful dataset as clearly attributed external listings. Authorized listing photos are copied into Autoshop Source storage, original URLs are retained internally, and inquiries are recorded here for owner relay.</p>
            </div>
            <button className="button-primary shrink-0" onClick={importLatestApifyRun} disabled={isImporting} data-testid="button-import-apify">
              <Database size={17} /> {isImporting ? 'Importing…' : 'Import latest run'}
            </button>
          </div>
          {importStatus && <div className="mt-4 border border-[var(--teal)] bg-[var(--surface-blue)] p-3 text-sm font-bold" role="status">{importStatus}</div>}
        </section>
        <section className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-7" aria-label="Advertising overview">
          <article className="seller-card"><TrendingUp size={20} /><small className="block uppercase font-bold text-[var(--steel-line)] mt-3">Active campaigns</small><strong className="font-oswald text-3xl">{overview.activeCampaigns}</strong></article>
          <article className="seller-card"><ShieldAlert size={20} /><small className="block uppercase font-bold text-[var(--steel-line)] mt-3">Needs approval</small><strong className="font-oswald text-3xl">{overview.pendingApproval}</strong></article>
          <article className="seller-card"><Layers3 size={20} /><small className="block uppercase font-bold text-[var(--steel-line)] mt-3">Active ad spaces</small><strong className="font-oswald text-3xl">{overview.activeLocations}</strong></article>
          <article className="seller-card"><DollarSign size={20} /><small className="block uppercase font-bold text-[var(--steel-line)] mt-3">Booked campaign value</small><strong className="font-oswald text-3xl">{money(overview.bookedValue)}</strong></article>
        </section>
        <div className="flex flex-wrap gap-3 mb-7">
          <button className={tab === 'campaigns' ? 'button-primary' : 'button-secondary'} onClick={() => setTab('campaigns')} data-testid="button-admin-campaigns">Campaigns</button>
          <button className={tab === 'locations' ? 'button-primary' : 'button-secondary'} onClick={() => setTab('locations')} data-testid="button-admin-locations">Inventory & pricing</button>
        </div>
        {actionError && <div className="mb-5 border-2 border-[var(--oxide)] bg-[#f8e5e2] p-3 font-bold text-[var(--oxide)]" role="alert">{actionError}</div>}

        {tab === 'campaigns' ? (
          <>
            <div className="flex items-end justify-between gap-4 mb-4">
              <div><p className="section-kicker">Paid inventory</p><h2 className="font-oswald text-2xl uppercase">Campaign ledger</h2></div>
              <label className="text-xs font-bold uppercase">Status
                <select className="block mt-1 border-2 border-[var(--steel-dark)] bg-white p-2" value={statusFilter} onChange={event => setStatusFilter(event.target.value)} data-testid="select-campaign-status">
                  {['all', 'pending_payment', 'pending_approval', 'active', 'expired', 'cancelled', 'rejected'].map(status => <option key={status} value={status}>{status.replace('_', ' ')}</option>)}
                </select>
              </label>
            </div>
            <div className="admin-table-wrapper">
              <table className="admin-table">
                <thead><tr><th>Campaign</th><th>Status / dates</th><th>Performance</th><th>Value</th><th>Controls</th></tr></thead>
                <tbody>
                  {campaigns.map(campaign => (
                    <tr key={campaign.id} data-testid={`row-admin-campaign-${campaign.id}`}>
                      <td><strong>{campaign.locationName}</strong><br /><a href={campaign.destinationUrl} target="_blank" rel="noreferrer" className="text-xs text-[var(--teal)]">{campaign.destinationUrl}</a></td>
                      <td><span className="font-bold uppercase text-xs">{campaign.status.replace('_', ' ')}</span><br /><small>{campaign.startAt ? format(new Date(campaign.startAt), 'MMM d, yyyy') : 'Not started'} — {campaign.endAt ? format(new Date(campaign.endAt), 'MMM d, yyyy') : '—'}</small></td>
                      <td className="font-mono text-xs">{campaign.impressions.toLocaleString()} views<br />{campaign.clicks.toLocaleString()} clicks</td>
                      <td className="font-bold">{money(campaign.amountMinor, campaign.currency)}</td>
                      <td><div className="flex flex-wrap gap-2">
                        {campaign.status === 'pending_approval' && <>
                          <button title="Approve" onClick={() => run(() => approve.mutateAsync({ adId: campaign.id }), 'campaigns')} data-testid={`button-approve-${campaign.id}`}><Check size={17} /></button>
                          <button title="Reject" onClick={() => run(() => reject.mutateAsync({ adId: campaign.id }), 'campaigns')} data-testid={`button-reject-${campaign.id}`}><X size={17} /></button>
                        </>}
                        <button title="Edit destination" onClick={() => editDestination(campaign)} data-testid={`button-edit-${campaign.id}`}><Edit3 size={17} /></button>
                        {campaign.status === 'active' && <button title="Extend" onClick={() => extendCampaign(campaign)} data-testid={`button-extend-${campaign.id}`}>+M</button>}
                        {['active', 'pending_payment', 'pending_approval'].includes(campaign.status) && <button title="Cancel" onClick={() => confirm('Cancel this campaign?') && run(() => cancel.mutateAsync({ adId: campaign.id }), 'campaigns')} data-testid={`button-admin-cancel-${campaign.id}`}><Power size={17} /></button>}
                        {['expired', 'cancelled', 'rejected'].includes(campaign.status) && <button title="Remove" onClick={() => confirm('Permanently remove this campaign and analytics?') && run(() => remove.mutateAsync({ adId: campaign.id }), 'campaigns')} data-testid={`button-remove-${campaign.id}`}><Trash2 size={17} /></button>}
                      </div></td>
                    </tr>
                  ))}
                  {!campaignQuery.isLoading && campaigns.length === 0 && <tr><td colSpan={5} className="text-center py-10">No campaigns match this status.</td></tr>}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <div className="grid xl:grid-cols-[1fr_340px] gap-7">
            <section>
              <p className="section-kicker">Bookable surfaces</p>
              <h2 className="font-oswald text-2xl uppercase mb-4">Inventory & current prices</h2>
              <p className="text-sm text-[var(--steel-line)] mb-4">Click any duration price to change it immediately. Use Edit settings to rename a space or require campaign approval.</p>
              <div className="grid gap-4">
                {(locationQuery.data ?? []).map(location => (
                  <article className="seller-card" key={location.id} data-testid={`card-admin-location-${location.id}`}>
                    <div className="flex justify-between gap-4">
                      <div><h3>{location.name}</h3><p className="font-mono text-xs">{location.placementKey} · {location.desktopWidth}×{location.desktopHeight}{location.mobileWidth ? ` / ${location.mobileWidth}×${location.mobileHeight}` : ''}</p></div>
                      <span className="font-bold uppercase text-xs">{location.isActive ? 'Active' : 'Disabled'}{location.occupied ? ' · Occupied' : ''}</span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 my-4">
                      {durations.map(duration => {
                        const price = location.prices.find(item => item.durationMonths === duration);
                        return <button key={duration} className="border border-[var(--steel-line)] bg-[var(--paper)] p-2 text-left" onClick={() => editLocationPrice(location, duration)} data-testid={`button-price-${location.id}-${duration}`}><small>{duration} MONTHS</small><br /><strong>{price ? money(price.amountMinor, price.currency) : 'Set price'}</strong></button>;
                      })}
                    </div>
                    <div className="flex gap-2">
                      <button className="button-secondary" onClick={() => editLocation(location)} data-testid={`button-edit-location-${location.id}`}>Edit settings</button>
                      <button className="button-secondary" onClick={() => run(() => updateLocation.mutateAsync({ locationId: location.id, data: { isActive: !location.isActive } }), 'locations')} disabled={location.occupied && location.isActive} data-testid={`button-toggle-location-${location.id}`}>{location.isActive ? 'Disable' : 'Enable'}</button>
                    </div>
                  </article>
                ))}
              </div>
            </section>
            <form className="seller-card h-fit" onSubmit={createInventory}>
              <h3 className="flex items-center gap-2"><Plus size={18} /> New location</h3>
              {Object.entries(newLocation).map(([key, value]) => <label className="block mt-3 text-xs font-bold uppercase" key={key}>{key.replace(/([A-Z])/g, ' $1')}
                <input className="block w-full mt-1 border-2 border-[var(--steel-dark)] bg-white p-2 normal-case" value={value} onChange={event => setNewLocation(current => ({ ...current, [key]: event.target.value }))} required={['name', 'placementKey', 'page', 'desktopWidth', 'desktopHeight'].includes(key)} data-testid={`input-new-location-${key}`} />
              </label>)}
              <button className="button-primary w-full mt-5" disabled={createLocation.isPending} data-testid="button-create-location">Create location</button>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}