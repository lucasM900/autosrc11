import React, { useEffect, useState } from 'react';
import { useGetListingsSummary, useListListings, getListListingsQueryKey, getGetListingsSummaryQueryKey } from '@workspace/api-client-react';
import { ArrowUpRight, ChevronDown, Factory, PackageOpen, RefreshCw, Search, SlidersHorizontal, X } from 'lucide-react';
import { ListingCard } from '../components/listing-card';
import { categoryName, normalizePriceRange } from '../lib/constants';
import { SidebarFilters } from '../components/sidebar-filters';
import { SponsoredAd } from '../components/sponsored-ad';
import { setPageSeo } from '../lib/seo';

export default function Home() {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategories, setActiveCategories] = useState<string[]>([]);
  const [condition, setCondition] = useState<string[]>([]);
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [locationLabel, setLocationLabel] = useState('');
  const [radius, setRadius] = useState('25');
  const [equipmentTypes, setEquipmentTypes] = useState<string[]>([]);
  const [attributeFilters, setAttributeFilters] = useState<Record<string, any>>({});
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  const [rotationSeed, setRotationSeed] = useState(() => crypto.randomUUID());

  useEffect(() => {
    setPageSeo(
      'Shop Equipment Marketplace | Autoshop Source',
      'Browse vehicle lifts, tire changers, welders, compressors and other shop equipment from mechanics, shops and equipment owners worldwide on Autoshop Source.',
      '/',
    );
  }, []);

  const clearFilters = () => {
    setActiveCategories([]);
    setCondition([]);
    setMinPrice('');
    setMaxPrice('');
    setUserLocation(null);
    setLocationLabel('');
    setRadius('25');
    setEquipmentTypes([]);
    setAttributeFilters({});
  };

  const activeFilterCount =
    activeCategories.length +
    condition.length +
    (minPrice ? 1 : 0) +
    (maxPrice ? 1 : 0) +
    (userLocation ? 1 : 0) +
    equipmentTypes.length +
    Object.keys(attributeFilters).length;

  const queryParams: any = {
    search: searchTerm || undefined,
    category: activeCategories.length > 0 ? activeCategories.join(',') : undefined,
    condition: condition.length > 0 ? condition.join(',') : undefined,
    minPrice: normalizePriceRange(minPrice, maxPrice).min,
    maxPrice: normalizePriceRange(minPrice, maxPrice).max,
    latitude: userLocation?.lat,
    longitude: userLocation?.lng,
    radiusKm: userLocation ? Number(radius) : undefined,
    equipmentType: equipmentTypes.length > 0 ? equipmentTypes.join(',') : undefined,
    availability: Array.isArray(attributeFilters.availability)
      ? attributeFilters.availability.join(',')
      : attributeFilters.availability || undefined,
    attributeFilters: Object.keys(attributeFilters).length > 0 ? JSON.stringify(attributeFilters) : undefined,
    rotationSeed,
  };

  // Remove undefined values
  Object.keys(queryParams).forEach(key => queryParams[key] === undefined && delete queryParams[key]);

  const listingsQuery = useListListings(queryParams, { query: { queryKey: getListListingsQueryKey(queryParams), staleTime: 30_000, refetchInterval: 60_000 } });
  const summaryQuery = useGetListingsSummary({ query: { queryKey: getGetListingsSummaryQueryKey(), staleTime: 30_000 } });
  
  const listings = listingsQuery.data ?? [];

  return (
    <>
      <section className="hero">
        <div className="hero-inner">
          <div className="hero-copy">
            <p className="eyebrow">Global equipment marketplace / est. 2024</p>
            <h1>Tools that earn their keep.</h1>
            <p className="hero-lede">Find hoists, welders, compressors, generators, and shop essentials direct from the people who know them best — wherever they operate.</p>
            <div className="search-plate">
              <Search size={19} color="#1e2527" aria-hidden="true" />
              <input type="search" value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} placeholder="Search MIG welders, 2-post lifts, compressors..." aria-label="Search listings" data-testid="input-search-listings" />
              <button type="button" onClick={() => listingsQuery.refetch()} data-testid="button-search-listings">Search <ArrowUpRight size={16} /></button>
            </div>
          </div>
        </div>
      </section>
      <main className="content-shell">
        <div className="market-bar">
          <div><p className="section-kicker">Open board</p><h2>Available equipment</h2></div>
          <div className="market-meta">
            <span data-testid="text-listing-count">{listings.length} shown</span>
            <button type="button" className="refresh-button" onClick={() => { setRotationSeed(crypto.randomUUID()); summaryQuery.refetch(); }} aria-busy={listingsQuery.isFetching} data-testid="button-refresh-listings">
              <RefreshCw size={13} /> Refresh
            </button>
          </div>
        </div>
        
        <div className="mobile-filter-shell md:hidden mt-6">
          <button
            type="button"
            className="mobile-filter-trigger"
            aria-expanded={mobileFiltersOpen}
            aria-controls="mobile-marketplace-filters"
            onClick={() => setMobileFiltersOpen(open => !open)}
          >
            <span><SlidersHorizontal size={18} /> Filter listings</span>
            <span className="mobile-filter-trigger-meta">
              {activeFilterCount > 0 && <b>{activeFilterCount}</b>}
              <ChevronDown size={19} className={mobileFiltersOpen ? 'rotate-180' : ''} />
            </span>
          </button>
          {mobileFiltersOpen && (
            <div id="mobile-marketplace-filters" className="mobile-filter-panel">
              <div className="mobile-filter-panel-header">
                <div>
                  <span className="section-kicker">Refine results</span>
                  <h3>Filter by</h3>
                </div>
                <button type="button" onClick={() => setMobileFiltersOpen(false)} aria-label="Close filters"><X size={20} /></button>
              </div>
              <SidebarFilters
                activeCategories={activeCategories} setActiveCategories={setActiveCategories}
                condition={condition} setCondition={setCondition}
                minPrice={minPrice} setMinPrice={setMinPrice}
                maxPrice={maxPrice} setMaxPrice={setMaxPrice}
                userLocation={userLocation} setUserLocation={setUserLocation}
                locationLabel={locationLabel} setLocationLabel={setLocationLabel}
                radius={radius} setRadius={setRadius}
                equipmentTypes={equipmentTypes} setEquipmentTypes={setEquipmentTypes}
                attributeFilters={attributeFilters} setAttributeFilters={setAttributeFilters}
              />
              <div className="mobile-filter-actions">
                <button type="button" onClick={clearFilters} disabled={activeFilterCount === 0}>Clear all</button>
                <button type="button" className="button-primary" onClick={() => setMobileFiltersOpen(false)}>Show {listings.length} listings</button>
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-col md:flex-row gap-6 mt-6">
          <aside className="hidden md:block w-full md:w-[280px] shrink-0">
            <SidebarFilters
              activeCategories={activeCategories} setActiveCategories={setActiveCategories}
              condition={condition} setCondition={setCondition}
              minPrice={minPrice} setMinPrice={setMinPrice}
              maxPrice={maxPrice} setMaxPrice={setMaxPrice}
              userLocation={userLocation} setUserLocation={setUserLocation}
              locationLabel={locationLabel} setLocationLabel={setLocationLabel}
              radius={radius} setRadius={setRadius}
              equipmentTypes={equipmentTypes} setEquipmentTypes={setEquipmentTypes}
              attributeFilters={attributeFilters} setAttributeFilters={setAttributeFilters}
            />
          </aside>

          <div className="marketplace-results flex-1 min-w-0">
            <div className="summary-rail" aria-label="Marketplace summary">
              <div className="summary-cell"><strong data-testid="summary-total">{summaryQuery.data?.total ?? '—'}</strong><span>Total active listings</span></div>
              {['vehicle-lifts', 'welding', 'compressors'].map((cat) => (
                <div className="summary-cell" key={cat}>
                  <strong data-testid={`summary-${cat}`}>{summaryQuery.data?.byCategory?.[cat] ?? '—'}</strong>
                  <span>{categoryName(cat)}</span>
                </div>
              ))}
            </div>

            <div className="my-6">
              <SponsoredAd variant="horizontal" placementKey="horizontal-listings" />
            </div>

            {listingsQuery.isLoading ? (
              <div className="skeleton-stack" aria-label="Loading listings" data-testid="status-loading-listings">
                <div className="skeleton-row" /><div className="skeleton-row" /><div className="skeleton-row" />
              </div>
            ) : listingsQuery.isError ? (
              <div className="state-panel" role="alert" data-testid="status-listings-error">
                <Factory size={31} />
                <h3>Board temporarily offline</h3>
                <p>We couldn't load the equipment board. Check your connection, then try again.</p>
                <button type="button" className="state-action" onClick={() => listingsQuery.refetch()} data-testid="button-retry-listings">Try again</button>
              </div>
            ) : listings.length === 0 ? (
              <div className="state-panel" data-testid="status-listings-empty">
                <PackageOpen size={31} />
                <h3>No matching equipment</h3>
                <p>Try a wider search or switch categories. New equipment is added directly by shops and owners worldwide.</p>
                <button type="button" className="state-action" onClick={() => { setSearchTerm(''); clearFilters(); }} data-testid="button-clear-filters">Clear filters</button>
              </div>
            ) : (
              <div className="listing-stack">
                {listings.map((listing, index) => (
                  <React.Fragment key={listing.id}>
                    <ListingCard listing={listing} index={index} />
                    {(index + 1) % 3 === 0 && (
                      <div className="my-6">
                        <SponsoredAd
                          variant="horizontal"
                          placementKey={`horizontal-listings-${Math.floor((index + 1) / 3) + 1}`}
                        />
                      </div>
                    )}
                  </React.Fragment>
                ))}
              </div>
            )}
          </div>

          <aside className="hidden xl:block w-[190px] shrink-0" aria-label="Sponsored listings">
            <div className="sticky top-6 flex flex-col gap-4 pb-6">
              <SponsoredAd variant="vertical" placementKey="right-rail-1" />
              <SponsoredAd variant="vertical" placementKey="right-rail-2" />
            </div>
          </aside>
        </div>
      </main>
    </>
  );
}
