import React, { useEffect, useState } from 'react';
import { useListBannerLocations, useCreateBannerCampaign, BannerLocation, BannerCampaignInputDurationMonths, getListBannerLocationsQueryKey } from '@workspace/api-client-react';
import { useUpload } from '../hooks/use-upload';
import { validateAndReadImage } from '../lib/image-utils';
import { addMonths, format } from 'date-fns';
import { AlertCircle, ArrowRight, Loader2, UploadCloud, CheckCircle2 } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { setPageSeo } from '../lib/seo';

export default function Advertise() {
  useEffect(() => {
    setPageSeo(
      'Advertise to Equipment Buyers | Autoshop Source',
      'Reach mechanics, shops, and equipment buyers with advertising placements on Autoshop Source. Explore available ad space and create a campaign.',
      '/advertise',
    );
  }, []);

  const requestedPlacement = new URLSearchParams(window.location.search).get('placement');
  const [step, setStep] = useState(2);
  const [selectedLocation, setSelectedLocation] = useState<BannerLocation | null>(null);
  
  const [durationMonths, setDurationMonths] = useState<BannerCampaignInputDurationMonths>(1);
  
  const [desktopFile, setDesktopFile] = useState<File | null>(null);
  const [desktopPreview, setDesktopPreview] = useState<string>('');
  const [desktopError, setDesktopError] = useState<string>('');
  
  const [mobileFile, setMobileFile] = useState<File | null>(null);
  const [mobilePreview, setMobilePreview] = useState<string>('');
  const [mobileError, setMobileError] = useState<string>('');
  
  const [destinationUrl, setDestinationUrl] = useState('');
  const [submitError, setSubmitError] = useState('');
  
  const { data: locations, isLoading: loadingLocations, isError: locationsError } = useListBannerLocations({
    query: { queryKey: getListBannerLocationsQueryKey() }
  });
  const createCampaign = useCreateBannerCampaign();
  const { uploadFile, isUploading } = useUpload();
  const [, setPath] = useLocation();

  const activeLocations = locations?.filter(l => l.isActive) || [];

  useEffect(() => {
    const match = activeLocations.find(location => location.placementKey === requestedPlacement && !location.occupied);
    if (match && !selectedLocation) {
      setSelectedLocation(match);
      setStep(2);
    }
  }, [activeLocations, requestedPlacement, selectedLocation]);

  const handleDesktopFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedLocation) return;
    setDesktopError('');
    try {
      await validateAndReadImage(file, selectedLocation.desktopWidth, selectedLocation.desktopHeight, selectedLocation.maxFileSizeBytes);
      setDesktopFile(file);
      setDesktopPreview(URL.createObjectURL(file));
    } catch (err: any) {
      setDesktopError(err.message);
      e.target.value = '';
    }
  };

  const handleMobileFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedLocation?.mobileWidth || !selectedLocation?.mobileHeight) return;
    setMobileError('');
    try {
      await validateAndReadImage(file, selectedLocation.mobileWidth, selectedLocation.mobileHeight, selectedLocation.maxFileSizeBytes);
      setMobileFile(file);
      setMobilePreview(URL.createObjectURL(file));
    } catch (err: any) {
      setMobileError(err.message);
      e.target.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLocation || !desktopFile || !destinationUrl) return;
    setSubmitError('');

    try {
      const desktopPath = await uploadFile(desktopFile);
      let mobilePath = undefined;
      if (mobileFile) {
        mobilePath = await uploadFile(mobileFile);
      }

      const response = await createCampaign.mutateAsync({
        data: {
          locationId: selectedLocation.id,
          durationMonths: durationMonths,
          destinationUrl,
          desktop: {
            objectPath: desktopPath,
            width: selectedLocation.desktopWidth,
            height: selectedLocation.desktopHeight,
            sizeBytes: desktopFile.size,
            contentType: desktopFile.type
          },
          ...(mobilePath && mobileFile && selectedLocation.mobileWidth && selectedLocation.mobileHeight ? {
            mobile: {
              objectPath: mobilePath,
              width: selectedLocation.mobileWidth,
              height: selectedLocation.mobileHeight,
              sizeBytes: mobileFile.size,
              contentType: mobileFile.type
            }
          } : {})
        }
      });

      if (response.checkoutUrl) {
        window.location.assign(response.checkoutUrl);
      } else {
        setPath('/advertise/dashboard');
      }
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Unable to reserve this placement. Please try again.');
    }
  };

  const formatPrice = (minor: number, currency: string) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: currency.toUpperCase() }).format(minor / 100);
  };

  const immediateStart = new Date();
  const immediateEnd = addMonths(immediateStart, durationMonths);

  return (
    <div className="flex flex-col min-h-[100dvh] bg-[var(--paper)]">
      <section className="advertise-hero">
        <div className="content-shell">
          <h1>Direct Advertising</h1>
          <p>Book high-visibility placements across the marketplace. Flat rates, guaranteed delivery.</p>
        </div>
      </section>

      <main className="content-shell py-10">
        <div className="step-indicator">
          <div className="step-item" data-active={step === 2}>1. Duration</div>
          <div className="step-item" data-active={step === 3}>2. Creative</div>
          <div className="step-item" data-active={step === 4}>3. Review</div>
        </div>

        {!requestedPlacement && (
          <div className="state-panel" data-testid="status-placement-required">
            <h2>Choose the ad space you want</h2>
            <p>Campaigns are created directly from an available ad space on the marketplace. The space you click is the space you purchase.</p>
            <Link href="/" className="button-primary">View available ad spaces</Link>
          </div>
        )}

        {requestedPlacement && loadingLocations && (
          <div className="flex items-center gap-2 text-[var(--steel-line)]"><Loader2 className="animate-spin" /> Loading selected ad space...</div>
        )}

        {requestedPlacement && locationsError && (
          <div className="state-panel" role="alert" data-testid="status-ad-inventory-error">Advertising inventory is temporarily unavailable.</div>
        )}

        {requestedPlacement && !loadingLocations && !locationsError && !selectedLocation && (
          <div className="state-panel" role="alert" data-testid="status-placement-unavailable">
            <h2>This ad space is no longer available</h2>
            <p>Return to the marketplace and choose another visible advertising space.</p>
            <Link href="/" className="button-primary">View available ad spaces</Link>
          </div>
        )}

        {requestedPlacement && step === 2 && selectedLocation && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
            <h2 className="text-2xl font-['Barlow_Condensed'] uppercase font-bold text-[var(--steel-dark)] mb-6">Select campaign duration</h2>
            
            <div className="duration-grid">
              {selectedLocation.prices.map(price => (
                <div 
                  key={price.id} 
                  className="duration-card"
                  data-selected={durationMonths === price.durationMonths}
                  onClick={() => setDurationMonths(price.durationMonths as any)}
                >
                  <h4>{price.durationMonths} Month{price.durationMonths > 1 ? 's' : ''}</h4>
                  <p>{formatPrice(price.amountMinor, price.currency)}</p>
                </div>
              ))}
            </div>

            <div className="mt-8 p-6 bg-[#fbf9f4] border border-[var(--steel-line)]">
              <h4 className="font-['Barlow_Condensed'] uppercase font-bold mb-2">Estimated Schedule</h4>
              <p className="text-[var(--steel-dark)]">Start: <strong>{format(immediateStart, 'MMMM d, yyyy')}</strong> (Immediate)</p>
              <p className="text-[var(--steel-dark)]">End: <strong>{format(immediateEnd, 'MMMM d, yyyy')}</strong></p>
              <p className="text-sm text-[var(--steel-line)] mt-2">
                The slot is reserved for 30 minutes while you complete payment. Campaigns begin only after successful payment.
              </p>
            </div>

            <div className="mt-10 flex gap-4">
              {requestedPlacement ? (
                <button className="button-secondary" onClick={() => setPath('/')}>Back to listings</button>
              ) : (
                <button className="button-secondary" onClick={() => setStep(1)}>Back</button>
              )}
              <button className="button-primary" onClick={() => setStep(3)}>Continue <ArrowRight size={18} /></button>
            </div>
          </div>
        )}

        {step === 3 && selectedLocation && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
            <h2 className="text-2xl font-['Barlow_Condensed'] uppercase font-bold text-[var(--steel-dark)] mb-6">Upload Creatives</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-bold mb-2">Desktop Banner <span className="text-[var(--oxide)]">*</span></h3>
                <p className="text-sm text-[var(--steel-line)] mb-4">
                   Required exactly {selectedLocation.desktopWidth}x{selectedLocation.desktopHeight}px. Max {Math.round(selectedLocation.maxFileSizeBytes / 1024 / 1024)}MB (JPG/PNG/WebP).
                </p>
                
                {desktopPreview ? (
                  <div className="upload-preview relative">
                    <img src={desktopPreview} alt="Desktop creative preview" />
                    <button 
                      className="absolute top-2 right-2 bg-[var(--oxide)] text-white p-1 text-xs font-bold"
                      onClick={() => { setDesktopFile(null); setDesktopPreview(''); }}
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <label className="upload-box block">
                    <UploadCloud className="mx-auto mb-2 text-[var(--steel-line)]" size={32} />
                    <span className="font-bold text-[var(--steel-dark)]">Click to upload desktop image</span>
                    <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handleDesktopFile} />
                  </label>
                )}
                {desktopError && <div className="flex items-center gap-1 text-[var(--oxide)] text-sm font-bold mt-2"><AlertCircle size={14}/> {desktopError}</div>}
              </div>

              {selectedLocation.mobileWidth && selectedLocation.mobileHeight && (
                <div>
                  <h3 className="font-bold mb-2">Mobile Banner <span className="text-[var(--steel-line)] font-normal">(Optional)</span></h3>
                  <p className="text-sm text-[var(--steel-line)] mb-4">
                     Required exactly {selectedLocation.mobileWidth}x{selectedLocation.mobileHeight}px. Max {Math.round(selectedLocation.maxFileSizeBytes / 1024 / 1024)}MB. Will fall back to desktop if omitted.
                  </p>
                  
                  {mobilePreview ? (
                    <div className="upload-preview relative">
                      <img src={mobilePreview} alt="Mobile creative preview" />
                      <button 
                        className="absolute top-2 right-2 bg-[var(--oxide)] text-white p-1 text-xs font-bold"
                        onClick={() => { setMobileFile(null); setMobilePreview(''); }}
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <label className="upload-box block">
                      <UploadCloud className="mx-auto mb-2 text-[var(--steel-line)]" size={32} />
                      <span className="font-bold text-[var(--steel-dark)]">Click to upload mobile image</span>
                      <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handleMobileFile} />
                    </label>
                  )}
                  {mobileError && <div className="flex items-center gap-1 text-[var(--oxide)] text-sm font-bold mt-2"><AlertCircle size={14}/> {mobileError}</div>}
                </div>
              )}
            </div>

            <div className="mt-8 max-w-xl">
              <label className="block font-bold mb-2">Destination URL <span className="text-[var(--oxide)]">*</span></label>
              <input 
                type="url" 
                className="w-full border-2 border-[var(--steel-dark)] bg-white p-3 font-['Space_Mono',_monospace]" 
                placeholder="https://yourwebsite.com/offer"
                value={destinationUrl}
                onChange={e => setDestinationUrl(e.target.value)}
                required
                data-testid="input-ad-destination"
              />
            </div>

            <div className="mt-10 flex gap-4">
              <button className="button-secondary" onClick={() => setStep(2)}>Back</button>
              <button 
                className="button-primary" 
                 disabled={!desktopFile || !/^https?:\/\/\S+$/i.test(destinationUrl)}
                onClick={() => setStep(4)}
              >
                Review Order <ArrowRight size={18} />
              </button>
            </div>
          </div>
        )}

        {step === 4 && selectedLocation && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
            <h2 className="text-2xl font-['Barlow_Condensed'] uppercase font-bold text-[var(--steel-dark)] mb-6">Review & Checkout</h2>
            
            <div className="bg-[#fbf9f4] border-2 border-[var(--steel-dark)] p-8 max-w-3xl shadow-[6px_6px_0_rgba(24,39,53,0.15)]">
              <div className="grid grid-cols-2 gap-6 mb-8 pb-8 border-b border-[var(--steel-line)]">
                <div>
                  <div className="text-[var(--steel-line)] uppercase text-xs font-bold tracking-wider mb-1">Placement</div>
                  <div className="font-['Barlow_Condensed'] text-xl font-bold">{selectedLocation.name}</div>
                </div>
                <div>
                  <div className="text-[var(--steel-line)] uppercase text-xs font-bold tracking-wider mb-1">Duration</div>
                  <div className="font-['Barlow_Condensed'] text-xl font-bold">{durationMonths} Month{durationMonths > 1 ? 's' : ''}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-[var(--steel-line)] uppercase text-xs font-bold tracking-wider mb-1">Destination URL</div>
                  <a href={destinationUrl} target="_blank" rel="noreferrer" className="text-[var(--teal)] font-['Space_Mono',_monospace] text-sm break-all">{destinationUrl}</a>
                </div>
              </div>

              <div className="flex justify-between items-center mb-8">
                <span className="text-lg font-bold">Total Due</span>
                <span className="font-['Barlow_Condensed'] text-3xl font-bold text-[var(--steel-dark)]">
                  {formatPrice(selectedLocation.prices.find(p => p.durationMonths === durationMonths)?.amountMinor || 0, selectedLocation.prices[0]?.currency || 'usd')}
                </span>
              </div>

              {submitError && <div className="mb-4 border border-[var(--oxide)] bg-[#f8e5e2] p-3 text-sm font-bold text-[var(--oxide)]" role="alert" data-testid="status-checkout-error">{submitError}</div>}
              {isUploading || createCampaign.isPending ? (
                <div className="flex justify-center items-center gap-3 p-4 bg-[var(--surface-blue)] text-[var(--teal)] font-bold">
                  <Loader2 className="animate-spin" /> Processing order...
                </div>
              ) : (
                <div className="flex gap-4">
                  <button className="button-secondary flex-1" onClick={() => setStep(3)}>Back</button>
                  <button className="button-primary flex-1" onClick={handleSubmit} data-testid="button-proceed-payment">
                    Proceed to Payment
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
