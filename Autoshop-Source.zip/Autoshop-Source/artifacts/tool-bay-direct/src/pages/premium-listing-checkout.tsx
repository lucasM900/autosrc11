import { useGetListingPremiumStatus, getGetListingPremiumStatusQueryKey, getListSellerListingsQueryKey, getListListingsQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { CheckCircle2, Loader2, XCircle } from 'lucide-react';
import { Link } from 'wouter';
import { useEffect } from 'react';

export default function PremiumListingCheckout() {
  const params = new URLSearchParams(window.location.search);
  const listingId = params.get('listing_id') ?? '';
  const sessionId = params.get('session_id');
  const queryClient = useQueryClient();
  const query = useGetListingPremiumStatus(listingId, {
    query: {
      queryKey: getGetListingPremiumStatusQueryKey(listingId),
      enabled: Boolean(listingId && sessionId),
      refetchInterval: result => result.state.data?.isPremium ? false : 2000,
    },
  });

  useEffect(() => {
    if (!query.data?.isPremium) return;
    void queryClient.invalidateQueries({ queryKey: getListSellerListingsQueryKey() });
    void queryClient.invalidateQueries({ queryKey: getListListingsQueryKey() });
  }, [query.data?.isPremium, queryClient]);

  return (
    <main className="content-shell flex min-h-[65vh] items-center justify-center py-20">
      <div className="seller-card max-w-lg w-full text-center">
        {!listingId || !sessionId ? (
          <>
            <XCircle className="mx-auto text-oxide mb-4" size={48} />
            <h1 className="font-oswald text-3xl uppercase">Invalid premium checkout</h1>
            <Link href="/seller" className="button-primary mt-7 w-full">Return to Dashboard</Link>
          </>
        ) : query.isError ? (
          <>
            <XCircle className="mx-auto text-oxide mb-4" size={48} />
            <h1 className="font-oswald text-3xl uppercase">Verification failed</h1>
            <p className="text-steel-line mt-2">Your listing is safe. Check the dashboard to retry verification.</p>
            <Link href="/seller" className="button-primary mt-7 w-full">View Dashboard</Link>
          </>
        ) : query.data?.isPremium ? (
          <>
            <CheckCircle2 className="mx-auto text-sage mb-4" size={48} />
            <h1 className="font-oswald text-3xl uppercase">Premium activated</h1>
            <p className="text-steel-line mt-2">Your listing is eligible for rotating priority placement through its 90-day term.</p>
            <Link href="/seller" className="button-primary mt-7 w-full">View Dashboard</Link>
          </>
        ) : (
          <>
            <Loader2 className="mx-auto text-teal animate-spin mb-4" size={48} />
            <h1 className="font-oswald text-3xl uppercase">Verifying payment</h1>
            <p className="text-steel-line mt-2">Waiting for Stripe confirmation…</p>
          </>
        )}
      </div>
    </main>
  );
}