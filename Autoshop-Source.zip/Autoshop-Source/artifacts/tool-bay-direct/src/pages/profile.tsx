import { useEffect, useRef, useState } from 'react';
import { useAuth } from '@clerk/react';
import { useQueryClient } from '@tanstack/react-query';
import { getGetMyProfileQueryKey, getGetUserProfileQueryKey, getListListingsQueryKey, getListSellerListingsQueryKey, useGetMyProfile, useUpdateMyProfile, useRequestProfilePhotoUploadUrl, useUpdateMyProfilePhoto } from '@workspace/api-client-react';
import { Link } from 'wouter';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '../components/ui/form';
import { AccountError, AccountHeading, AccountLoading, AccountSignIn } from '../components/account-state';
import { MemberAvatar } from '../components/member-avatar';
import { ProfilePhotoEditor } from '../components/profile-photo-editor';
import { LocationAutocomplete } from '../components/location-autocomplete';

const schema = z.object({
  displayName: z.string().trim().min(2, 'Enter at least 2 characters').max(80),
  bio: z.string().trim().max(1000),
  location: z.string().trim().max(120),
});
type Values = z.infer<typeof schema>;

function requestStatus(error: unknown): number | null {
  if (error && typeof error === 'object' && 'status' in error && typeof error.status === 'number') {
    return error.status;
  }
  return null;
}

function photoRequestError(error: unknown, step: 'link' | 'save' | 'remove'): string {
  const status = requestStatus(error);
  if (status === 401 || status === 403) return 'Your sign-in has expired. Sign in again, then retry.';
  if (status === 404) return 'Profile pictures are unavailable right now. Refresh the page and try again.';
  if (status === 400 || status === 413) return 'We could not use that picture. Try another JPEG, PNG or WebP image.';
  if (status !== null && status >= 500) return 'The picture service is temporarily unavailable. Please try again shortly.';
  if (step === 'link') return 'We could not start the upload. Check your connection and try again.';
  if (step === 'remove') return 'We could not remove your picture. Check your connection and try again.';
  return 'We could not save the picture to your profile. Check your connection and try again.';
}

export default function Profile() {
  const { isLoaded, isSignedIn } = useAuth();
  const queryClient = useQueryClient();
  const profile = useGetMyProfile({ query: { queryKey: getGetMyProfileQueryKey(), enabled: isSignedIn === true } });
  const update = useUpdateMyProfile();
  const requestPhotoUrl = useRequestProfilePhotoUploadUrl();
  const updatePhoto = useUpdateMyProfilePhoto();
  const [photoBusy, setPhotoBusy] = useState(false);
  const [photoStage, setPhotoStage] = useState('');
  const [photoError, setPhotoError] = useState('');
  const [photoSuccess, setPhotoSuccess] = useState('');
  const [selectedPhoto, setSelectedPhoto] = useState<File | null>(null);
  const initializedUser = useRef<string | null>(null);
  const [saved, setSaved] = useState(false);
  const form = useForm<Values>({ resolver: zodResolver(schema), defaultValues: { displayName: '', bio: '', location: '' } });
  useEffect(() => {
    if (profile.data && initializedUser.current !== profile.data.userId) {
      initializedUser.current = profile.data.userId;
      form.reset({ displayName: profile.data.displayName, bio: profile.data.bio, location: profile.data.location });
    }
  }, [profile.data?.userId, form.reset]);

  const savePhoto = async (avatarPath: string | null) => {
    const result = await updatePhoto.mutateAsync({ data: { avatarPath } });
    queryClient.setQueryData(getGetMyProfileQueryKey(), result);
    queryClient.setQueryData(getGetUserProfileQueryKey(result.userId), result);
    // The text form stays untouched, including any unsaved changes.
    await Promise.allSettled([
      queryClient.invalidateQueries({ queryKey: getGetMyProfileQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getGetUserProfileQueryKey(result.userId) }),
      queryClient.invalidateQueries({ queryKey: getListListingsQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getListSellerListingsQueryKey() }),
      queryClient.invalidateQueries({ predicate: query => typeof query.queryKey[0] === 'string' && query.queryKey[0].startsWith('/api/listings/') }),
    ]);
  };

  const selectPhoto = (file: File) => {
    setPhotoError('');
    setPhotoSuccess('');
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setPhotoError('Choose a JPEG, PNG or WebP image.');
      return;
    }
    if (file.size > 20_000_000 || file.size === 0) {
      setPhotoError('Choose a non-empty image no larger than 20 MB. We will resize it before uploading.');
      return;
    }
    setSelectedPhoto(file);
  };

  const onPhotoSelected = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = '';
    if (file) selectPhoto(file);
  };

  const uploadPhoto = async (file: File) => {
    if (photoBusy) return;
    setPhotoError('');
    setPhotoBusy(true);
    try {
      setPhotoStage('Requesting upload…');
      let destination: { uploadURL: string; objectPath: string };
      try {
        destination = await requestPhotoUrl.mutateAsync({ data: { name: file.name, size: file.size, contentType: file.type } });
      } catch (error) {
        setPhotoError(`${photoRequestError(error, 'link')} Your crop is still here.`);
        return;
      }
      setPhotoStage('Uploading picture…');
      try {
        const response = await fetch(destination.uploadURL, { method: 'PUT', body: file, headers: { 'Content-Type': file.type } });
        if (!response.ok) {
          setPhotoError(response.status === 403
            ? 'The upload link expired. Retry to get a new link; your crop is still here.'
            : response.status === 413
              ? 'The picture is too large to upload. Choose a smaller image.'
              : 'The picture did not upload. Retry in a moment; your crop is still here.');
          return;
        }
      } catch {
        setPhotoError('The picture did not upload. Check your connection and retry; your crop is still here.');
        return;
      }
      setPhotoStage('Saving picture…');
      try {
        await savePhoto(destination.objectPath);
      } catch (error) {
        setPhotoError(`${photoRequestError(error, 'save')} Your crop is still here.`);
        return;
      }
      setPhotoSuccess('Profile picture updated.');
      setSelectedPhoto(null);
    } finally {
      setPhotoBusy(false);
      setPhotoStage('');
    }
  };

  const removePhoto = async () => {
    setPhotoError('');
    setPhotoSuccess('');
    setPhotoBusy(true);
    setPhotoStage('Removing picture…');
    try {
      await savePhoto(null);
      setPhotoSuccess('Profile picture removed.');
    } catch (error) {
      setPhotoError(photoRequestError(error, 'remove'));
    } finally {
      setPhotoBusy(false);
      setPhotoStage('');
    }
  };

  const onSubmit = (values: Values) => {
    if (photoBusy || update.isPending) return;
    setSaved(false);
    update.mutate({ data: values }, {
      onSuccess: (result) => {
        queryClient.setQueryData(getGetMyProfileQueryKey(), result);
        queryClient.setQueryData(getGetUserProfileQueryKey(result.userId), result);
        form.reset({ displayName: result.displayName, bio: result.bio, location: result.location });
        setSaved(true);
      },
    });
  };

  return <main className="content-shell account-page">
    <AccountHeading label="Your account / Public identity" title="My profile" description="The details other members see when they contact you." />
    {!isLoaded ? <AccountLoading /> : !isSignedIn ? <AccountSignIn message="Sign in to edit your public seller profile." /> : profile.isLoading ? <AccountLoading /> : profile.isError || !profile.data ? <AccountError onRetry={() => void profile.refetch()} /> :
      <div className="account-layout">
        <div className="account-panel">
          <section className="profile-photo-section" aria-label="Profile picture">
            <MemberAvatar name={profile.data.displayName} avatarPath={profile.data.avatarPath} size="large" testId="img-my-profile-picture" />
            <div className="profile-photo-actions">
              <h2>Profile picture</h2>
              <p>JPEG, PNG or WebP · 20 MB maximum. Crop and preview before uploading.</p>
              <div className="profile-photo-buttons">
                <input id="profile-photo-input" className="profile-photo-input" type="file" accept="image/jpeg,image/png,image/webp" disabled={photoBusy || update.isPending} onChange={onPhotoSelected} aria-describedby="profile-photo-help" data-testid="input-profile-photo" />
                <label htmlFor="profile-photo-input" className="button-secondary" aria-disabled={photoBusy || update.isPending} data-testid="button-choose-profile-photo">{profile.data.avatarPath ? 'Change picture' : 'Choose picture'}</label>
                {profile.data.avatarPath && <button type="button" className="button-secondary" onClick={removePhoto} disabled={photoBusy || update.isPending} data-testid="button-remove-profile-photo">Remove picture</button>}
              </div>
              <span id="profile-photo-help" className="sr-only">Choose a JPEG, PNG or WebP file no larger than 20 megabytes. It will be resized before upload.</span>
              {photoBusy && <p role="status" data-testid="status-profile-photo-loading">{photoStage}</p>}
              {photoError && !selectedPhoto && <p role="alert" className="account-feedback error" data-testid="status-profile-photo-error">{photoError}</p>}
              {photoSuccess && <p role="status" className="account-feedback" data-testid="status-profile-photo-success">{photoSuccess}</p>}
            </div>
          </section>
          <h2>Public details</h2>
          <p className="text-sm text-[var(--ink-soft)]">Use a name buyers will recognize. Your email address is never shown here.</p>
          <Form {...form}><form className="account-form" onSubmit={form.handleSubmit(onSubmit)}>
            <FormField control={form.control} name="displayName" render={({ field }) => <FormItem className="form-field"><FormLabel>Display name</FormLabel><FormControl><input {...field} maxLength={80} data-testid="input-profile-display-name" placeholder="Your name or shop name" /></FormControl><FormMessage className="field-error" /></FormItem>} />
            <FormField control={form.control} name="location" render={({ field }) => <FormItem className="form-field"><FormLabel htmlFor="profile-location">Location</FormLabel><LocationAutocomplete inputId="profile-location" inputName={field.name} value={field.value} onChange={field.onChange} onClear={() => {}} onBlur={field.onBlur} maxLength={120} testId="input-profile-location" placeholder="Search for a city or region" /><FormMessage className="field-error" /></FormItem>} />
            <FormField control={form.control} name="bio" render={({ field }) => <FormItem className="form-field"><FormLabel>About you</FormLabel><FormControl><textarea {...field} maxLength={1000} data-testid="input-profile-bio" placeholder="What equipment do you work with? Tell buyers a little about your shop." /></FormControl><small>Up to 1,000 characters</small><FormMessage className="field-error" /></FormItem>} />
            {update.isError && <p role="alert" className="account-feedback error" data-testid="status-profile-error">Could not save your profile. Please try again.</p>}
            {saved && <p role="status" className="account-feedback" data-testid="status-profile-saved">Profile updated. Your public page is now current.</p>}
            <button type="submit" className="button-primary" disabled={update.isPending || photoBusy || !form.formState.isDirty} data-testid="button-save-profile">{update.isPending ? 'Saving…' : 'Save profile'}</button>
          </form></Form>
        </div>
        <aside className="account-aside"><strong>How you appear to buyers</strong><p>Your display name, location and bio appear on your public profile. Direct conversations stay private.</p><Link href={`/profiles/${encodeURIComponent(profile.data.userId)}`} className="font-semibold underline" data-testid="link-view-public-profile">View public profile</Link></aside>
      </div>}
    {selectedPhoto && <ProfilePhotoEditor file={selectedPhoto} busy={photoBusy} stage={photoStage} uploadError={photoError}
      onCancel={() => { setSelectedPhoto(null); setPhotoError(''); }}
      onReplace={selectPhoto} onSave={uploadPhoto} />}
  </main>;
}