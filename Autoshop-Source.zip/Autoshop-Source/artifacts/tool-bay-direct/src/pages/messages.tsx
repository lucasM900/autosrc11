import { useState } from 'react';
import { useAuth, useUser } from '@clerk/react';
import { useQueryClient } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { Send } from 'lucide-react';
import { getGetConversationQueryKey, getGetListingQueryKey, getListConversationsQueryKey, useGetListing, useListConversations, useStartListingConversation } from '@workspace/api-client-react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '../components/ui/form';
import { AccountEmpty, AccountError, AccountHeading, AccountLoading, AccountSignIn } from '../components/account-state';

const schema = z.object({ body: z.string().trim().min(1, 'Write a message before sending').max(4000, 'Keep your message under 4,000 characters') });
type Values = z.infer<typeof schema>;
const displayDate = (date: string) => { const parsed = new Date(date); return Number.isNaN(parsed.getTime()) ? '' : parsed.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }); };

export default function Messages() {
  const { isLoaded, isSignedIn } = useAuth();
  const { user } = useUser();
  const [, navigate] = useLocation();
  const listingId = new URLSearchParams(window.location.search).get('listing') || '';
  const queryClient = useQueryClient();
  const conversations = useListConversations({ query: { queryKey: getListConversationsQueryKey(), enabled: isSignedIn === true, refetchInterval: 15000 } });
  const listing = useGetListing(listingId, undefined, { query: { queryKey: getGetListingQueryKey(listingId), enabled: isSignedIn === true && !!listingId } });
  const start = useStartListingConversation();
  const [formError, setFormError] = useState('');
  const form = useForm<Values>({ resolver: zodResolver(schema), defaultValues: { body: '' } });
  const imported = !!listing.data?.attributes?.externalListing;
  const own = !!listing.data?.ownerId && listing.data.ownerId === user?.id;
  const unavailable = listing.data?.status === 'sold';
  const canSend = !!listing.data?.ownerId && !imported && !own && !unavailable;
  const onSubmit = ({ body }: Values) => {
    if (!canSend || !isSignedIn) return;
    setFormError('');
    start.mutate({ id: listingId, data: { body: body.trim() } }, {
      onSuccess: (conversation) => {
        void queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
        void queryClient.invalidateQueries({ queryKey: getGetConversationQueryKey(conversation.id) });
        navigate(`/messages/${encodeURIComponent(conversation.id)}`);
      },
      onError: () => setFormError('Your message could not be sent. Please try again.'),
    });
  };

  return <main className="content-shell account-page">
    <AccountHeading label="Your account / Direct contact" title="Messages" description="Private conversations about equipment listed by members." />
    {!isLoaded ? <AccountLoading /> : !isSignedIn ? <AccountSignIn message="Sign in to read and send private messages to listing owners." /> : <>
      {listingId && <div className="account-panel message-compose">
        <span className="account-kicker">New conversation</span>
        {listing.isLoading ? <div className="skeleton-row account-skeleton mt-4" /> : listing.isError || !listing.data ? <AccountError title="Listing unavailable" onRetry={() => void listing.refetch()} /> :
          imported ? <div className="account-feedback error" data-testid="status-imported-no-message">This listing was imported from another marketplace. Its source seller does not have an account here, so private messaging is unavailable. <Link href={`/listings/${encodeURIComponent(listingId)}`} className="underline" data-testid="link-imported-inquiry">Use the listing inquiry form instead</Link>.</div> :
          own ? <div className="account-feedback" data-testid="status-own-listing">This is your listing. You can reply to buyer messages in your inbox below.</div> :
          unavailable ? <div className="account-feedback" data-testid="status-listing-sold">This listing is sold and no longer accepting messages.</div> :
          !listing.data.ownerId ? <div className="account-feedback error" data-testid="status-no-seller-account">This listing does not have a member seller available for direct messages.</div> :
          <>
            <h2 data-testid="text-compose-listing">{listing.data.title}</h2>
            <p className="text-sm text-[var(--ink-soft)]">Your message goes directly to the member who listed this equipment.</p>
            <Form {...form}><form onSubmit={form.handleSubmit(onSubmit)} className="account-form">
              <FormField control={form.control} name="body" render={({ field }) => <FormItem className="form-field"><FormLabel>Message to seller</FormLabel><FormControl><textarea {...field} maxLength={4000} placeholder="Ask about condition, pickup, or availability…" data-testid="input-new-message" /></FormControl><FormMessage className="field-error" /></FormItem>} />
              {formError && <p role="alert" className="account-feedback error" data-testid="status-send-error">{formError}</p>}
              <button type="submit" className="button-primary" disabled={start.isPending} data-testid="button-start-conversation"><Send size={16} /> {start.isPending ? 'Sending…' : 'Send message'}</button>
            </form></Form>
          </>}
      </div>}
      <div className="account-heading"><div><span className="account-kicker">Direct messages</span><h1 className="!text-3xl">Inbox</h1></div></div>
      {conversations.isLoading ? <AccountLoading /> : conversations.isError ? <AccountError title="Could not load conversations" onRetry={() => void conversations.refetch()} /> : !conversations.data?.length ? <AccountEmpty title="No conversations yet" description="When you contact a member about equipment, or a buyer contacts you, the conversation will appear here." /> :
        <div className="message-list" data-testid="list-conversations">{conversations.data.map((conversation) =>
          <Link key={conversation.id} href={`/messages/${encodeURIComponent(conversation.id)}`} className="message-row" data-testid={`link-conversation-${conversation.id}`}>
            <div className="message-avatar" aria-hidden="true">{conversation.otherUserName?.charAt(0).toUpperCase() || 'M'}</div>
            <div className="min-w-0"><strong data-testid={`text-conversation-name-${conversation.id}`}>{conversation.otherUserName}</strong><span>{conversation.listingTitle}</span><small data-testid={`text-last-message-${conversation.id}`}>{conversation.lastMessage}</small></div>
            <time dateTime={conversation.updatedAt}>{displayDate(conversation.updatedAt)}</time>
          </Link>)}</div>}
    </>}
  </main>;
}