import { SignUp } from '@clerk/react';
import { ArrowLeft, Globe, Wrench, Cog, Network } from 'lucide-react';
import { Link } from 'wouter';

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

export default function SignUpPage() {
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#fbfaf6]">
      <div className="w-full md:w-[45%] lg:w-[50%] flex flex-col justify-between p-6 md:p-12 relative overflow-hidden shrink-0 border-b-[3px] border-[#f4bd22] md:border-b-0 md:border-r-[3px]" style={{
        background: `
          linear-gradient(110deg, rgba(24,39,53,.98) 0%, rgba(38,61,77,.94) 67%, rgba(46,113,128,.92) 100%),
          linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px)
        `,
        backgroundSize: '100% 100%, 24px 24px, 24px 24px'
      }}>
        {/* Animated Scan Line */}
        <div className="auth-scan-line"></div>

        {/* Subtle Orbiting Motifs in Background */}
        <div className="absolute inset-0 pointer-events-none opacity-20 overflow-hidden flex items-center justify-center">
           <div className="auth-orbit absolute w-[600px] h-[600px] rounded-full border border-dashed border-[#b8c9ce]/20 flex items-center justify-center">
              <Cog className="absolute top-0 -mt-3 text-[#f4bd22]" size={24} />
              <div className="w-[400px] h-[400px] rounded-full border border-[#b8c9ce]/10 flex items-center justify-center auth-orbit" style={{ animationDirection: 'reverse', animationDuration: '45s' }}>
                <Wrench className="absolute bottom-0 -mb-2.5 text-[#b8c9ce]" size={20} />
                <div className="w-[200px] h-[200px] rounded-full border border-dotted border-[#f4bd22]/30 flex items-center justify-center auth-orbit" style={{ animationDuration: '30s' }}>
                  <Network className="absolute right-0 -mr-2.5 text-[#b8c9ce]" size={20} />
                </div>
              </div>
           </div>
        </div>

        {/* Top: Logo & Back Link */}
        <div className="relative z-10 flex flex-col items-start gap-6 md:gap-8">
          <Link href="/" className="inline-flex items-center gap-2 text-[#b8c9ce] hover:text-white text-sm font-['Space_Mono',_monospace] uppercase tracking-wider transition-colors bg-black/10 backdrop-blur-sm px-3 py-1.5 rounded-md border border-white/5">
            <ArrowLeft size={16} /> Return to Global Network
          </Link>
          <div className="md:hidden flex items-baseline gap-2 text-white font-['Barlow_Condensed',_sans-serif] text-[1.55rem] font-bold tracking-[0.025em]">
            <span className="text-[#f4bd22]">AUTOSHOP</span> SOURCE
          </div>
        </div>

        {/* Bottom: Copy */}
        <div className="relative z-10 mt-12 md:mt-0 hidden md:block">
          <div className="mb-6 inline-flex items-center gap-2 text-[#f4bd22] font-['Space_Mono',_monospace] text-xs font-bold uppercase tracking-widest bg-[#182735]/60 px-3 py-1.5 rounded-sm border border-[#f4bd22]/30">
            <Globe size={14} /> International Marketplace
          </div>
          <h1 className="font-['Barlow_Condensed',_sans-serif] text-white text-4xl md:text-5xl lg:text-[4rem] uppercase font-bold leading-[0.94] tracking-[-0.02em] mb-5 max-w-[15ch]">
            Global reach. <br/>Direct sourcing.
          </h1>
          <p className="text-[#c8d8d8] font-sans text-lg max-w-[36ch] leading-[1.65]">
            The unified network for shop owners worldwide. Connect across borders to source verified professional equipment with zero middleman friction.
          </p>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-center items-center p-6 py-12 md:p-12 bg-[#fbfaf6] relative">
        <div className="w-full max-w-[460px] animate-in fade-in slide-in-from-bottom-4 duration-700 ease-out z-10">
          <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
        </div>
      </div>
    </div>
  );
}
