import { useEffect, useState } from 'react';
import { useRoute, Link, useLocation } from 'wouter';
import { useGetListing, getGetListingQueryKey, useCreateInquiry } from '@workspace/api-client-react';
import { MapPin, ArrowLeft, ArrowRight, Send, ShieldCheck, Tag, Zap } from 'lucide-react';
import { categoryName, formatPrice } from '../lib/constants';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '../components/ui/form';
import { ListingAttributesDisplay } from '../components/listing-attributes-display';
import { setPageSeo } from '../lib/seo';
import { useAuth, useUser } from '@clerk/react';
import { MemberAvatar } from '../components/member-avatar';

const inquirySchema = z.object({
  name: z.string().trim().min(1, 'Name is required'),
  email: z.string().trim().email('Valid email is required'),
  message: z.string().trim().min(1, 'Message is required'),
});

type InquiryValues = z.infer<typeof inquirySchema>;

export default function ListingDetail() {
  const { isLoaded, isSignedIn } = useAuth();
  const { user } = useUser();
  const [, params] = useRoute('/listings/:id');
  const id = params?.id || '';
  const [location] = useLocation();
  const requestedAvailability = new URLSearchParams(location.split('?')[1] || '').get('availability') || undefined;
  
  const { data: listing, isLoading, isError } = useGetListing(id, { availability: requestedAvailability }, {
    query: { 
      enabled: !!id, 
      queryKey: getGetListingQueryKey(id, { availability: requestedAvailability }),
      refetchOnMount: 'always'
    } 
  });

  const createInquiry = useCreateInquiry();
  const [inquirySent, setInquirySent] = useState(false);
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  useEffect(() => {
    if (!listing) return;
    setPageSeo(
      `${listing.title} | Autoshop Source`,
      `${listing.title} in ${listing.location}. ${listing.spec || 'View equipment details, condition, asking price and photos on Autoshop Source.'}`.slice(0, 160),
      `/listings/${encodeURIComponent(listing.id)}`,
    );
  }, [listing]);

  useEffect(() => {
    const imageCount = listing?.imagePaths?.length || (listing?.image ? 1 : 0);
    setActiveImageIndex(current => imageCount > 0 ? Math.min(current, imageCount - 1) : 0);
  }, [listing?.imagePaths, listing?.image]);

  const form = useForm<InquiryValues>({
    resolver: zodResolver(inquirySchema),
    defaultValues: { name: '', email: '', message: '' },
  });

  const onSubmit = (values: InquiryValues) => {
    createInquiry.mutate(
      { id, data: values },
      {
        onSuccess: () => {
          setInquirySent(true);
          form.reset();
        }
      }
    );
  };

  if (isLoading) {
    return (
      <main className="content-shell" style={{ paddingTop: '40px' }}>
        <div className="skeleton-row" style={{ height: '400px' }} />
      </main>
    );
  }

  if (isError || !listing) {
    return (
      <main className="content-shell" style={{ paddingTop: '40px' }}>
        <div className="state-panel">
          <h3>Listing Not Found</h3>
          <p>This equipment may have been sold or removed by the seller.</p>
          <Link href="/" className="state-action inline-block mt-4">Back to Board</Link>
        </div>
      </main>
    );
  }

  // Use imagePaths if available, fallback to legacy image string
  const images = listing.imagePaths && listing.imagePaths.length > 0 
    ? listing.imagePaths.map(p => `/api/storage${p}`)
    : listing.image ? [listing.image] : [];
    
  const activeImage = images[activeImageIndex] || null;
  const availability = listing.status === 'sold'
    ? 'sold'
    : String(listing.attributes?.availability || 'available');
  const sourcePlatform = listing.attributes?.externalListing ? String(listing.attributes?.sourcePlatform || 'an external marketplace') : null;
  const memberSeller = !sourcePlatform && !!listing.ownerId;
  const isOwnListing = memberSeller && isSignedIn && user?.id === listing.ownerId;

  return (
    <main className="content-shell">
      <div className="pt-6 pb-2">
        <Link href="/" className="inline-flex items-center gap-2 text-steel-line hover:text-steel-dark text-sm font-mono uppercase tracking-wider transition-colors">
          <ArrowLeft size={14} /> Back to board
        </Link>
      </div>

      <div className="detail-layout">
        <div>
          {images.length > 0 ? (
            <div className="detail-gallery">
              <div className="main-image">
                <img src={activeImage!} alt={listing.title} />
                {images.length > 1 && (
                  <>
                    <button
                      type="button"
                      className="gallery-arrow gallery-arrow-prev"
                      onClick={() => setActiveImageIndex(index => (index - 1 + images.length) % images.length)}
                      aria-label="Show previous image"
                    >
                      <ArrowLeft size={22} />
                    </button>
                    <button
                      type="button"
                      className="gallery-arrow gallery-arrow-next"
                      onClick={() => setActiveImageIndex(index => (index + 1) % images.length)}
                      aria-label="Show next image"
                    >
                      <ArrowRight size={22} />
                    </button>
                  </>
                )}
              </div>
              {images.length > 1 && (
                <div className="thumbnail-strip">
                  {images.map((img, idx) => (
                    <button
                      key={img}
                      className={`thumbnail ${idx === activeImageIndex ? 'active' : ''}`}
                      onClick={() => setActiveImageIndex(idx)}
                      type="button"
                    >
                      <img src={img} alt={`Thumbnail ${idx + 1}`} />
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="main-image">
              <div className="no-photo flex flex-col items-center">
                <ShieldCheck size={48} className="mb-2 opacity-50" />
                No photos provided
              </div>
            </div>
          )}

          <div className="mt-12">
            <h2 className="font-oswald text-xl uppercase mb-4 border-b-2 border-steel-dark pb-2">Equipment Description</h2>
            <div className="detail-description">
              {listing.description || listing.spec}
            </div>
          </div>

          <ListingAttributesDisplay category={listing.category} attributes={listing.attributes} />
        </div>

        <div>
          <div className="detail-content">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`condition-badge condition-${listing.condition}`}>{listing.condition}</span>
              {availability !== 'available' && <span className={`condition-badge condition-${availability}`}>{availability}</span>}
              {sourcePlatform && <span className="source-badge">Imported from {sourcePlatform}</span>}
            </div>
            {sourcePlatform && (
              <div className="source-disclosure" role="note">
                <strong>External listing imported from {sourcePlatform}</strong>
                <p>The source seller did not create or manage this Autoshop Source listing. We record your inquiry here and the Autoshop Source owner can relay it to the source seller. Confirm availability, price, condition, and specifications before purchasing.</p>
              </div>
            )}
            <h1>{listing.title}</h1>
            <div className="detail-price">{formatPrice(listing.price, listing.currencyCode)}</div>

            <div className="detail-attributes">
              <div className="listing-fact">
                <span className="fact-label"><Tag size={12} /> Category</span>
                <span className="fact-value">{categoryName(listing.category)}</span>
              </div>
              <div className="listing-fact">
                <span className="fact-label"><MapPin size={12} /> Location</span>
                <span className="fact-value">{listing.location}</span>
              </div>
              <div className="listing-fact full-width col-span-2">
                <span className="fact-label"><Zap size={12} /> Key Specs</span>
                <span className="fact-value">{listing.spec}</span>
              </div>
            </div>
            {memberSeller && (
              <div className="detail-seller text-sm">
                <span className="fact-label">Listed by a member</span>
                <Link href={`/profiles/${encodeURIComponent(listing.ownerId!)}`} className="seller-link" data-testid="link-listing-seller-profile">
                  <MemberAvatar name={listing.sellerProfile?.displayName || 'Marketplace member'} avatarPath={listing.sellerProfile?.avatarPath} size="medium" testId="img-listing-seller" />
                  <span>{listing.sellerProfile?.displayName || 'Marketplace member'}</span>
                </Link>
              </div>
            )}

            {availability === 'sold' ? (
              <div className="inquiry-box">
                <h3>Listing Sold</h3>
                <p className="text-steel-line mt-3">This equipment is no longer available for purchase.</p>
              </div>
            ) : memberSeller ? (
              <div className="inquiry-box">
                <h3>Contact seller directly</h3>
                {isOwnListing ? (
                  <p className="text-[var(--ink-soft)]" data-testid="status-own-listing-contact">This is your listing. Buyer messages will appear in your <Link href="/messages" className="underline text-[var(--teal)]" data-testid="link-own-listing-inbox">inbox</Link>.</p>
                ) : (
                  <>
                    <p className="text-sm text-[var(--ink-soft)] mb-5">{isLoaded && !isSignedIn ? 'Sign in to send a private message to this seller.' : 'Ask the seller directly about condition, availability, or pickup.'}</p>
                    <Link href={isLoaded && !isSignedIn ? '/sign-in' : `/messages?listing=${encodeURIComponent(listing.id)}`} className="button-primary w-full no-underline" data-testid="link-send-listing-message">
                      <Send size={16} /> {isLoaded && !isSignedIn ? 'Sign in to send message' : 'Send message'}
                    </Link>
                  </>
                )}
              </div>
            ) : (
            <div className="inquiry-box">
              <h3>{sourcePlatform ? 'Request seller contact' : 'Contact Seller'}</h3>
              {sourcePlatform && <p className="text-sm text-steel-line mb-4">Your message stays on Autoshop Source and is recorded as a relay request. Delivery to or a response from the source seller is not guaranteed.</p>}
              {inquirySent ? (
                <div className="bg-sage text-paper p-4 text-center">
                  <ShieldCheck size={32} className="mx-auto mb-2" />
                  <p className="font-semibold mb-1">Message recorded.</p>
                  <p className="text-sm opacity-90">{sourcePlatform ? 'Autoshop Source will review this relay request.' : 'The seller will review your inquiry in their dashboard.'}</p>
                  <button 
                    onClick={() => setInquirySent(false)} 
                    className="mt-4 text-sm underline opacity-80 hover:opacity-100"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)}>
                    <div className="flex flex-col gap-4">
                      <FormField control={form.control} name="name" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Name</FormLabel>
                          <FormControl><input {...field} placeholder="Jane Doe" className="w-full p-2 border-2 border-steel-dark bg-paper" /></FormControl>
                          <FormMessage className="text-oxide text-xs font-semibold mt-1" />
                        </FormItem>
                      )} />
                      <FormField control={form.control} name="email" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Email</FormLabel>
                          <FormControl><input type="email" {...field} placeholder="jane@example.com" className="w-full p-2 border-2 border-steel-dark bg-paper" /></FormControl>
                          <FormMessage className="text-oxide text-xs font-semibold mt-1" />
                        </FormItem>
                      )} />
                      <FormField control={form.control} name="message" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Message</FormLabel>
                          <FormControl><textarea {...field} placeholder="Hi, I'm interested in..." className="w-full p-2 border-2 border-steel-dark bg-paper min-h-[100px] resize-y" /></FormControl>
                          <FormMessage className="text-oxide text-xs font-semibold mt-1" />
                        </FormItem>
                      )} />
                      <button 
                        type="submit" 
                        disabled={createInquiry.isPending}
                        className="button-primary w-full mt-2"
                      >
                        {createInquiry.isPending ? 'Sending...' : <><Send size={16} /> Send Inquiry</>}
                      </button>
                    </div>
                  </form>
                </Form>
              )}
            </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
