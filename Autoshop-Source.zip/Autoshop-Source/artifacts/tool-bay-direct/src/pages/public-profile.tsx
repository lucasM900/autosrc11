import { Link, useRoute } from 'wouter';
import { MapPin, ArrowLeft } from 'lucide-react';
import { getGetUserProfileQueryKey, useGetUserProfile } from '@workspace/api-client-react';
import { AccountError, AccountHeading, AccountLoading } from '../components/account-state';
import { MemberAvatar } from '../components/member-avatar';

export default function PublicProfile() {
  const [, params] = useRoute('/profiles/:userId');
  const userId = params?.userId || '';
  const profile = useGetUserProfile(userId, { query: { queryKey: getGetUserProfileQueryKey(userId), enabled: !!userId } });
  return <main className="content-shell account-page">
    <AccountHeading label="Marketplace / Member" title="Seller profile" />
    {profile.isLoading ? <AccountLoading /> : profile.isError || !profile.data ? <AccountError title="Profile unavailable" onRetry={() => void profile.refetch()} /> :
      <div className="account-panel" data-testid="card-public-profile">
         <MemberAvatar name={profile.data.displayName} avatarPath={profile.data.avatarPath} size="large" testId="img-public-profile-picture" />
        <h2 className="!text-3xl !mb-0" data-testid="text-public-display-name">{profile.data.displayName}</h2>
        {profile.data.location && <div className="profile-meta" data-testid="text-public-location"><MapPin size={16} /> {profile.data.location}</div>}
        <div className="profile-bio" data-testid="text-public-bio">{profile.data.bio || 'This member has not added a bio yet.'}</div>
        <p className="text-sm text-[var(--ink-soft)]">To ask about equipment, open one of this member’s listings and use Send message.</p>
        <Link href="/" className="button-secondary mt-5 no-underline" data-testid="link-back-marketplace"><ArrowLeft size={16} /> Browse equipment</Link>
      </div>}
  </main>;
}