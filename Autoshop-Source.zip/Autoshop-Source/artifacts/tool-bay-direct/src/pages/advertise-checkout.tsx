import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useGetBannerCheckoutStatus, getGetBannerCheckoutStatusQueryKey, getListBannerCampaignsQueryKey } from '@workspace/api-client-react';
import { CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { Link } from 'wouter';

export default function AdvertiseCheckout() {
  const queryClient = useQueryClient();
  const params = new URLSearchParams(window.location.search);
  const sessionId = params.get('session_id');
  const campaignId = params.get('campaign_id');
  const wasCancelled = params.get('cancelled') === '1';

  const { data: status, isLoading, isError } = useGetBannerCheckoutStatus(campaignId || '', {
    query: {
      queryKey: getGetBannerCheckoutStatusQueryKey(campaignId || ''),
      enabled: !!campaignId && !wasCancelled,
      refetchInterval: (query) => query.state.data?.status === 'pending_payment' ? 2000 : false
    }
  });
  useEffect(() => {
    if (status?.status === 'active' || status?.status === 'pending_approval') {
      void queryClient.invalidateQueries({ queryKey: getListBannerCampaignsQueryKey() });
    }
  }, [status?.status, queryClient]);

  return (
    <div className="flex flex-col min-h-[100dvh] bg-[var(--paper)]">
      <main className="content-shell flex-1 flex items-center justify-center py-20">
        <div className="bg-white border-2 border-[var(--steel-dark)] shadow-[8px_8px_0_rgba(24,39,53,0.15)] p-10 max-w-lg w-full text-center">
          
          {wasCancelled ? (
            <>
              <XCircle className="mx-auto text-[var(--oxide)] mb-4" size={48} />
              <h2 className="font-['Barlow_Condensed'] text-3xl uppercase font-bold mb-2">Checkout Cancelled</h2>
              <p className="text-[var(--steel-line)] mb-6">No campaign was activated. The temporary reservation will be released.</p>
              <Link href="/advertise" className="button-primary w-full" data-testid="link-retry-advertising">Return to Advertising</Link>
            </>
          ) : !campaignId || !sessionId ? (
            <>
              <XCircle className="mx-auto text-[var(--oxide)] mb-4" size={48} />
              <h2 className="font-['Barlow_Condensed'] text-3xl uppercase font-bold mb-2">Invalid Session</h2>
              <p className="text-[var(--steel-line)] mb-6">Missing checkout parameters.</p>
              <Link href="/advertise" className="button-primary w-full">Return to Advertising</Link>
            </>
          ) : isLoading ? (
            <>
              <Loader2 className="mx-auto text-[var(--teal)] animate-spin mb-4" size={48} />
              <h2 className="font-['Barlow_Condensed'] text-3xl uppercase font-bold mb-2">Verifying Payment</h2>
              <p className="text-[var(--steel-line)]">Please wait while we confirm your transaction...</p>
            </>
          ) : isError ? (
            <>
              <XCircle className="mx-auto text-[var(--oxide)] mb-4" size={48} />
              <h2 className="font-['Barlow_Condensed'] text-3xl uppercase font-bold mb-2">Verification Failed</h2>
              <p className="text-[var(--steel-line)] mb-6">We could not verify this session. Please check your dashboard.</p>
              <Link href="/advertise/dashboard" className="button-primary w-full">View Dashboard</Link>
            </>
          ) : status?.status === 'pending_payment' ? (
            <>
              <Loader2 className="mx-auto text-[var(--teal)] animate-spin mb-4" size={48} />
              <h2 className="font-['Barlow_Condensed'] text-3xl uppercase font-bold mb-2">Processing Payment</h2>
              <p className="text-[var(--steel-line)]">Waiting for Stripe confirmation. This usually takes just a moment...</p>
            </>
          ) : status?.status === 'cancelled' || status?.status === 'rejected' ? (
            <>
              <XCircle className="mx-auto text-[var(--oxide)] mb-4" size={48} />
              <h2 className="font-['Barlow_Condensed'] text-3xl uppercase font-bold mb-2">Order Cancelled</h2>
              <p className="text-[var(--steel-line)] mb-6">Your payment was cancelled or declined.</p>
              <Link href="/advertise" className="button-primary w-full">Try Again</Link>
            </>
          ) : (
            <>
              <CheckCircle2 className="mx-auto text-[var(--sage)] mb-4" size={48} />
              <h2 className="font-['Barlow_Condensed'] text-3xl uppercase font-bold mb-2">Campaign Confirmed</h2>
              <p className="text-[var(--steel-dark)] mb-8">Your banner advertisement has been successfully booked.</p>
              <Link href="/advertise/dashboard" className="button-primary w-full">Go to Dashboard</Link>
            </>
          )}

        </div>
      </main>
    </div>
  );
}
