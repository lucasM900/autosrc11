import { Link } from 'wouter';
import { useListSellerListings, getListSellerListingsQueryKey, useListSellerInquiries, getListSellerInquiriesQueryKey, useDeleteSellerListing, useRenewSellerListing, useCancelSellerListing, useCreateListingPremiumCheckout, getGetListingsSummaryQueryKey, getListListingsQueryKey, getGetListingQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { Archive, Plus, Pencil, ArrowUpRight, RotateCw, Sparkles } from 'lucide-react';
import { categoryName, formatPrice } from '../lib/constants';
import { formatDistanceToNow } from 'date-fns';

export default function SellerDashboard() {
  const queryClient = useQueryClient();
  const { data: listings, isLoading: listingsLoading, isError: listingsError, refetch: refetchListings } = useListSellerListings({ query: { queryKey: getListSellerListingsQueryKey() } });
  const { data: inquiries, isLoading: inquiriesLoading, isError: inquiriesError, refetch: refetchInquiries } = useListSellerInquiries({ query: { queryKey: getListSellerInquiriesQueryKey() } });

  const deleteListing = useDeleteSellerListing();
  const renewListing = useRenewSellerListing();
  const cancelListing = useCancelSellerListing();
  const premiumCheckout = useCreateListingPremiumCheckout();
  const daysLeft = (expiresAt: string | null) => expiresAt
    ? Math.max(0, Math.ceil((new Date(expiresAt).getTime() - Date.now()) / 86_400_000))
    : 0;

  const handleDelete = (id: string) => {
    if (!confirm('Are you sure you want to permanently delete this listing?')) return;
    deleteListing.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSellerListingsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListListingsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetListingsSummaryQueryKey() });
      }
    });
  };

  const handleCancel = (id: string) => {
    if (!confirm('Are you sure you want to cancel this listing? It will no longer be visible to buyers.')) return;
    cancelListing.mutate({ id }, {
      onSuccess: () => {
        queryClient.removeQueries({ queryKey: getGetListingQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getListSellerListingsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListListingsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetListingsSummaryQueryKey() });
      }
    });
  };

  const handleRenew = (id: string) => {
    renewListing.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSellerListingsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListListingsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetListingsSummaryQueryKey() });
      }
    });
  };

  const handlePremium = async (id: string) => {
    try {
      const checkout = await premiumCheckout.mutateAsync({ id });
      window.location.assign(checkout.checkoutUrl);
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Unable to start premium checkout.');
    }
  };

  return (
    <main className="content-shell" style={{ paddingTop: '40px' }}>
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="section-kicker">Seller Area</p>
          <h1 className="font-oswald text-3xl uppercase">Your Dashboard</h1>
        </div>
        <Link href="/seller/listings/new" className="button-primary">
          <Plus size={18} /> New Listing
        </Link>
      </div>

      <div className="seller-grid">
        <div>
          <div className="seller-card">
            <h3>Your Listings</h3>
            {listingsLoading ? (
              <div className="skeleton-stack">
                <div className="skeleton-row" style={{ minHeight: '120px' }} />
                <div className="skeleton-row" style={{ minHeight: '120px' }} />
              </div>
            ) : listingsError ? (
              <div className="py-8 text-center border-2 border-dashed border-oxide bg-paper">
                <p className="text-oxide mb-4 font-semibold">Could not load your listings. Your listings have not been deleted.</p>
                <button type="button" onClick={() => void refetchListings()} className="button-secondary">Try again</button>
              </div>
            ) : !listings?.length ? (
              <div className="py-8 text-center border-2 border-dashed border-steel-line bg-paper">
                <p className="text-steel-line mb-4 font-semibold">No listings found.</p>
                <Link href="/seller/listings/new" className="button-secondary">Create your first listing</Link>
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {listings.map(listing => (
                  <div key={listing.id} className="border-2 border-steel-dark bg-[#fbf9f4] p-4 flex gap-4 items-start">
                    {listing.imagePaths?.[0] || listing.image ? (
                      <div className="w-24 h-24 shrink-0 border border-steel-dark overflow-hidden bg-[#e4ded3]">
                        <img src={listing.imagePaths?.[0] ? `/api/storage${listing.imagePaths[0]}` : listing.image!} alt={listing.title} className="w-full h-full object-cover" />
                      </div>
                    ) : (
                      <div className="w-24 h-24 shrink-0 border border-steel-dark bg-[#e4ded3] flex items-center justify-center text-steel-line">
                        No img
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <h4 className="font-oswald text-lg uppercase truncate pr-4">{listing.title}</h4>
                        <span className="font-oswald font-bold">{formatPrice(listing.price, listing.currencyCode)}</span>
                      </div>
                      <p className="text-sm font-mono text-steel-line mt-1">
                        {categoryName(listing.category)} &middot; {listing.status} &middot; {daysLeft(listing.expiresAt)} days left
                      </p>
                      {listing.isPremium && listing.premiumExpiresAt && new Date(listing.premiumExpiresAt).getTime() > Date.now() && <span className="premium-badge mt-2"><Sparkles size={12} /> Premium</span>}
                      
                      <div className="mt-4 flex gap-3 flex-wrap">
                        <Link href={`/seller/listings/${listing.id}/edit`} className="text-xs font-bold uppercase tracking-wider flex items-center gap-1 hover:text-yellow transition-colors">
                          <Pencil size={12} /> Edit
                        </Link>
                        {(listing.status === 'active' || listing.status === 'sold') && (
                          <Link href={`/listings/${listing.id}?availability=${listing.status === 'sold' || listing.attributes?.availability === 'sold' ? 'sold' : listing.attributes?.availability === 'pending' ? 'pending' : 'available'}`} target="_blank" className="text-xs font-bold uppercase tracking-wider flex items-center gap-1 hover:text-yellow transition-colors">
                            <ArrowUpRight size={12} /> View public
                          </Link>
                        )}
                        {(listing.status === 'cancelled' || listing.status === 'expired') && (
                          <button onClick={() => handleRenew(listing.id)} className="text-xs font-bold uppercase tracking-wider flex items-center gap-1 hover:text-yellow transition-colors" disabled={renewListing.isPending}>
                            <RotateCw size={12} /> Reactivate
                          </button>
                        )}
                        {listing.status === 'active' && !listing.isPremium && (
                          <button onClick={() => handlePremium(listing.id)} className="text-xs font-bold uppercase tracking-wider flex items-center gap-1 text-teal hover:text-steel-dark transition-colors" disabled={premiumCheckout.isPending}>
                            <Sparkles size={12} /> Make Premium · $9.99
                          </button>
                        )}
                        {listing.status === 'active' ? (
                          <button onClick={() => handleCancel(listing.id)} className="text-xs font-bold uppercase tracking-wider flex items-center gap-1 text-oxide hover:text-[#8e3626] transition-colors ml-auto" disabled={cancelListing.isPending}>
                            <Archive size={12} /> Cancel Listing
                          </button>
                        ) : (
                          <button onClick={() => handleDelete(listing.id)} className="text-xs font-bold uppercase tracking-wider flex items-center gap-1 text-oxide hover:text-[#8e3626] transition-colors ml-auto" disabled={deleteListing.isPending}>
                            <Archive size={12} /> Delete
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div>
          <div className="seller-card">
            <h3>Recent Inquiries</h3>
            {inquiriesLoading ? (
              <div className="skeleton-stack">
                <div className="skeleton-row" style={{ minHeight: '80px' }} />
                <div className="skeleton-row" style={{ minHeight: '80px' }} />
              </div>
            ) : inquiriesError ? (
              <div className="py-8 text-center bg-paper text-oxide">
                <p className="font-mono text-sm mb-4">Could not load your messages.</p>
                <button type="button" onClick={() => void refetchInquiries()} className="button-secondary">Try again</button>
              </div>
            ) : !inquiries?.length ? (
              <div className="py-8 text-center bg-paper text-steel-line">
                <p className="font-mono text-sm">No messages yet.</p>
              </div>
            ) : (
              <div className="flex flex-col">
                {inquiries.map(inquiry => {
                  const targetListing = listings?.find(l => l.id === inquiry.listingId);
                  return (
                    <div key={inquiry.id} className="inquiry-item">
                      <div className="inquiry-meta">
                        <strong>{inquiry.name}</strong> ({inquiry.email})
                      </div>
                      <div className="inquiry-meta text-xs">
                        Re: {targetListing ? targetListing.title : 'Unknown Listing'} &middot; {formatDistanceToNow(new Date(inquiry.createdAt), { addSuffix: true })}
                      </div>
                      <p className="inquiry-message">{inquiry.message}</p>
                      <a href={`mailto:${inquiry.email}?subject=Re: ${targetListing?.title || 'Autoshop Source Inquiry'}`} className="text-xs font-bold uppercase tracking-wider flex items-center gap-1 mt-3 hover:text-yellow transition-colors inline-flex">
                        <ArrowUpRight size={12} /> Reply via Email
                      </a>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
