import { useListBannerCampaigns, useCancelBannerCampaign, getListBannerCampaignsQueryKey } from '@workspace/api-client-react';
import { format } from 'date-fns';
import { Link } from 'wouter';
import { Plus, XCircle, BarChart, ExternalLink, Image as ImageIcon } from 'lucide-react';

export default function AdvertiseDashboard() {
  const { data: campaigns, isLoading, isError, refetch } = useListBannerCampaigns({
    query: { queryKey: getListBannerCampaignsQueryKey() }
  });
  const cancelCampaign = useCancelBannerCampaign();

  const handleCancel = async (id: string) => {
    if (confirm('Are you sure you want to cancel this pending campaign?')) {
      await cancelCampaign.mutateAsync({ adId: id });
      refetch();
    }
  };

  const formatPrice = (minor: number, curr: string) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: curr }).format(minor / 100);

  return (
    <div className="flex flex-col min-h-[100dvh] bg-[var(--paper)]">
      <section className="bg-[var(--steel-dark)] py-8 border-b-4 border-[var(--yellow)]">
        <div className="content-shell flex justify-between items-end">
          <div>
            <h1 className="font-['Barlow_Condensed'] text-3xl text-white uppercase m-0">Ad Dashboard</h1>
            <p className="text-[var(--paper-dim)] mt-1">Manage your active and pending campaigns</p>
          </div>
          <Link href="/advertise" className="button-primary text-sm py-2 px-4">
            <Plus size={16} /> New Campaign
          </Link>
        </div>
      </section>

      <main className="content-shell py-10">
        {isLoading ? (
          <div className="p-10 text-center text-[var(--steel-line)]">Loading campaigns...</div>
        ) : isError ? (
          <div className="state-panel" role="alert" data-testid="status-campaigns-error">
            <h3>Sign in to view your campaigns</h3>
            <p>Your advertising dashboard is private to your account.</p>
            <Link href="/sign-in" className="button-primary">Sign in</Link>
          </div>
        ) : !campaigns || campaigns.length === 0 ? (
          <div className="bg-white border-2 dashed border-[var(--steel-line)] p-12 text-center">
            <BarChart size={48} className="mx-auto text-[var(--steel-line)] mb-4" />
            <h3 className="font-['Barlow_Condensed'] text-2xl uppercase mb-2">No campaigns yet</h3>
            <p className="text-[var(--steel-line)] mb-6">Promote your business directly to our audience.</p>
            <Link href="/advertise" className="button-primary">Create Your First Ad</Link>
          </div>
        ) : (
          <div className="grid gap-6">
            {campaigns.map(camp => {
              const ctr = camp.impressions > 0 ? ((camp.clicks / camp.impressions) * 100).toFixed(2) : '0.00';
              return (
                <div key={camp.id} className="bg-white border-2 border-[var(--steel-dark)] p-6 shadow-[4px_4px_0_rgba(24,39,53,0.1)] flex flex-col md:flex-row gap-6" data-testid={`card-campaign-${camp.id}`}>
                  
                  <div className="shrink-0 w-full md:w-[240px] bg-[#e4ded3] border border-[var(--steel-line)] relative flex items-center justify-center aspect-video overflow-hidden">
                    {camp.desktopImagePath ? (
                      <img src={`/api/storage${camp.desktopImagePath}`} alt="Creative" className="max-w-full max-h-full object-contain" />
                    ) : (
                      <ImageIcon className="text-[var(--steel-line)]" size={32} />
                    )}
                    <div className="absolute top-2 left-2 bg-[var(--steel-dark)] text-white text-xs px-2 py-1 font-bold uppercase">
                      {camp.status.replace('_', ' ')}
                    </div>
                  </div>

                  <div className="flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-['Barlow_Condensed'] text-2xl uppercase m-0 leading-none">{camp.locationName || 'Unknown Location'}</h3>
                        <a href={camp.destinationUrl} target="_blank" rel="noreferrer" className="text-[var(--teal)] text-sm font-['Space_Mono'] inline-flex items-center gap-1 hover:underline mt-1">
                          {camp.destinationUrl} <ExternalLink size={12} />
                        </a>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-lg">{formatPrice(camp.amountMinor, camp.currency)}</div>
                        <div className="text-xs text-[var(--steel-line)] font-bold uppercase">{camp.durationMonths} Month{camp.durationMonths > 1 ? 's' : ''}</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-[#fbf9f4] p-4 border border-[var(--steel-line)] mt-auto">
                      <div>
                        <div className="text-[10px] uppercase font-bold text-[var(--steel-line)] tracking-wider">Purchased / Start</div>
                        <div className="font-['Space_Mono'] text-sm">{camp.purchaseAt ? format(new Date(camp.purchaseAt), 'MMM d, yy') : '—'} / {camp.startAt ? format(new Date(camp.startAt), 'MMM d, yy') : '—'}</div>
                      </div>
                      <div>
                        <div className="text-[10px] uppercase font-bold text-[var(--steel-line)] tracking-wider">End</div>
                        <div className="font-['Space_Mono'] text-sm">{camp.endAt ? format(new Date(camp.endAt), 'MMM d, yy') : '—'}</div>
                      </div>
                      <div>
                        <div className="text-[10px] uppercase font-bold text-[var(--steel-line)] tracking-wider">Impressions</div>
                        <div className="font-['Space_Mono'] text-sm font-bold">{camp.impressions.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-[10px] uppercase font-bold text-[var(--steel-line)] tracking-wider">Clicks (CTR)</div>
                        <div className="font-['Space_Mono'] text-sm font-bold text-[var(--teal)]">{camp.clicks.toLocaleString()} ({ctr}%)</div>
                      </div>
                    </div>
                  </div>

                  {(camp.status === 'pending_payment' || camp.status === 'pending_approval') && (
                    <div className="flex flex-col justify-center border-l border-[var(--steel-line)] pl-6">
                      <button 
                        onClick={() => handleCancel(camp.id)}
                        className="text-[var(--oxide)] text-sm font-bold uppercase flex items-center gap-1 hover:underline"
                        data-testid={`button-cancel-campaign-${camp.id}`}
                      >
                        <XCircle size={16} /> Cancel
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
