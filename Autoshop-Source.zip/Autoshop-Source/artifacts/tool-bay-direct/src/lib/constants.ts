export const CATEGORIES = [
  { id: 'all', label: 'All equipment' },
  { id: 'vehicle-lifts', label: 'Vehicle Lifts / Hoists' },
  { id: 'tire-changers', label: 'Tire Changers' },
  { id: 'wheel-balancers', label: 'Wheel Balancers' },
  { id: 'wheel-alignment', label: 'Wheel Alignment Equipment' },
  { id: 'diagnostic-scanners', label: 'Diagnostic Scanners / Scan Tools' },
  { id: 'adas-calibration', label: 'ADAS Calibration Equipment' },
  { id: 'ac-service', label: 'A/C Service Machines' },
  { id: 'compressors', label: 'Compressors' },
  { id: 'air-shop-systems', label: 'Air Compressors / Shop Air Systems' },
  { id: 'tire-service', label: 'Tire Service Equipment' },
  { id: 'oil-fluid-service', label: 'Oil / Fluid Service Equipment' },
  { id: 'brake-service', label: 'Brake Service Equipment' },
  { id: 'engine-transmission', label: 'Engine / Transmission Equipment' },
  { id: 'body-shop', label: 'Body Shop Equipment' },
  { id: 'detailing', label: 'Detailing Equipment' },
  { id: 'vehicle-inspection', label: 'Vehicle Inspection / Testing Equipment' },
  { id: 'battery-ev', label: 'Battery / EV Equipment' },
  { id: 'battery-chargers', label: 'Battery Chargers / Boosters' },
  { id: 'shop-furniture', label: 'Shop Furniture & Workstations' },
  { id: 'shop-infrastructure', label: 'Shop Equipment / Infrastructure' },
  { id: 'parts-cleaning', label: 'Parts Cleaning / Cleaning Equipment' },
  { id: 'milling', label: 'Milling / Metalworking' },
  { id: 'motorcycle-shop', label: 'Motorcycle Shop Equipment' },
  { id: 'heavy-truck', label: 'Heavy Truck / Fleet Equipment' },
  { id: 'specialty', label: 'Specialty Equipment' },
  { id: 'shop-business-assets', label: 'Shop Business Assets' },
  { id: 'hoists', label: 'Hoists (Legacy)' },
  { id: 'welding', label: 'Welding' },
  { id: 'generators', label: 'Generators' },
  { id: 'hand-power', label: 'Hand & Power Tools' },
  { id: 'metalworking', label: 'Metalworking' },
  { id: 'diagnostics', label: 'Diagnostics (Legacy)' },
  { id: 'lifts-jacks', label: 'Lifts & Jacks' },
];

export const categoryName = (id: string) =>
  CATEGORIES.find((category) => category.id === id)?.label ?? id;

export const formatPrice = (price: number, currencyCode: string = 'CAD') =>
  new Intl.NumberFormat(currencyCode === 'USD' ? 'en-US' : 'en-CA', { style: 'currency', currency: currencyCode, maximumFractionDigits: 0 }).format(price);

export interface NormalizedPriceRange {
  min?: number;
  max?: number;
}

function normalizePriceBound(value: string | number | undefined): number | undefined {
  if (value === undefined || value === '') return undefined;
  const parsed = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(parsed)) return undefined;
  return Math.max(0, parsed);
}

/**
 * Inputs may be edited independently, so normalize only at the query
 * boundary. Values above the visual slider's convenience cap remain valid;
 * an empty upper bound means unbounded.
 */
export function normalizePriceRange(
  minValue: string | number | undefined,
  maxValue: string | number | undefined,
): NormalizedPriceRange {
  const min = normalizePriceBound(minValue);
  const max = normalizePriceBound(maxValue);
  if (min !== undefined && max !== undefined && min > max) {
    return { min: max, max: min };
  }
  return { min, max };
}

export const contactHref = (contact: string) =>
  contact.includes('@') ? `mailto:${contact}` : `tel:${contact.replace(/[^0-9+]/g, '')}`;
