export type FieldKind = 'select' | 'multi-select' | 'yes-no' | 'text' | 'number' | 'date';

export const SUPPORTED_FIELD_KINDS: FieldKind[] = ['select', 'multi-select', 'yes-no', 'text', 'number', 'date'];

export function assertFieldKindSupported(kind: FieldKind) {
  if (!SUPPORTED_FIELD_KINDS.includes(kind)) {
    throw new Error(`Unsupported field kind: ${kind}. Both seller (EquipmentSchemaFields) and buyer (SidebarFilters) UIs must implement it for parity.`);
  }
}

export interface FieldDefinition {
  key: string;
  label: string;
  kind: FieldKind;
  units?: string;
  options?: { label: string; value: string }[];
}

export const YES_NO_OPTIONS = [
  { label: 'Yes', value: 'true' },
  { label: 'No', value: 'false' },
] as const;

export function getFieldOptions(field: FieldDefinition): { label: string; value: string }[] {
  if (field.kind === 'yes-no') return YES_NO_OPTIONS.map(option => ({ ...option }));
  return field.options?.map(option => ({ ...option })) ?? [];
}

export interface EquipmentTypeDefinition {
  id: string;
  label: string;
}

export interface CategoryDefinition {
  id: string;
  label: string;
  types: EquipmentTypeDefinition[];
  fields: FieldDefinition[];
}

const option = (label: string, value = label.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')) => ({ label, value });
const select = (key: string, label: string, options: { label: string; value: string }[], units?: string): FieldDefinition => ({ key, label, kind: 'select', options, units });
const multi = (key: string, label: string, options: { label: string; value: string }[]): FieldDefinition => ({ key, label, kind: 'multi-select', options });
const text = (key: string, label: string, units?: string): FieldDefinition => ({ key, label, kind: 'text', units });
const number = (key: string, label: string, units?: string): FieldDefinition => ({ key, label, kind: 'number', units });
const yesNo = (key: string, label: string): FieldDefinition => ({ key, label, kind: 'yes-no' });
const date = (key: string, label: string): FieldDefinition => ({ key, label, kind: 'date' });
const types = (...items: [string, string][]): EquipmentTypeDefinition[] => items.map(([id, label]) => ({ id, label }));

const CONDITION_OPTIONS = [
  option('New', 'new'),
  option('Excellent', 'excellent'),
  option('Good', 'good'),
  option('Fair', 'fair'),
  option('Parts', 'parts'),
  // Keep these values: older listings already use them.
  option('Used', 'used'),
  option('Refurbished', 'refurbished'),
];

const POWER_OPTIONS = [option('120V', '120v'), option('208V', '208v'), option('240V', '240v'), option('480V', '480v'), option('Single-phase', 'single-phase'), option('3-phase', '3-phase')];
const MOUNT_OPTIONS = [option('Bench', 'bench'), option('Floor mounted', 'floor-mounted'), option('Mobile', 'mobile'), option('Wall mounted', 'wall-mounted'), option('In-ground', 'in-ground')];
const OPERATION_OPTIONS = [option('Automatic', 'automatic'), option('Semi-automatic', 'semi-automatic'), option('Manual', 'manual')];
const MATERIAL_OPTIONS = [option('Steel', 'steel'), option('Aluminum', 'aluminum'), option('Stainless steel', 'stainless-steel'), option('Plastic', 'plastic'), option('Wood', 'wood')];

/**
 * These fields are deliberately shared by every category. They form the
 * universal buyer master-list and the matching seller fields. Category
 * schemas below contain only fields that make sense for that equipment.
 */
export const COMMON_EQUIPMENT_FIELDS: FieldDefinition[] = [
  { key: 'manufacturer', label: 'Manufacturer / Brand', kind: 'text' },
  { key: 'model', label: 'Model / Model number', kind: 'text' },
  { key: 'year', label: 'Year', kind: 'number' },
  { key: 'warranty', label: 'Warranty', kind: 'yes-no' },
  { key: 'manualIncluded', label: 'Manual', kind: 'yes-no' },
  { key: 'serviceRecords', label: 'Service Records', kind: 'yes-no' },
  {
    key: 'installationStatus',
    label: 'Installation',
    kind: 'select',
    options: [option('Included', 'included'), option('Available', 'available'), option('No', 'no')],
  },
  { key: 'deliveryAvailable', label: 'Delivery', kind: 'yes-no' },
  { key: 'financingAvailable', label: 'Financing', kind: 'yes-no' },
  { key: 'makeOffer', label: 'Make Offer', kind: 'yes-no' },
  {
    key: 'sellerType',
    label: 'Seller Type',
    kind: 'select',
    options: [
      option('Automotive repair shop', 'automotive-repair-shop'),
      option('Dealership', 'dealership'),
      option('Body shop', 'body-shop'),
      option('Tire shop', 'tire-shop'),
      option('Fleet', 'fleet'),
      option('Heavy truck shop', 'heavy-truck-shop'),
      option('Auto recycler', 'auto-recycler'),
      option('Equipment dealer', 'equipment-dealer'),
      option('Manufacturer', 'manufacturer'),
      option('Auction company', 'auction-company'),
      option('Liquidator', 'liquidator'),
      option('Shop', 'shop'),
      option('Dealer', 'dealer'),
      option('Distributor', 'distributor'),
      option('Private', 'private'),
      option('Private seller', 'private-seller'),
    ],
  },
  {
    key: 'saleReason',
    label: 'Sale Reason',
    kind: 'multi-select',
    options: [
      option('Shop closing', 'shop-closing'),
      option('Retirement', 'retirement'),
      option('Relocation', 'relocation'),
      option('Downsizing', 'downsizing'),
      option('Upgrade', 'upgrade'),
      option('Surplus', 'surplus'),
      option('Business sale', 'business-sale'),
      option('Liquidation', 'liquidation'),
      option('Excess inventory', 'excess-inventory'),
      option('Estate', 'estate'),
      option('Bankruptcy / liquidation', 'bankruptcy-liquidation'),
      option('Other', 'other'),
    ],
  },
  {
    key: 'transactionType',
    label: 'Transaction Type',
    kind: 'multi-select',
    options: [
      option('Individual item', 'individual-item'),
      option('Multiple items', 'multiple-items'),
      option('Complete shop', 'complete-shop'),
      option('Shop package', 'shop-package'),
      option('Make offer', 'make-offer'),
      option('Auction', 'auction'),
      option('Fixed price', 'fixed-price'),
    ],
  },
  {
    key: 'availability',
    label: 'Availability',
    kind: 'select',
    options: [option('Available', 'available'), option('Pending', 'pending'), option('Sold', 'sold')],
  },
];

const VEHICLE_LIFT_FIELDS: FieldDefinition[] = [
  number('originalPrice', 'Original Purchase Price', '$'),
  select('liftingCapacity', 'Lifting Capacity', [option('7,000 lb', '7000'), option('9,000 lb', '9000'), option('10,000 lb', '10000'), option('12,000 lb', '12000'), option('15,000 lb', '15000'), option('18,000 lb', '18000'), option('20,000+ lb', '20000+')]),
  number('maxLiftHeight', 'Maximum Lift Height', 'in'),
  number('minPadHeight', 'Minimum Pad Height', 'in'),
  number('overallWidth', 'Overall Width', 'in'),
  number('overallLength', 'Overall Length', 'in'),
  number('driveThroughWidth', 'Drive-through Width', 'in'),
  select('armConfiguration', 'Arm Configuration', [option('Asymmetric', 'asymmetric'), option('Symmetric', 'symmetric')]),
  select('mountType', 'Mount / Install', MOUNT_OPTIONS),
  select('powerVoltage', 'Power', POWER_OPTIONS),
  yesNo('certified', 'Certified / Certification Available'),
  text('certificationBody', 'Certification Body'),
  date('installationDate', 'Installation Date'),
  text('serviceHistory', 'Service History'),
  yesNo('partsAvailable', 'Parts Available'),
  select('removal', 'Removal Required / Included', [option('Not required', 'not-required'), option('Required', 'required'), option('Included', 'included')]),
];

const TIRE_CHANGER_FIELDS: FieldDefinition[] = [
  select('operationType', 'Operation Type', [option('Automatic', 'automatic'), option('Semi-automatic', 'semi-automatic'), option('Leverless', 'leverless'), option('Tilt-back', 'tilt-back'), option('Heavy-duty', 'heavy-duty'), option('Truck / Bus', 'truck-bus'), option('Motorcycle', 'motorcycle')]),
  text('wheelDiameterRange', 'Wheel Diameter Range', 'in'),
  number('maxTireDiameter', 'Maximum Tire Diameter', 'in'),
  number('maxTireWidth', 'Maximum Tire Width', 'in'),
  text('rimWidthRange', 'Rim Width Range', 'in'),
  text('rimClampingRange', 'Rim Clamping Range', 'in'),
  yesNo('runFlatCapable', 'Run-flat Capable'),
  yesNo('tpmsCompatible', 'TPMS Compatible'),
  yesNo('centerLockCompatible', 'Center-lock Compatible'),
  yesNo('assistArm', 'Assist Arm'),
  number('beadBreakerCapacity', 'Bead Breaker Capacity', 'lb'),
  select('powerAir', 'Pneumatic / Electric', [option('Pneumatic', 'pneumatic'), option('Electric', 'electric'), option('Pneumatic & Electric', 'pneumatic-electric')]),
  text('voltage', 'Voltage'),
  text('phase', 'Phase (Single / 3-phase)'),
  text('airRequirement', 'Air Requirement', 'CFM'),
  text('serviceHistory', 'Service History'),
  text('accessories', 'Accessories Included'),
  yesNo('shippingAvailable', 'Shipping Available'),
];

const WHEEL_BALANCER_FIELDS: FieldDefinition[] = [
  number('maxWheelDiameter', 'Maximum Wheel Diameter', 'in'),
  number('maxWheelWidth', 'Maximum Wheel Width', 'in'),
  number('maxWheelWeight', 'Maximum Wheel Weight', 'lb'),
  number('shaftDiameter', 'Shaft Diameter', 'mm'),
  number('balancingAccuracy', 'Balancing Accuracy', 'g'),
  yesNo('roadForceCapability', 'Road-force Capability'),
  yesNo('automaticDataEntry', 'Automatic Data Entry'),
  yesNo('laserPositioning', 'Laser Positioning'),
  yesNo('touchscreen', 'Touchscreen'),
  yesNo('weightOptimization', 'Weight Optimization'),
  yesNo('hiddenWeightMode', 'Hidden-weight Mode'),
  yesNo('tpmsCompatibility', 'TPMS Compatibility'),
  select('power', 'Power', POWER_OPTIONS),
  text('voltage', 'Voltage'),
  text('serviceHistory', 'Service History'),
  text('accessories', 'Accessories'),
];

const ALIGNMENT_FIELDS: FieldDefinition[] = [
  select('alignmentDimension', '2D / 3D', [option('2D', '2d'), option('3D', '3d')]),
  select('sensorTechnology', 'CCD / Camera / Laser', [option('CCD / Camera', 'ccd-camera'), option('Laser', 'laser'), option('3D Camera', '3d-camera')]),
  number('numberOfCameras', 'Number of Cameras'),
  yesNo('alignmentRackIncluded', 'Alignment Rack Included'),
  text('rackManufacturer', 'Rack Manufacturer'),
  number('maxVehicleWeight', 'Maximum Vehicle Weight', 'lb'),
  number('maxWheelbase', 'Maximum Wheelbase', 'in'),
  text('alignmentRange', 'Alignment Range'),
  yesNo('automaticCompensation', 'Automatic Compensation'),
  yesNo('runOutCompensation', 'Run-out Compensation'),
  yesNo('databaseIncluded', 'Database Included'),
  text('softwareVersion', 'Software Version'),
  yesNo('softwareSubscriptionRequired', 'Software Subscription Required'),
  yesNo('computerIncluded', 'Computer Included'),
  yesNo('printerIncluded', 'Printer Included'),
  yesNo('targetsIncluded', 'Targets Included'),
  yesNo('clampsIncluded', 'Clamps Included'),
  select('calibrationStatus', 'Calibration Status', [option('Current', 'current'), option('Due', 'due'), option('Unknown', 'unknown')]),
  text('serviceHistory', 'Service History'),
  select('power', 'Power', POWER_OPTIONS),
];

const SCANNER_FIELDS: FieldDefinition[] = [
  multi('toolType', 'Tool Type', [option('Professional', 'professional'), option('OEM Scanner', 'oem'), option('Universal', 'universal'), option('ADAS', 'adas'), option('Key Programming', 'key-programming'), option('ECU Programming', 'ecu-programming'), option('EV Diagnostics', 'ev-diagnostics'), option('Battery Diagnostics', 'battery-diagnostics'), option('TPMS Tool', 'tpms')]),
  text('vehicleCoverage', 'Vehicle Coverage'),
  text('makesSupported', 'Makes Supported'),
  multi('protocols', 'Protocols', [option('OBD-II', 'obd-ii'), option('CAN', 'can'), option('DoIP', 'doip'), option('J2534', 'j2534')]),
  multi('capabilities', 'Capabilities', [option('ECU Programming', 'ecu-programming'), option('Coding', 'coding'), option('Key Programming', 'key-programming'), option('Immobilizer', 'immobilizer'), option('ADAS', 'adas'), option('EV / Hybrid', 'ev-hybrid'), option('Oscilloscope', 'oscilloscope'), option('Multimeter', 'multimeter'), option('Topology Mapping', 'topology-mapping'), option('Bidirectional Controls', 'bidirectional-controls')]),
  text('softwareVersion', 'Software Version'),
  text('subscriptionStatus', 'Subscription Status'),
  date('subscriptionExpiry', 'Subscription Expiry Date'),
  number('updateCost', 'Update Cost', '$'),
  select('hardwareFormat', 'Tablet / Handheld', [option('Tablet', 'tablet'), option('Handheld', 'handheld'), option('Dongle / VCI', 'dongle')]),
  yesNo('wifiBluetooth', 'Wi-Fi / Bluetooth'),
  yesNo('warranty', 'Warranty'),
  text('accessories', 'Accessories'),
];

const ADAS_FIELDS: FieldDefinition[] = [
  text('vehicleCoverage', 'Vehicle Coverage'),
  text('oemCoverage', 'OEM Coverage'),
  yesNo('cameraCalibration', 'Camera Calibration'),
  yesNo('radarCalibration', 'Radar Calibration'),
  yesNo('laneDeparture', 'Lane Departure'),
  yesNo('blindSpot', 'Blind Spot'),
  yesNo('camera360', '360° Camera'),
  yesNo('nightVision', 'Night Vision'),
  yesNo('lidar', 'Lidar'),
  yesNo('calibrationFrame', 'Calibration Frame'),
  text('targetsIncluded', 'Targets Included'),
  text('targetsByManufacturer', 'Targets by Manufacturer'),
  yesNo('diagnosticTabletIncluded', 'Diagnostic Tablet Included'),
  text('software', 'Software'),
  text('softwareSubscription', 'Software Subscription'),
  number('floorSpaceRequired', 'Floor Space Required', 'sq ft'),
  number('ceilingHeightRequired', 'Ceiling Height Required', 'ft'),
  text('calibrationAccuracy', 'Calibration Accuracy'),
];

const COMPRESSOR_FIELDS: FieldDefinition[] = [
  select('compressorType', 'Type', [option('Rotary Screw', 'rotary-screw'), option('Reciprocating', 'reciprocating'), option('Scroll', 'scroll'), option('Vertical', 'vertical'), option('Horizontal', 'horizontal'), option('Portable', 'portable')]),
  number('horsepower', 'Horsepower', 'HP'),
  number('cfm', 'CFM', 'CFM'),
  number('psi', 'PSI', 'PSI'),
  number('tankCapacity', 'Tank Capacity', 'gal'),
  select('voltage', 'Voltage', POWER_OPTIONS),
  select('phase', 'Phase', [option('Single-phase', 'single-phase'), option('3-phase', '3-phase')]),
  text('dutyCycle', 'Duty Cycle'),
  select('lubrication', 'Oil / Oil-free', [option('Oil', 'oil'), option('Oil-free', 'oil-free')]),
  yesNo('airDryerIncluded', 'Air Dryer Included'),
  number('compressorHours', 'Compressor Hours', 'hrs'),
  text('serviceHistory', 'Service History'),
  number('noiseLevel', 'Noise Level', 'dB'),
  number('dimensions', 'Dimensions', 'in'),
  number('weight', 'Weight', 'lb'),
];

const AIR_SYSTEM_FIELDS: FieldDefinition[] = [
  select('subCategory', 'System Component', [option('Air Dryer', 'air-dryer'), option('Air Receiver', 'air-receiver'), option('Filter', 'filter'), option('Regulator', 'regulator'), option('Air Treatment System', 'air-treatment'), option('Hose Reel', 'hose-reel'), option('Air Distribution System', 'air-distribution')]),
  number('capacity', 'Capacity', 'gal'),
  number('psi', 'PSI', 'PSI'),
  number('cfm', 'CFM', 'CFM'),
  text('pipeSize', 'Pipe Size'),
  number('age', 'Age', 'years'),
];

const TIRE_SERVICE_FIELDS: FieldDefinition[] = [
  select('serviceItem', 'Service Equipment', [option('Tire Inflation System', 'inflation-system'), option('Nitrogen Generator', 'nitrogen-generator'), option('Nitrogen Inflation Machine', 'nitrogen-machine'), option('Tire Inflation Cage', 'inflation-cage'), option('Bead Seating Equipment', 'bead-seating'), option('Tire Repair Machine', 'repair-machine'), option('Tire Spreader', 'tire-spreader'), option('Tire Storage Rack', 'storage-rack'), option('Tire Changer', 'tire-changer'), option('Wheel Balancer', 'wheel-balancer')]),
  number('capacity', 'Capacity', 'tires'),
  number('psi', 'PSI', 'PSI'),
  text('accessories', 'Accessories'),
];

const OIL_FLUID_FIELDS: FieldDefinition[] = [
  select('fluidEquipment', 'Equipment', [option('Oil Drainer', 'oil-drainer'), option('Oil Dispenser', 'oil-dispenser'), option('Fluid Extractor', 'fluid-extractor'), option('Transmission Fluid Machine', 'transmission-fluid'), option('Coolant Flush Machine', 'coolant-flush'), option('Brake Bleeding Machine', 'brake-bleeding'), option('Power Steering Flush Machine', 'power-steering'), option('Differential Fluid Equipment', 'differential-fluid'), option('A/C Service Machine', 'ac-service')]),
  select('fluidType', 'Fluid Type', [option('Engine oil', 'engine-oil'), option('Transmission fluid', 'transmission-fluid'), option('Coolant', 'coolant'), option('Brake fluid', 'brake-fluid'), option('Power steering fluid', 'power-steering-fluid'), option('A/C refrigerant', 'refrigerant')]),
  number('capacity', 'Capacity', 'gal'),
  select('operationMode', 'Automatic / Manual', OPERATION_OPTIONS),
  text('vehicleCompatibility', 'Vehicle Compatibility'),
  select('refrigerantType', 'A/C Refrigerant', [option('R134a', 'r134a'), option('R1234yf', 'r1234yf'), option('Dual refrigerant', 'dual')]),
  multi('recoveryFunctions', 'Recovery / Recycle / Recharge', [option('Recovery', 'recovery'), option('Recycle', 'recycle'), option('Recharge', 'recharge')]),
  number('vacuumPumpCapacity', 'Vacuum Pump Capacity', 'CFM'),
  number('refrigerantCapacity', 'Refrigerant Capacity', 'lb'),
  select('power', 'Power', POWER_OPTIONS),
];

const AC_FIELDS: FieldDefinition[] = [
  select('refrigerantType', 'Refrigerant', [option('R134a', 'r134a'), option('R1234yf', 'r1234yf'), option('Dual gas', 'dual')]),
  multi('functionality', 'Functions', [option('Recovery', 'recovery'), option('Recycling', 'recycling'), option('Recharge', 'recharge'), option('Automatic', 'automatic'), option('Semi-automatic', 'semi-automatic')]),
  number('refrigerantCapacity', 'Refrigerant Capacity', 'lb'),
  number('vacuumPumpCapacity', 'Vacuum Pump Capacity', 'CFM'),
  yesNo('oilInjection', 'Oil Injection'),
  yesNo('uvDye', 'UV Dye'),
  yesNo('printerIncluded', 'Printer'),
  yesNo('refrigerantScale', 'Refrigerant Scale'),
  text('softwareVersion', 'Software Version'),
  text('serviceHistory', 'Service History'),
];

const BRAKE_FIELDS: FieldDefinition[] = [
  select('brakeEquipment', 'Equipment', [option('Brake Lathe', 'brake-lathe'), option('Brake Bleeder', 'brake-bleeder'), option('Brake Flush Machine', 'brake-flush'), option('Brake Tester', 'brake-tester'), option('Disc Resurfacing', 'disc-resurfacing'), option('Drum Resurfacing', 'drum-resurfacing')]),
  text('vehicleType', 'Vehicle Type'),
  text('rotorDiameterRange', 'Rotor Diameter Range', 'in'),
  text('drumDiameterRange', 'Drum Diameter Range', 'in'),
  number('maximumThickness', 'Maximum Thickness', 'in'),
  select('operationMode', 'Automatic / Manual', OPERATION_OPTIONS),
  select('mountType', 'Bench / Floor Mounted', [option('Bench', 'bench'), option('Floor mounted', 'floor-mounted')]),
  select('power', 'Power', POWER_OPTIONS),
  text('accessories', 'Accessories'),
];

const ENGINE_FIELDS: FieldDefinition[] = [
  select('engineEquipment', 'Equipment', [option('Engine Hoist', 'engine-hoist'), option('Engine Stand', 'engine-stand'), option('Transmission Jack', 'transmission-jack'), option('Transmission Lift', 'transmission-lift'), option('Engine Crane', 'engine-crane'), option('Drivetrain Table', 'drivetrain-table'), option('Mobile Workstation', 'mobile-workstation')]),
  number('capacity', 'Capacity', 'ton'),
  number('maximumHeight', 'Maximum Height', 'in'),
  number('minimumHeight', 'Minimum Height', 'in'),
  number('reach', 'Reach', 'in'),
  select('driveType', 'Hydraulic / Electric / Manual', [option('Hydraulic', 'hydraulic'), option('Electric', 'electric'), option('Manual', 'manual')]),
  select('wheelConfiguration', 'Wheel Configuration', [option('2 wheel', '2-wheel'), option('4 wheel', '4-wheel'), option('6 wheel', '6-wheel')]),
];

const WELDING_FIELDS: FieldDefinition[] = [
  select('weldingProcess', 'MIG / TIG / Stick', [option('MIG', 'mig'), option('TIG', 'tig'), option('Stick', 'stick'), option('MIG / TIG', 'mig-tig'), option('Plasma', 'plasma'), option('Spot weld', 'spot')]),
  number('amperage', 'Amperage', 'A'),
  text('dutyCycle', 'Duty Cycle'),
  multi('materialCapability', 'Material Capability', MATERIAL_OPTIONS),
  select('phase', 'Phase', [option('Single-phase', 'single-phase'), option('3-phase', '3-phase')]),
  select('voltage', 'Voltage', POWER_OPTIONS),
  text('gasRequirements', 'Gas Requirements'),
  text('wireDiameter', 'Wire Diameter', 'mm'),
  text('accessories', 'Accessories'),
  number('hours', 'Hours', 'hrs'),
];

const BODY_SHOP_FIELDS: FieldDefinition[] = [
  number('dimensions', 'Dimensions', 'in'),
  number('vehicleCapacity', 'Vehicle Capacity', 'lb'),
  select('heated', 'Heated / Unheated', [option('Heated', 'heated'), option('Unheated', 'unheated')]),
  select('paintBoothType', 'Paint Booth Type', [option('Open face', 'open-face'), option('Crossdraft', 'crossdraft'), option('Downdraft', 'downdraft'), option('Side-draft', 'side-draft')]),
  number('airflowCfm', 'Airflow', 'CFM'),
  select('burnerType', 'Burner Type', [option('Gas', 'gas'), option('Electric', 'electric'), option('None', 'none')]),
  text('filterSystem', 'Filter System'),
  yesNo('explosionProofComponents', 'Explosion-proof Components'),
  text('complianceCertification', 'Compliance / Certification'),
  select('boothInstallationStatus', 'Installation Status', [option('Installed', 'installed'), option('Disassembled', 'disassembled'), option('Ready to install', 'ready-to-install')]),
  yesNo('disassemblyRequired', 'Disassembly Required'),
];

const DETAILING_FIELDS: FieldDefinition[] = [
  select('detailingEquipment', 'Equipment', [option('Steam Cleaner', 'steam-cleaner'), option('Extractor', 'extractor'), option('Pressure Washer', 'pressure-washer'), option('Polisher', 'polisher'), option('Vacuum', 'vacuum'), option('Ozone Generator', 'ozone-generator'), option('Carpet Cleaner', 'carpet-cleaner'), option('Detailing Cart', 'detailing-cart'), option('Water Reclaim System', 'water-reclaim')]),
  number('psi', 'PSI', 'PSI'),
  number('gpm', 'GPM', 'GPM'),
  number('tankCapacity', 'Tank Capacity', 'gal'),
  number('wattage', 'Wattage', 'W'),
  number('temperature', 'Temperature', '°F'),
  number('runtime', 'Runtime', 'hrs'),
  select('power', 'Power', POWER_OPTIONS),
  text('accessories', 'Accessories'),
];

const INSPECTION_FIELDS: FieldDefinition[] = [
  select('inspectionEquipment', 'Testing Equipment', [option('Brake Tester', 'brake-tester'), option('Suspension Tester', 'suspension-tester'), option('Headlight Tester', 'headlight-tester'), option('Emissions Equipment', 'emissions'), option('Exhaust Gas Analyzer', 'exhaust-analyzer'), option('Battery Tester', 'battery-tester'), option('Charging-system Tester', 'charging-system'), option('Dynamometer', 'dynamometer')]),
  text('vehicleCompatibility', 'Vehicle Compatibility'),
  number('capacity', 'Capacity'),
  text('testingRange', 'Testing Range'),
  text('accuracy', 'Accuracy'),
  text('certification', 'Certification'),
  text('software', 'Software'),
  date('calibrationDate', 'Calibration Date'),
];

const BATTERY_EV_FIELDS: FieldDefinition[] = [
  select('evType', 'EV / Hybrid', [option('EV', 'ev'), option('Hybrid', 'hybrid'), option('Both', 'both')]),
  number('voltageRating', 'Voltage Rating', 'V'),
  number('maximumVoltage', 'Maximum Voltage', 'V'),
  number('batteryCapacity', 'Battery Capacity', 'kWh'),
  number('maximumLoad', 'Maximum Load', 'lb'),
  text('vehicleCompatibility', 'Vehicle Compatibility'),
  number('chargingSpeed', 'Charging Speed', 'kW'),
  select('chargingCurrent', 'Charging Current', [option('AC', 'ac'), option('DC', 'dc'), option('AC / DC', 'ac-dc')]),
  select('connectorType', 'Connector Type', [option('J1772', 'j1772'), option('CCS', 'ccs'), option('CHAdeMO', 'chademo'), option('NACS / Tesla', 'nacs')]),
  text('software', 'Software'),
  text('warrantyDetails', 'Warranty'),
  text('certification', 'Certification'),
];

const BATTERY_CHARGER_FIELDS: FieldDefinition[] = [
  select('voltage', 'Voltage', [option('6V', '6v'), option('12V', '12v'), option('24V', '24v'), option('6V / 12V / 24V', 'multi-voltage')]),
  number('ampOutput', 'Amp Output', 'A'),
  multi('batteryType', 'Battery Type', [option('AGM', 'agm'), option('Lead acid', 'lead-acid'), option('Lithium', 'lithium')]),
  multi('chargingModes', 'Charging Modes', [option('Charge', 'charge'), option('Maintain', 'maintain'), option('Boost', 'boost'), option('Recondition', 'recondition')]),
  number('capacity', 'Capacity', 'Ah'),
];

const FURNITURE_FIELDS: FieldDefinition[] = [
  select('furnitureItem', 'Furniture Type', [option('Workbench', 'workbench'), option('Tool Cabinet', 'tool-cabinet'), option('Tool Box', 'tool-box'), option('Service Cart', 'service-cart'), option('Parts Cabinet', 'parts-cabinet'), option('Storage Rack', 'storage-rack'), option('Tire Rack', 'tire-rack'), option('Shelving', 'shelving'), option('Reception Furniture', 'reception'), option('Computer Station', 'computer-station')]),
  number('width', 'Width', 'in'),
  number('height', 'Height', 'in'),
  number('depth', 'Depth', 'in'),
  number('numberOfDrawers', 'Number of Drawers'),
  select('material', 'Material', MATERIAL_OPTIONS),
  number('weightCapacity', 'Weight Capacity', 'lb'),
  select('mobility', 'Mobile / Fixed', [option('Mobile', 'mobile'), option('Fixed', 'fixed')]),
  text('colour', 'Colour'),
];

const INFRASTRUCTURE_FIELDS: FieldDefinition[] = [
  select('infrastructureItem', 'Infrastructure Type', [option('Exhaust Extraction', 'exhaust-extraction'), option('Shop Fan', 'shop-fan'), option('Industrial Fan', 'industrial-fan'), option('Heater', 'heater'), option('HVAC', 'hvac'), option('Oil Tank', 'oil-tank'), option('Fluid Tank', 'fluid-tank'), option('Waste Oil Furnace', 'waste-oil-furnace'), option('Waste Oil Tank', 'waste-oil-tank'), option('Pressure Washer', 'pressure-washer'), option('Water Reclaim', 'water-reclaim'), option('Shop Lighting', 'lighting'), option('Security System', 'security'), option('Industrial Generator', 'generator'), option('Electrical Equipment', 'electrical')]),
  number('capacity', 'Capacity'),
  number('powerOutput', 'Power Output', 'kW'),
  text('dimensions', 'Dimensions'),
  text('installationRequirements', 'Installation Requirements'),
];

const CLEANING_FIELDS: FieldDefinition[] = [
  select('cleaningEquipment', 'Cleaning Equipment', [option('Parts Washer', 'parts-washer'), option('Ultrasonic Cleaner', 'ultrasonic'), option('Solvent Cleaning System', 'solvent'), option('Hot Water Pressure Washer', 'hot-water-pressure-washer'), option('Steam Cleaner', 'steam-cleaner'), option('Degreaser', 'degreaser')]),
  number('tankCapacity', 'Tank Capacity', 'gal'),
  select('cleaningMethod', 'Cleaning Method', [option('Solvent', 'solvent'), option('Ultrasonic', 'ultrasonic'), option('Hot water', 'hot-water'), option('Steam', 'steam'), option('Water-based', 'water-based')]),
  yesNo('heated', 'Heated'),
  number('temperature', 'Temperature', '°F'),
  number('pumpCapacity', 'Pump Capacity', 'GPM'),
  yesNo('solventCompatible', 'Solvent Compatible'),
  yesNo('waterBased', 'Water Based'),
];

const MILLING_FIELDS: FieldDefinition[] = [
  select('machineType', 'Machine Type', [option('Lathe', 'lathe'), option('Milling Machine', 'milling-machine'), option('Drill Press', 'drill-press'), option('Hydraulic Press', 'hydraulic-press'), option('Grinder', 'grinder'), option('Parts Washer', 'parts-washer'), option('Sandblasting Cabinet', 'sandblasting-cabinet'), option('Metal Cutting Equipment', 'metal-cutting'), option('Hydraulic Equipment', 'hydraulic')]),
  number('capacity', 'Capacity'),
  number('swing', 'Swing', 'in'),
  number('tableSize', 'Table Size', 'in'),
  number('motorPower', 'Motor Power', 'HP'),
  select('power', 'Power', POWER_OPTIONS),
];

const MOTORCYCLE_FIELDS: FieldDefinition[] = [
  select('motorcycleEquipment', 'Equipment', [option('Motorcycle Lift', 'motorcycle-lift'), option('Tire Changer', 'tire-changer'), option('Wheel Balancer', 'wheel-balancer'), option('Motorcycle Stand', 'motorcycle-stand'), option('Engine Stand', 'engine-stand'), option('Diagnostic Equipment', 'diagnostic'), option('Wheel Service Equipment', 'wheel-service')]),
  number('capacity', 'Capacity', 'lb'),
  number('maxWheelDiameter', 'Maximum Wheel Diameter', 'in'),
  text('vehicleCompatibility', 'Vehicle Compatibility'),
];

const HEAVY_TRUCK_FIELDS: FieldDefinition[] = [
  select('truckClass', 'Truck Class', [option('Class 1', 'class-1'), option('Class 2', 'class-2'), option('Class 3', 'class-3'), option('Class 4', 'class-4'), option('Class 5', 'class-5'), option('Class 6', 'class-6'), option('Class 7', 'class-7'), option('Class 8', 'class-8')]),
  number('maximumGvw', 'Maximum GVW', 'lb'),
  number('maximumWheelDiameter', 'Maximum Wheel Diameter', 'in'),
  number('maximumAxleWeight', 'Maximum Axle Weight', 'lb'),
  number('liftCapacity', 'Lift Capacity', 'lb'),
  number('vehicleLength', 'Vehicle Length', 'ft'),
  number('vehicleHeight', 'Vehicle Height', 'ft'),
];

const SPECIALTY_FIELDS: FieldDefinition[] = [
  select('specialtyEquipment', 'Specialty Equipment', [option('DPF Cleaner', 'dpf-cleaner'), option('Injector Cleaner', 'injector-cleaner'), option('Fuel System Cleaner', 'fuel-system-cleaner'), option('Carbon Cleaning Machine', 'carbon-cleaning'), option('Hydrogen Cleaning Machine', 'hydrogen-cleaning'), option('Decarbonization Equipment', 'decarbonization'), option('Smoke Leak Tester', 'smoke-leak'), option('Cooling System Tester', 'cooling-system'), option('Pressure Tester', 'pressure-tester'), option('Ultrasonic Equipment', 'ultrasonic'), option('Borescope', 'borescope'), option('Diagnostic Oscilloscope', 'oscilloscope'), option('ADAS Calibration', 'adas')]),
  number('capacity', 'Capacity'),
  text('vehicleCompatibility', 'Vehicle Compatibility'),
  text('accessories', 'Accessories'),
];

const SHOP_ASSET_FIELDS: FieldDefinition[] = [
  select('assetType', 'Asset Type', [option('Individual Item', 'individual-item'), option('Shop Liquidation', 'shop-liquidation'), option('Shop Package', 'shop-package')]),
  text('packageContents', 'Package Contents'),
  multi('closingReasons', 'Closing / Downsizing Reason', [option('Business closing', 'business-closing'), option('Downsizing', 'downsizing'), option('Relocating', 'relocating'), option('Upgrading', 'upgrading'), option('Excess inventory', 'excess-inventory'), option('Estate', 'estate'), option('Bankruptcy / liquidation', 'bankruptcy-liquidation'), option('Surplus equipment', 'surplus-equipment')]),
];

function category(id: string, label: string, categoryTypes: EquipmentTypeDefinition[], fields: FieldDefinition[]): CategoryDefinition {
  return { id, label, types: categoryTypes, fields };
}

export const EQUIPMENT_SCHEMAS: CategoryDefinition[] = [
  category('vehicle-lifts', 'Vehicle Lifts / Hoists', types(
    ['2-post', '2-Post Lift'], ['4-post', '4-Post Lift'], ['scissor', 'Scissor Lift'], ['low-rise', 'Low-Rise Lift'], ['mid-rise', 'Mid-Rise Lift'], ['in-ground', 'In-Ground Lift'], ['mobile-column', 'Mobile Column Lift'], ['alignment', 'Alignment Lift'], ['motorcycle', 'Motorcycle Lift'], ['heavy-duty-truck', 'Heavy-Duty Truck Lift'], ['portable', 'Portable Lift'],
  ), VEHICLE_LIFT_FIELDS),
  category('tire-changers', 'Tire Changers', types(
    ['automatic', 'Automatic'], ['semi-automatic', 'Semi-automatic'], ['swing-arm', 'Swing Arm'], ['leverless', 'Leverless'], ['tilt-back', 'Tilt-back'], ['heavy-duty', 'Heavy-duty'], ['truck-bus', 'Truck / Bus'], ['motorcycle', 'Motorcycle'], ['run-flat', 'Run-flat Capable'],
  ), TIRE_CHANGER_FIELDS),
  category('wheel-balancers', 'Wheel Balancers', types(
    ['standard', 'Standard Balancer'], ['high-speed', 'High-speed Balancer'], ['truck', 'Truck Balancer'], ['motorcycle', 'Motorcycle Balancer'], ['diagnostic', 'Diagnostic Balancer'], ['road-force', 'Road-force Balancer'],
  ), WHEEL_BALANCER_FIELDS),
  category('wheel-alignment', 'Wheel Alignment Equipment', types(
    ['2-wheel', '2-wheel Alignment'], ['4-wheel', '4-wheel Alignment'], ['3d', '3D Alignment'], ['ccd', 'CCD Alignment'], ['laser', 'Laser Alignment'], ['mobile', 'Mobile Alignment System'],
  ), ALIGNMENT_FIELDS),
  category('diagnostic-scanners', 'Diagnostic Scanners / Scan Tools', types(
    ['professional', 'Professional Scan Tool'], ['oem', 'OEM Scanner'], ['universal', 'Universal Scanner'], ['adas', 'ADAS Scanner'], ['key-programming', 'Key Programming'], ['ecu-programming', 'ECU Programming'], ['ev-diagnostics', 'EV Diagnostics'], ['battery-diagnostics', 'Battery Diagnostics'], ['tpms', 'TPMS Tool'], ['handheld', 'Handheld Scanner'], ['tablet', 'Tablet Scanner'], ['pc-based', 'PC-Based Interface'], ['heavy-duty', 'Heavy Duty Scanner'],
  ), SCANNER_FIELDS),
  category('adas-calibration', 'ADAS Calibration Equipment', types(
    ['static', 'Static Calibration'], ['dynamic', 'Dynamic Calibration'], ['radar', 'Radar Calibration'], ['camera', 'Camera Calibration'], ['lidar', 'Lidar Calibration'], ['multi-brand', 'Multi-brand System'],
  ), ADAS_FIELDS),
  category('compressors', 'Compressors', types(
    ['rotary-screw', 'Rotary Screw'], ['reciprocating', 'Reciprocating'], ['scroll', 'Scroll'], ['vertical', 'Vertical'], ['horizontal', 'Horizontal'], ['portable', 'Portable'],
  ), COMPRESSOR_FIELDS),
  category('air-shop-systems', 'Air Compressors / Shop Air Systems', types(
    ['air-dryer', 'Air Dryer'], ['air-receiver', 'Air Receiver'], ['filter', 'Filter'], ['regulator', 'Regulator'], ['air-treatment', 'Air Treatment System'], ['hose-reel', 'Hose Reel'], ['air-distribution', 'Air Distribution System'],
  ), AIR_SYSTEM_FIELDS),
  category('tire-service', 'Tire Service Equipment', types(
    ['inflation-system', 'Tire Inflation System'], ['nitrogen-generator', 'Nitrogen Generator'], ['nitrogen-machine', 'Nitrogen Inflation Machine'], ['inflation-cage', 'Tire Inflation Cage'], ['bead-seating', 'Bead Seating Equipment'], ['repair-machine', 'Tire Repair Machine'], ['tire-spreader', 'Tire Spreader'], ['storage-rack', 'Tire Storage Rack'], ['tire-changer', 'Tire Changer'], ['wheel-balancer', 'Wheel Balancer'],
  ), TIRE_SERVICE_FIELDS),
  category('oil-fluid-service', 'Oil / Fluid Service Equipment', types(
    ['oil-drainer', 'Oil Drainer'], ['oil-dispenser', 'Oil Dispenser'], ['fluid-extractor', 'Fluid Extractor'], ['transmission-fluid', 'Transmission Fluid Machine'], ['coolant-flush', 'Coolant Flush Machine'], ['brake-bleeding', 'Brake Bleeding Machine'], ['power-steering', 'Power Steering Flush Machine'], ['differential-fluid', 'Differential Fluid Equipment'], ['ac-service', 'A/C Service Machine'],
  ), OIL_FLUID_FIELDS),
  category('ac-service', 'A/C Service Machines', types(
    ['r134a', 'R134a Machine'], ['r1234yf', 'R1234yf Machine'], ['dual-gas', 'Dual Gas Machine'],
  ), AC_FIELDS),
  category('brake-service', 'Brake Service Equipment', types(
    ['brake-lathe', 'Brake Lathe'], ['brake-bleeder', 'Brake Bleeder'], ['brake-flush', 'Brake Flush Machine'], ['brake-tester', 'Brake Tester'], ['disc-resurfacing', 'Disc Resurfacing'], ['drum-resurfacing', 'Drum Resurfacing'],
  ), BRAKE_FIELDS),
  category('engine-transmission', 'Engine / Transmission Equipment', types(
    ['engine-hoist', 'Engine Hoist'], ['engine-stand', 'Engine Stand'], ['transmission-jack', 'Transmission Jack'], ['transmission-lift', 'Transmission Lift'], ['engine-crane', 'Engine Crane'], ['drivetrain-table', 'Drivetrain Table'], ['mobile-workstation', 'Mobile Workstation'],
  ), ENGINE_FIELDS),
  category('welding', 'Welding / Fabrication Equipment', types(
    ['mig', 'MIG Welder'], ['tig', 'TIG Welder'], ['plasma', 'Plasma Cutter'], ['stick', 'Stick Welder'], ['spot', 'Spot Welder'], ['frame', 'Frame Welder'], ['welding-table', 'Welding Table'], ['fume-extractor', 'Welding Fume Extractor'],
  ), WELDING_FIELDS),
  category('body-shop', 'Body Shop Equipment', types(
    ['frame-machine', 'Frame Machine'], ['frame-straightening', 'Frame Straightening System'], ['paint-booth', 'Paint Booth'], ['prep-station', 'Prep Station'], ['paint-mixing', 'Paint Mixing System'], ['dent-repair', 'Dent Repair Equipment'], ['spot-welder', 'Spot Welder'], ['aluminum-repair', 'Aluminum Repair System'], ['plastic-repair', 'Plastic Repair System'], ['dust-extraction', 'Dust Extraction'], ['sanding', 'Sanding System'], ['paint-booth-filters', 'Paint Booth Filters'],
  ), BODY_SHOP_FIELDS),
  category('detailing', 'Detailing Equipment', types(
    ['steam-cleaner', 'Steam Cleaner'], ['extractor', 'Extractor'], ['pressure-washer', 'Pressure Washer'], ['polisher', 'Polisher'], ['vacuum', 'Vacuum'], ['ozone-generator', 'Ozone Generator'], ['carpet-cleaner', 'Carpet Cleaner'], ['detailing-cart', 'Detailing Cart'], ['water-reclaim', 'Water Reclaim System'],
  ), DETAILING_FIELDS),
  category('vehicle-inspection', 'Vehicle Inspection / Testing Equipment', types(
    ['brake-tester', 'Brake Tester'], ['suspension-tester', 'Suspension Tester'], ['headlight-tester', 'Headlight Tester'], ['emissions', 'Emissions Equipment'], ['exhaust-analyzer', 'Exhaust Gas Analyzer'], ['battery-tester', 'Battery Tester'], ['charging-system', 'Charging-system Tester'], ['dynamometer', 'Dynamometer'],
  ), INSPECTION_FIELDS),
  category('battery-ev', 'Battery / EV Equipment', types(
    ['battery-lift', 'EV Battery Lift'], ['battery-testing', 'Battery Testing Equipment'], ['insulation-tester', 'EV Insulation Tester'], ['hv-diagnostic', 'High-voltage Diagnostic Equipment'], ['charger', 'Battery Charger'], ['charging-station', 'EV Charging Station'], ['battery-storage', 'Battery Storage Equipment'], ['hv-safety', 'HV Safety Equipment'], ['service-table', 'EV Service Table'],
  ), BATTERY_EV_FIELDS),
  category('battery-chargers', 'Battery Chargers / Boosters', types(
    ['charger', 'Battery Charger'], ['maintainer', 'Battery Maintainer'], ['jump-starter', 'Jump Starter'], ['analyzer', 'Battery Analyzer'], ['booster', 'Booster Pack'],
  ), BATTERY_CHARGER_FIELDS),
  category('shop-furniture', 'Shop Furniture & Workstations', types(
    ['workbench', 'Workbench'], ['tool-cabinet', 'Tool Cabinet'], ['tool-box', 'Tool Box'], ['service-cart', 'Service Cart'], ['parts-cabinet', 'Parts Cabinet'], ['storage-rack', 'Storage Rack'], ['tire-rack', 'Tire Rack'], ['shelving', 'Shelving'], ['reception', 'Reception Furniture'], ['computer-station', 'Computer Station'],
  ), FURNITURE_FIELDS),
  category('shop-infrastructure', 'Shop Equipment / Infrastructure', types(
    ['exhaust-extraction', 'Vehicle Exhaust Extraction'], ['shop-fan', 'Shop Fan'], ['industrial-fan', 'Industrial Fan'], ['heater', 'Heater'], ['hvac', 'HVAC'], ['oil-tank', 'Oil Tank'], ['fluid-tank', 'Fluid Tank'], ['waste-oil-furnace', 'Waste Oil Furnace'], ['waste-oil-tank', 'Waste Oil Tank'], ['pressure-washer', 'Pressure Washer'], ['water-reclaim', 'Water Reclaim System'], ['lighting', 'Shop Lighting'], ['security', 'Security System'], ['generator', 'Industrial Generator'], ['electrical', 'Electrical Equipment'],
  ), INFRASTRUCTURE_FIELDS),
  category('parts-cleaning', 'Parts Cleaning / Cleaning Equipment', types(
    ['parts-washer', 'Parts Washer'], ['ultrasonic', 'Ultrasonic Cleaner'], ['solvent', 'Solvent Cleaning System'], ['hot-water-pressure-washer', 'Hot Water Pressure Washer'], ['steam-cleaner', 'Steam Cleaner'], ['degreaser', 'Degreaser'],
  ), CLEANING_FIELDS),
  // Keep the established metalworking identifier while exposing the guide's
  // "milling" taxonomy in its label and equipment types.
  category('metalworking', 'Milling / Metalworking', types(
    ['lathe', 'Lathe'], ['milling-machine', 'Milling Machine'], ['drill-press', 'Drill Press'], ['hydraulic-press', 'Hydraulic Press'], ['grinder', 'Grinder'], ['parts-washer', 'Parts Washer'], ['sandblasting-cabinet', 'Sandblasting Cabinet'], ['metal-cutting', 'Metal Cutting Equipment'], ['hydraulic', 'Hydraulic Equipment'],
  ), MILLING_FIELDS),
  category('milling', 'Milling / Metalworking', types(
    ['lathe', 'Lathe'], ['milling-machine', 'Milling Machine'], ['drill-press', 'Drill Press'], ['hydraulic-press', 'Hydraulic Press'], ['grinder', 'Grinder'], ['parts-washer', 'Parts Washer'], ['sandblasting-cabinet', 'Sandblasting Cabinet'], ['metal-cutting', 'Metal Cutting Equipment'], ['hydraulic', 'Hydraulic Equipment'],
  ), MILLING_FIELDS),
  category('motorcycle-shop', 'Motorcycle Shop Equipment', types(
    ['motorcycle-lift', 'Motorcycle Lift'], ['tire-changer', 'Tire Changer'], ['wheel-balancer', 'Wheel Balancer'], ['motorcycle-stand', 'Motorcycle Stand'], ['engine-stand', 'Engine Stand'], ['diagnostic', 'Diagnostic Equipment'], ['wheel-service', 'Wheel Service Equipment'],
  ), MOTORCYCLE_FIELDS),
  category('heavy-truck', 'Heavy Truck / Fleet Equipment', types(
    ['heavy-duty-lift', 'Heavy-duty Lift'], ['mobile-column', 'Mobile Columns'], ['truck-tire-changer', 'Truck Tire Changer'], ['truck-wheel-balancer', 'Truck Wheel Balancer'], ['truck-alignment', 'Truck Alignment System'], ['diesel-diagnostic', 'Diesel Diagnostic Equipment'], ['dpf-cleaning', 'DPF Cleaning Equipment'], ['brake-tester', 'Brake Tester'], ['engine-equipment', 'Engine Equipment'], ['transmission-equipment', 'Transmission Equipment'],
  ), HEAVY_TRUCK_FIELDS),
  category('specialty', 'Specialty Equipment', types(
    ['dpf-cleaner', 'DPF Cleaner'], ['injector-cleaner', 'Injector Cleaner'], ['fuel-system-cleaner', 'Fuel System Cleaner'], ['carbon-cleaning', 'Carbon Cleaning Machine'], ['hydrogen-cleaning', 'Hydrogen Cleaning Machine'], ['decarbonization', 'Decarbonization Equipment'], ['smoke-leak', 'Smoke Leak Tester'], ['cooling-system', 'Cooling System Tester'], ['pressure-tester', 'Pressure Tester'], ['ultrasonic', 'Ultrasonic Equipment'], ['borescope', 'Borescope'], ['oscilloscope', 'Diagnostic Oscilloscope'], ['adas', 'ADAS Calibration Equipment'],
  ), SPECIALTY_FIELDS),
  category('shop-business-assets', 'Shop Business Assets', types(
    ['individual-item', 'Individual Item'], ['shop-liquidation', 'Shop Liquidation'], ['shop-package', 'Shop Package'],
  ), SHOP_ASSET_FIELDS),
  // Existing categories not replaced by the guide retain their identifiers
  // and still receive sensible type-aware filters.
  category('hoists', 'Hoists (Legacy)', types(['engine-hoist', 'Engine Hoist'], ['shop-hoist', 'Shop Hoist']), ENGINE_FIELDS),
  category('generators', 'Generators', types(['portable', 'Portable Generator'], ['industrial', 'Industrial Generator']), [number('powerOutput', 'Power Output', 'kW'), number('runtime', 'Runtime', 'hrs'), select('voltage', 'Voltage', POWER_OPTIONS), select('phase', 'Phase', [option('Single-phase', 'single-phase'), option('3-phase', '3-phase')]), text('serviceHistory', 'Service History')]),
  category('hand-power', 'Hand & Power Tools', types(['hand-tools', 'Hand Tools'], ['power-tools', 'Power Tools']), [select('toolType', 'Tool Type', [option('Hand Tool', 'hand-tool'), option('Power Tool', 'power-tool')]), number('power', 'Power'), text('accessories', 'Accessories')]),
  category('diagnostics', 'Diagnostics (Legacy)', types(['general', 'General Diagnostic Equipment'], ['electrical', 'Electrical Tester']), SCANNER_FIELDS),
  category('lifts-jacks', 'Lifts & Jacks', types(['floor-jack', 'Floor Jack'], ['jack-stand', 'Jack Stand'], ['transmission-jack', 'Transmission Jack']), [number('capacity', 'Capacity', 'ton'), number('maximumHeight', 'Maximum Height', 'in'), select('mountType', 'Mount Type', MOUNT_OPTIONS)]),
];

export function getCategorySchema(categoryId: string | undefined): CategoryDefinition | undefined {
  if (!categoryId) return undefined;
  return EQUIPMENT_SCHEMAS.find(c => c.id === categoryId);
}

/** Shared fields are used by seller forms; buyer dynamic panels render only
 * category-specific fields plus the universal master list separately. */
export function getCategoryFields(categoryId: string | undefined): FieldDefinition[] {
  const schema = getCategorySchema(categoryId);
  if (!schema) return [...COMMON_EQUIPMENT_FIELDS];
  const fields = [...COMMON_EQUIPMENT_FIELDS, ...schema.fields];
  return fields.filter((field, index) => fields.findIndex(candidate => candidate.key === field.key) === index);
}

export function getCategorySpecificFields(categoryId: string | undefined): FieldDefinition[] {
  const schema = getCategorySchema(categoryId);
  if (!schema) return [];
  const commonKeys = new Set(COMMON_EQUIPMENT_FIELDS.map(field => field.key));
  return schema.fields.filter(field => !commonKeys.has(field.key));
}

export function getEquipmentType(categoryId: string, typeId: string): EquipmentTypeDefinition | undefined {
  return getCategorySchema(categoryId)?.types.find(t => t.id === typeId);
}