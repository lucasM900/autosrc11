export const validateAndReadImage = (
  file: File,
  expectedWidth: number,
  expectedHeight: number,
  maxBytes?: number
): Promise<{ width: number; height: number }> => {
  if (maxBytes && file.size > maxBytes) {
    return Promise.reject(
      new Error(`File exceeds maximum size of ${Math.round(maxBytes / 1024 / 1024)}MB`)
    );
  }

  const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  if (!validTypes.includes(file.type)) {
    return Promise.reject(new Error('Only JPG, PNG, and WebP are allowed'));
  }

  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();

    img.onload = () => {
      URL.revokeObjectURL(url);
      if (img.width !== expectedWidth || img.height !== expectedHeight) {
        reject(
          new Error(
            `Dimensions must be exactly ${expectedWidth}x${expectedHeight}px. Got ${img.width}x${img.height}px.`
          )
        );
      } else {
        resolve({ width: img.width, height: img.height });
      }
    };

    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Invalid image file'));
    };

    img.src = url;
  });
};
