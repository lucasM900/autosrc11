import { recordWebsiteAnalyticsEvent } from '@workspace/api-client-react';

type AnalyticsEventType = 'page_view' | 'login' | 'signup';

declare global {
  interface Window {
    umami?: {
      track(name: string, data?: Record<string, string | number | boolean>): void;
    };
  }
}

function persistentId(storage: Storage, key: string): string {
  const existing = storage.getItem(key);
  if (existing) return existing;
  const id = crypto.randomUUID();
  storage.setItem(key, id);
  return id;
}

export function trackWebsiteEvent(eventType: AnalyticsEventType, path: string): void {
  try {
    const visitorId = persistentId(localStorage, 'autoshop_visitor_id');
    const sessionId = persistentId(sessionStorage, 'autoshop_session_id');
    let referrerHost: string | undefined;
    try {
      referrerHost = document.referrer ? new URL(document.referrer).hostname : undefined;
    } catch {
      referrerHost = undefined;
    }

    void recordWebsiteAnalyticsEvent({
      eventId: crypto.randomUUID(),
      visitorId,
      sessionId,
      eventType,
      path,
      referrerHost,
    }).catch(() => undefined);

    window.umami?.track(eventType, { path });
  } catch {
    // Analytics must never interrupt the app.
  }
}