import { getRegisteredBrands } from '@workspace/api-zod';

type ModelsByType = Record<string, string[]>;
interface ManufacturerCatalog {
  manufacturer: string;
  modelsByType: ModelsByType;
}

type EquipmentCatalog = Record<string, ManufacturerCatalog[]>;

export const EQUIPMENT_CATALOG: EquipmentCatalog = {
  'vehicle-lifts': [
    {
      manufacturer: 'Rotary Lift',
      modelsByType: {
        '2-post': ['SPOA10', 'SPO12', 'SPO20'],
        '4-post': ['SM14', 'SM18', 'AR18'],
        scissor: ['XA12', 'RLP77', 'VLXS10'],
        'low-rise': ['M50'],
        'mid-rise': ['M70'],
        'in-ground': ['MOD30', 'MOD35', 'Flex MAX'],
        'mobile-column': ['MCHW18', 'MCH418'],
        alignment: ['AR18', 'SM18'],
        'heavy-duty-truck': ['SPO20', 'MOD35', 'MCHW18'],
      },
    },
    {
      manufacturer: 'BendPak',
      modelsByType: {
        '2-post': ['XPR-9S', 'XPR-10S', 'XPR-12FDL', 'XPR-18CL'],
        '4-post': ['HD-9', 'HD-14T', 'HDS-18E', 'HDS-40X'],
        scissor: ['SP-7XE', 'SP-7XLF', 'MDS-6LP'],
        'low-rise': ['LR-60', 'LR-10000'],
        'mid-rise': ['MD-6XP', 'MDS-6LP'],
        alignment: ['HDS-14LSX', 'HDS-18EA'],
        motorcycle: ['MDS-6LP'],
        'heavy-duty-truck': ['XPR-18CL', 'HDS-40X'],
        portable: ['QuickJack 5000TL', 'QuickJack 7000TL', 'QuickJack 7000TLX'],
      },
    },
    {
      manufacturer: 'Challenger Lifts',
      modelsByType: {
        '2-post': ['CL10', 'CL12', 'LE10', 'SA10'],
        '4-post': ['4015', '44018', '44030'],
        scissor: ['DX77', 'DX12'],
        'low-rise': ['MR6'],
        'mid-rise': ['MR6'],
        'in-ground': ['EV1020', 'E12'],
        'mobile-column': ['CLHM-190', 'CLHM-140'],
        alignment: ['44018AR', '44030AR'],
        'heavy-duty-truck': ['CL20', '44030', 'CLHM-190'],
      },
    },
    {
      manufacturer: 'Mohawk Lifts',
      modelsByType: {
        '2-post': ['A-7', 'System I', 'TP-20', 'TP-26'],
        '4-post': ['TR-19', 'TR-35', 'TR-50', 'TR-75'],
        'in-ground': ['TR-25IG', 'MP-18'],
        'mobile-column': ['MP-18', 'MP-24'],
        alignment: ['TR-19A', 'TR-35A'],
        'heavy-duty-truck': ['TP-20', 'TP-26', 'TR-50', 'TR-75'],
      },
    },
    {
      manufacturer: 'Stertil-Koni',
      modelsByType: {
        '2-post': ['FreedomLift SK 2055', 'FreedomLift SK 2070'],
        '4-post': ['ST 4120', 'ST 4175', 'ST 4600'],
        scissor: ['ECOLIFT'],
        'in-ground': ['DIAMONDLIFT', 'ECOLIFT'],
        'mobile-column': ['ST 1075', 'ST 1085', 'ST 1130'],
        'heavy-duty-truck': ['ST 1130', 'SKYLIFT', 'DIAMONDLIFT'],
      },
    },
    {
      manufacturer: 'Hunter Engineering',
      modelsByType: {
        scissor: ['RX10', 'RX12'],
        alignment: ['RX10', 'RX12', 'RX14', 'RX72'],
      },
    },
    {
      manufacturer: 'Handy Industries',
      modelsByType: {
        motorcycle: ['S.A.M. 1200', 'B.O.B. 1500', 'Standard 1000'],
      },
    },
    {
      manufacturer: 'Titan Lifts',
      modelsByType: {
        motorcycle: ['SDML-1000D', 'MLJ-1000B', '1500XLT'],
        portable: ['SL-6600', 'MRL-6000'],
      },
    },
  ],
  'tire-changers': [
    {
      manufacturer: 'Hunter Engineering',
      modelsByType: {
        'swing-arm': ['TCX51', 'TCX53', 'TCX56'],
        'tilt-back': ['TCX57', 'TCX58'],
        leverless: ['TCX59', 'Revolution WalkAway'],
        'heavy-duty': ['TCX625', 'TCX635HD'],
        motorcycle: ['TCX51M', 'TCX53M'],
      },
    },
    {
      manufacturer: 'Corghi',
      modelsByType: {
        'swing-arm': ['MTS830', 'SP122'],
        'tilt-back': ['MTS430', 'A9824TI'],
        leverless: ['AM50', 'Artiglio Master Jolly'],
        'heavy-duty': ['HD1400', 'HD1300'],
        motorcycle: ['A9212'],
      },
    },
    {
      manufacturer: 'Coats',
      modelsByType: {
        'swing-arm': ['RC-5A', 'APX90'],
        'tilt-back': ['70X', '80C'],
        leverless: ['Maxx 90', 'Maxx 80'],
        'heavy-duty': ['CHD-9041', 'CHD-9551'],
        motorcycle: ['RC-15A'],
      },
    },
    {
      manufacturer: 'Ranger',
      modelsByType: {
        'swing-arm': ['R745', 'R980AT'],
        'tilt-back': ['R76LT', 'R26FLT'],
        leverless: ['R80EX', 'R980XR'],
        'heavy-duty': ['R26FLT', 'R560'],
        motorcycle: ['R745'],
      },
    },
  ],
  'diagnostic-scanners': [
    {
      manufacturer: 'Autel',
      modelsByType: {
        handheld: ['AutoLink AL619', 'MaxiCheck MX900', 'MaxiDiag MD906 Pro'],
        tablet: ['MaxiSys MS906 Pro', 'MaxiSys Ultra', 'MaxiSys Elite II Pro'],
        'pc-based': ['MaxiFlash VCI', 'MaxiFlash XLink'],
        'heavy-duty': ['MaxiSys MS909CV', 'MaxiSYS CV'],
      },
    },
    {
      manufacturer: 'LAUNCH',
      modelsByType: {
        handheld: ['CRP919X', 'CRP129X', 'Creader Elite'],
        tablet: ['X-431 V', 'X-431 PAD V', 'X-431 PRO5'],
        'pc-based': ['X-431 SmartLink C', 'X-431 HD III'],
        'heavy-duty': ['X-431 PAD V Elite HD', 'X-431 V+ HD III'],
      },
    },
    {
      manufacturer: 'Snap-on',
      modelsByType: {
        handheld: ['SOLUS+', 'TRITON-D10'],
        tablet: ['ZEUS+', 'VERUS Edge'],
      },
    },
    {
      manufacturer: 'Bosch',
      modelsByType: {
        handheld: ['HDS 250', 'ADS 325'],
        tablet: ['ADS 625X', 'ADS 625'],
        'pc-based': ['ESI[tronic] Evolution', 'M-VCI'],
        'heavy-duty': ['HDS 250', 'KTS Truck'],
      },
    },
    {
      manufacturer: 'Jaltest',
      modelsByType: {
        'pc-based': ['Jaltest Link V9'],
        'heavy-duty': ['Jaltest CV', 'Jaltest OHW', 'Jaltest AGV'],
      },
    },
    {
      manufacturer: 'TEXA',
      modelsByType: {
        tablet: ['AXONE Voice', 'AXONE Nemo Plus'],
        'pc-based': ['NAVIGATOR TXT MULTIHUB 2', 'NAVIGATOR NANO S 2'],
        'heavy-duty': ['TXT MULTIHUB Truck', 'AXONE Nemo Plus Truck'],
      },
    },
  ],
  'ac-service': [
    {
      manufacturer: 'Robinair',
      modelsByType: {
        r134a: ['34788NI', '34788NI-H', '34988'],
        r1234yf: ['AC1234-4', 'AC1234-4SL', 'AC1234-6'],
        'dual-gas': ['AC1X34-5i', 'AC1X34-7i'],
      },
    },
    {
      manufacturer: 'MAHLE',
      modelsByType: {
        r134a: ['ArcticPRO ACX2150', 'ArcticPRO ACX2180', 'ArcticPRO ACX2180H'],
        r1234yf: ['ArcticPRO ACX2250', 'ArcticPRO ACX2280'],
        'dual-gas': ['ArcticPRO ACX1280'],
      },
    },
    {
      manufacturer: 'Mastercool',
      modelsByType: {
        r134a: ['69788-A', '69789-H'],
        r1234yf: ['69372', '69360-YF'],
        'dual-gas': ['69390'],
      },
    },
    {
      manufacturer: 'Snap-on',
      modelsByType: {
        r134a: ['Polartek Plus EEAC330'],
        r1234yf: ['Polartek YF EEAC333'],
        'dual-gas': ['Polartek Dual EEAC334'],
      },
    },
  ],
  compressors: [
    {
      manufacturer: 'Kaeser',
      modelsByType: {
        'rotary-screw': ['SX Series', 'SM Series', 'SK Series', 'AS Series'],
        reciprocating: ['Premium Series'],
        portable: ['MOBILAIR M17', 'MOBILAIR M27', 'MOBILAIR M55'],
      },
    },
    {
      manufacturer: 'Atlas Copco',
      modelsByType: {
        'rotary-screw': ['GA Series', 'G Series', 'GX Series'],
        reciprocating: ['LE Series', 'LT Series'],
        scroll: ['SF Series', 'SF+ Series'],
        portable: ['XAS Series', 'E-Air Series'],
      },
    },
    {
      manufacturer: 'Ingersoll Rand',
      modelsByType: {
        'rotary-screw': ['UP6 Series', 'R-Series', 'Nirvana'],
        reciprocating: ['2475', '2545', '2340'],
        scroll: ['D-Series Oil-Free Scroll'],
        portable: ['P1.5IU-A9', 'SS3J5.5GH-WB'],
      },
    },
    {
      manufacturer: 'Quincy Compressor',
      modelsByType: {
        'rotary-screw': ['QGS Series', 'QGD Series', 'QGV Series'],
        reciprocating: ['QT Series', 'QP Series'],
        scroll: ['QOF Series'],
        portable: ['QT Portable Series'],
      },
    },
    {
      manufacturer: 'Sullair',
      modelsByType: {
        'rotary-screw': ['ShopTek', 'LS Series', 'TS Series'],
        portable: ['185 Series', '375 Series'],
      },
    },
    {
      manufacturer: 'Powerex',
      modelsByType: {
        reciprocating: ['Piston Air Series'],
        scroll: ['SLAE Series', 'SE Series', 'Oil-less Scroll Enclosure'],
      },
    },
  ],
};

function catalogFor(category: string, equipmentType: string): ManufacturerCatalog[] {
  return (EQUIPMENT_CATALOG[category] ?? []).filter(
    entry => (entry.modelsByType[equipmentType] ?? []).length > 0,
  );
}

export function getManufacturerSuggestions(category: string, equipmentType: string): string[] {
  const catalogSuggestions = catalogFor(category, equipmentType).map(entry => entry.manufacturer);
  // The shared registry is keyed by active equipment type. The model
  // catalogue contributes only brands with real models for that same type.
  return [...new Set([...getRegisteredBrands(category, equipmentType), ...catalogSuggestions])];
}

export function getModelSuggestions(
  category: string,
  equipmentType: string,
  manufacturer: string,
): string[] {
  const entries = catalogFor(category, equipmentType);
  const normalizedManufacturer = manufacturer.trim().toLowerCase();
  const exact = entries.find(entry => entry.manufacturer.toLowerCase() === normalizedManufacturer);

  if (exact) return exact.modelsByType[equipmentType] ?? [];

  return [...new Set(entries.flatMap(entry => entry.modelsByType[equipmentType] ?? []))];
}